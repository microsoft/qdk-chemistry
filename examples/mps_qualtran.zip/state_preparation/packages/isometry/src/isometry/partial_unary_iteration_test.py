# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import pytest
from qualtran import QUInt

from .isometry import ToggleWithPhase
from .partial_unary_iteration import (
    PartialUnaryIteration,
    _partial_unary_iteration_restricted,
    _partial_unary_iteration_unrestricted,
)
from .utils_test import bloq_autotester  # noqa: F401


@pytest.mark.parametrize(
    "bloq_ex",
    [
        _partial_unary_iteration_unrestricted,
        _partial_unary_iteration_restricted,
    ],
)
def test_examples(bloq_autotester, bloq_ex):  # noqa: F811
    bloq_autotester(bloq_ex)


@pytest.mark.parametrize("restricted", [True, False])
@pytest.mark.parametrize("interval", [(5, 6), (0, 16), (7, 15), (0, 7), (7, 16)])
def test_pui(restricted: bool, interval: tuple[int, int]):
    pui = PartialUnaryIteration(
        interval,
        QUInt(4),
        tuple(ToggleWithPhase(16, i, False, None) for i in range(*interval)),
        restricted=restricted,
    )

    assert len(pui.mapping) == interval[1] - interval[0]
    if restricted:
        for i, bloq_interval in enumerate(pui.mapping):
            assert bloq_interval == [interval[0] + i]

    for i in range(1 << 4):
        address, operation = pui.call_classically(
            address=i, operation=np.zeros(16, dtype=int)
        )

        assert address == i
        if interval[0] <= i < interval[1]:
            assert np.allclose(operation, np.eye(16, dtype=int)[i])
        elif i < interval[0]:
            assert np.allclose(operation, np.zeros(16))
        else:
            if restricted:
                assert np.allclose(operation, np.zeros(16))
            else:
                for j, bloq_interval in enumerate(pui.mapping):
                    if i in bloq_interval:
                        assert np.allclose(
                            operation, np.eye(16, dtype=int)[interval[0] + j]
                        )
