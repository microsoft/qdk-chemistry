# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np
from qualtran.symbolics import HasLength, Shaped, slen


def random_tableau(
    num_rows: int,
    num_columns: int,
    seed: int | None = None,
) -> np.ndarray:
    """
    Generate a random binary matrix with unique rows.

    The function creates a ``num_rows x num_columns`` array of ``bool`` values. Each row
    is a distinct binary vector (i.e. no two rows are identical)

    Parameters
    ----------
    - num_rows: int
        Desired number of rows in the output matrix.
    - num_columns: int
        Desired number of columns (bits) per row.
    - seed: int | None, optional (default: ``None``)
        Seed for the NumPy random generator.  Supplying a fixed integer makes the output
        deterministic, which is handy for reproducible tests.

    Returns
    -------
    - np.ndarray :
        A ``(num_rows, num_columns)`` boolean array. The rows are guaranteed to be
        pairwise distinct.
    """

    max_unique_rows = 1 << num_columns
    assert num_columns <= max_unique_rows, (
        f"Can only have as many columns as unique rows. Have {num_columns} columns and {max_unique_rows} rows."
    )

    highs = []
    i = 0
    while i < num_columns:
        bits = min(8, num_columns - i)
        highs.append(1 << bits)
        i += 8

    rng = np.random.default_rng(seed)
    seen: dict[tuple[np.uint8, ...], None] = dict()
    # Use dict for remembering order allowing reproducibility

    while len(seen) < num_rows:
        batch_needed = int(np.ceil((num_rows - len(seen)) * 1.1))

        batch_rows = rng.integers(
            low=0,
            high=highs,
            size=(batch_needed, len(highs)),
            dtype=np.uint8,
        )
        seen.update({tuple(row): None for row in batch_rows})

    return np.unpackbits(
        np.array(list(seen.keys())[:num_rows]),
        bitorder="little",
        axis=1,
        count=num_columns,
    ).astype(bool)


def random_signs(num_rows: int, seed: int | None = None) -> np.ndarray:
    """Return a random boolean vector of length ``num_rows``.

    Parameters
    ----------
    - num_rows: int
        Length of the output vector.
    - seed: int | None, optional (default: ``None``)
        Seed for the NumPy random generator.  Supplying a fixed integer makes the output
        deterministic.

    Returns
    -------
    - np.ndarray :
        A one-dimensional boolean array of shape ``(num_rows,)``.
    """
    rng = np.random.default_rng(seed)
    return rng.random(num_rows) < 0.5


def data_to_tuple(data: np.ndarray | HasLength | Shaped | None) -> tuple | None:
    """
    Convert a NumPy array (or ``None``) into a hash-able tuple. This is used for
    comparing/hashing.
    """
    if data is None:
        return None
    elif isinstance(data, HasLength):
        return (slen(data),)
    elif isinstance(data, Shaped):
        return data.shape
    else:
        return tuple(data.flatten()) + tuple(data.shape)


type HasLen = np.ndarray | HasLength
type HasShape = np.ndarray | Shaped


def pad(data: HasLen, final_len: int) -> HasLen:
    """Pad the data with zeros such that is has ``final_len``."""
    assert slen(data) <= final_len, (
        f"Final length {final_len} smaller than data length {slen(data)}.."
    )
    if isinstance(data, np.ndarray):
        return np.pad(data, [(0, final_len - slen(data))])
    else:
        return HasLength(final_len)
