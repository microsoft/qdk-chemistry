# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

from functools import cached_property

import numpy as np
import quimb.tensor as qtn
from attrs import frozen
from isometry.utils import HasLen
from qualtran import (
    Bloq,
    BloqBuilder,
    ConnectionT,
    QBit,
    QDType,
    Register,
    Side,
    Signature,
    SoquetT,
)
from qualtran.bloqs.basic_gates import (
    CSwap,
    Discard,
    MeasureX,
    OneEffect,
    OneState,
    ZeroEffect,
)
from qualtran.bloqs.data_loading import QROAMClean
from qualtran.bloqs.swap_network import SwapWithZero
from qualtran.resource_counting.generalizers import (
    _ignore_wrapper,
    generalize_cvs,
    ignore_alloc_free,
    ignore_split_join,
)
from qualtran.symbolics.types import is_symbolic, slen


@frozen(cache_hash=True)
class FakeMeas(Bloq):
    """
    Fake measurement bloq used for tensor simulations.

    Unphysical fake X-measurement that is independent of the state.

    At the moment the Bloq is not symbolic.

    Registers
    ----------
    - q : ``QBit``
        Qubit to measure.
    """

    random: bool = False
    """
    If ``False``, each X-measurement result is assumed to be deterministically ``|+>``. 
    If ``True`` randomly measure ``|+>`` or ``|->``, each result occuring with 
    probability ``0.5`` independent of the actual state. At the end it is assumend that
    the qubit it ``|+>``, e.g. by classicaly controlled operation."""

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("q", QBit()),
            ]
        )

    def my_tensors(
        self, incoming: dict[str, ConnectionT], outgoing: dict[str, ConnectionT]
    ) -> list[qtn.Tensor]:  # type:ignore
        """@private"""
        # Define fake measurement operator: measurement + classical controlled
        # operation resulting in |0> potentially with a sign.
        if self.random:
            sign = np.random.choice([1, -1])
            fake_meas = np.array([[1, sign], [0, 0]], dtype=np.complex128)
        else:
            fake_meas = np.array([[1, 1], [0, 0]], dtype=np.complex128)

        return [
            qtn.Tensor(
                data=fake_meas,
                inds=[(outgoing["q"], 0), (incoming["q"], 0)],
                tags=[str(self)],
            )
        ]


@frozen(cache_hash=True)
class MeasureInX(Bloq):
    """
    X-basis measurement of a register. The classical measurement result is discarded.

    At the moment the Bloq is not symbolic.

    Registers
    ----------
    - to_measure : ``self.qdtype`` (LEFT side):
        The register that is measured.
    """

    qdtype: QDType
    """Data type of the register that will be measured."""

    fake_random: None | bool = None
    """
    If ``None`` (default) a real X-basis measurement is performed using
    :class:`qualtran.bloqs.basic_gates.MeasureX`. If a boolean is supplied the
    measurement is replaced by a fake measurement:
    If ``False``, each X-measurement result is assumed to be deterministically ``|+>``.
    If ``True`` randomly measure ``|+>`` or ``|->``, each result occuring with 
    probability ``0.5`` independent of the actual state. At the end the qubit is 
    discarded.
    """

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("to_measure", self.qdtype, side=Side.LEFT),
            ]
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, to_measure: SoquetT
    ) -> dict[str, SoquetT]:  # type:ignore
        """@private"""
        for q in bb.split(to_measure):
            if self.fake_random is not None:
                q = bb.add(FakeMeas(self.fake_random), q=q)
                q = bb.add(ZeroEffect(), q=q)
            else:
                meas_result = bb.add(MeasureX(), q=q)
                bb.add(Discard(), c=meas_result)
                # We discard the measurement value for now.
                # Later use it to apply correct SignFixUp
        return {}


def ignore_measure_effect_state(b: Bloq) -> Bloq | None:
    """A generalizer that ignores measurements."""
    if isinstance(b, (MeasureInX, OneEffect, OneState, Discard)):
        return None
    return _ignore_wrapper(ignore_alloc_free, b)


def generalizer(b: Bloq) -> Bloq | None:
    for generalizer in [
        ignore_split_join,
        ignore_alloc_free,
        generalize_cvs,
        ignore_measure_effect_state,
    ]:
        b = generalizer(b)  # type: ignore
        if b is None:
            return None
    return b


def combine_sign_flips(flips_1: HasLen, flips_2: HasLen) -> HasLen:
    """XOR the two sign flip arrays."""
    assert slen(flips_1) == slen(flips_2), (
        f"Sign flip array lengths not equal: {slen(flips_1)} vs. {slen(flips_2)}."
    )
    return flips_1 if is_symbolic(flips_1, flips_2) else flips_1 ^ flips_2  # type: ignore


def clear_qroam_junk_registers(
    bb: BloqBuilder,
    dtype: QDType,
    tensor_simulation_random: None | bool,
    **soqs: SoquetT,
) -> dict[str, SoquetT]:
    """
    Clear the junk registers created by QROAM by measuring in the X-basis. This
    introduces +/-1 phase errors. The ``dtype`` of the target register for the QROAM
    call is needed.
    If ``None`` (default) a real X-basis measurement is performed using
    :class:`qualtran.bloqs.basic_gates.MeasureX`. If a boolean is supplied the
    measurement is replaced by a fake measurement:
    If ``False``, each X-measurement result is assumed to be deterministically ``|+>``.
    If ``True`` randomly measure ``|+>`` or ``|->``, each result occuring with
    probability ``0.5`` independent of the actual state. At the end the qubit is
    discarded.
    """
    for junk_soquet in [s for s in soqs.keys() if s.startswith("junk_target")]:
        for junk in soqs.pop(junk_soquet):
            bb.add(
                MeasureInX(
                    dtype,
                    tensor_simulation_random,
                ),
                to_measure=junk,
            )
    return soqs


def angle_to_binary(angles: np.ndarray, bitsize: int) -> np.ndarray:
    """
    Transform the elements in the array ``angles`` of floats into an array of ints from
    zero up to (excluding) ``bitsize``, such that the ``result/2**(bitsize) ``is the
    best approximation of the original value modulo ``2*pi``.
    """
    # Transform into [0, 2*pi].
    angles = angles % (2 * np.pi)
    # Transform to value in [0, 2**bitsize)
    scaled = (1 << bitsize) * angles / (2 * np.pi)
    rounded = np.round(scaled) % (1 << bitsize)
    return rounded.astype(np.int64)


@frozen(cache_hash=True)
class QROAMCleanExactCSwap(QROAMClean):
    """
    Wrapper around :class:`qualtran.bloqs.data_loading.QROAMClean` that replaces the
    approximate CSwap with the exact version. The approximate version introduces a
    random sign mistake.
    """

    @cached_property
    def swap_with_zero_bloqs(self) -> list[SwapWithZero]:
        return [
            SwapWithZeroExactCSwap(
                self.log_block_sizes,
                target_bitsize=target_bitsize,
                n_target_registers=self.block_sizes,
            )
            for target_bitsize in self.target_bitsizes
        ]


@frozen(cache_hash=True)
class SwapWithZeroExactCSwap(SwapWithZero):
    """
    Wrapper around :class:`qualtran.bloqs.swap_network.SwapWithZero` that replaces the
    approximate CSwap with the exact version. The approximate version introduces a
    random sign mistake.
    """

    @cached_property
    def cswap_n(self) -> CSwap:
        return CSwap(self.target_bitsize)


def set_qroam_max_junk_size(qroam: QROAMClean, max_junk_size: None | int) -> QROAMClean:
    """
    Make sure the ``qroam`` does not use more than ``max_junk_size`` qubits for its
    ancilla registers.
    """
    if max_junk_size is not None:
        assert max_junk_size >= 0, (
            f"The junk size must be non-negative. Have {max_junk_size}."
        )
        while sum(j.total_qubits() for j in qroam.junk_registers) > max_junk_size:
            qroam = qroam.with_log_block_sizes(qroam.log_block_sizes[0] - 1)
    return qroam
