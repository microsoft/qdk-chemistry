# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np

class RzRyLayerData:
    """
    A layer of ``Ry * Rz`` rotations of the form equ. (23) in the Berry et al. paper if
    ``shifted`` is ``False`` and (24) if ``True``.

    Attributes
    ----------
    angles_rz: list[float]
        The ``Rz`` rotation angles (in radians) for each rotation in the layer.
    angles_ry: list[float]
        The ``Ry`` rotation angles (in radians) for each rotation in the layer.
    shifted: bool
        ``True`` if the layer is the shifted form (equation (24)),
        ``False`` for the standard form (equation (23)).
    """

    angles_rz: list[float]
    angles_ry: list[float]
    shifted: bool

    def __repr__(self) -> str: ...

class RyLayerData:
    """
    A layer of ``Ry`` rotations of the form equ. (23) in the Berry et al. paper if
    ``shifted`` is ``False`` and (24) if ``True``.

    Attributes
    ----------
    angles_ry: list[float]
        The ``Ry`` rotation angles (in radians) for each rotation in the layer.
    shifted: bool
        ``True`` if the layer is the shifted form (equation (24)),
        ``False`` for the standard form (equation (23)).
    """

    angles_ry: list[float]
    shifted: bool

    def __repr__(self) -> str: ...

def decompose_complex(
    block_matrices: list[tuple[np.ndarray, ...]],
) -> tuple[list[float], list[RzRyLayerData]]:
    """
    Decompose a complex block-diagonal unitary ``U`` into a diagonal phase matrix ``D``
    and a sequence of ``RzRy`` layers.

    Returns
    -------
    phases: list[float]
        The diagonal phases ``phases`` such that ``D = diag(e^{1j*phases})``.
    layers: list[RzRyLayerData]
        The list of ``RzRy`` layers that realise the remaining unitary.
    """

def decompose_real(
    block_matrices: list[tuple[np.ndarray, ...]],
) -> tuple[list[bool], list[RyLayerData]]:
    """
    Decompose a real block-diagonal unitary ``U`` into a diagonal matrix with entries
    ``+/-1`` and a sequence of ``Ry`` layers.

    Returns
    -------
    phases: list[bool]
        The diagonal phases corresponding to the ``+/-1`` entries of the diagonal
        matrix. ``-1`` corrsponds to ``True``.
    layers: list[RyLayerData]
        The list of ``Ry`` layers that realise the remaining unitary.
    """
