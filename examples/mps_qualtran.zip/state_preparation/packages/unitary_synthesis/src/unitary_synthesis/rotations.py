# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

from collections import Counter
from functools import cached_property

import numpy as np
from attrs import evolve, field, frozen
from isometry import random_signs
from isometry.utils import HasLen, data_to_tuple, pad
from qualtran import (
    Bloq,
    BloqBuilder,
    QBit,
    QFxp,
    QUInt,
    Register,
    Signature,
    SoquetT,
    bloq_example,
)
from qualtran.bloqs.arithmetic import AddK
from qualtran.bloqs.basic_gates import Hadamard, OneEffect, OneState, SGate
from qualtran.bloqs.basic_gates.on_each import OnEach
from qualtran.bloqs.basic_gates.x_basis import XGate
from qualtran.bloqs.bookkeeping import Partition
from qualtran.bloqs.data_loading.qroam_clean import QROAMClean
from qualtran.bloqs.rotations import RzViaPhaseGradient
from qualtran.resource_counting import BloqCountDictT, SympySymbolAllocator
from qualtran.symbolics import bit_length, is_symbolic, slen
from qualtran.symbolics.types import HasLength
from scipy.linalg import block_diag

from .utils import (
    MeasureInX,
    QROAMCleanExactCSwap,
    angle_to_binary,
    clear_qroam_junk_registers,
    combine_sign_flips,
    generalizer,
    set_qroam_max_junk_size,
)


def _rz(angle: float) -> np.ndarray:
    """Rz gate matrix with``angle``."""
    return np.diag([np.exp(-1j * angle), np.exp(1j * angle)])


def _ry(angle: float) -> np.ndarray:
    """Ry gate matrix with ``angle``."""
    return np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])


@frozen(cache_hash=True)
class RyLayer:
    """
    A layer of ``Ry`` rotations of the form equ. (23) in the Berry et al. paper if
    ``shifted`` is ``False`` and (24) if ``True``.
    """

    angles_ry: HasLen = field(eq=lambda x: data_to_tuple(x))
    """
    One-dimensional array containing the ``Ry`` rotation angles (in radians) for each 
    rotation in the layer
    """
    shifted: bool
    """
    Indicate whether the layer is shifted by one, i.e. if it has the form (24) instead 
    of (24) in the reference.
    """

    def is_symbolic(self) -> bool:
        return is_symbolic(self.angles_ry)

    def _to_matrix(self, dimension: int) -> np.ndarray:
        """Create a matrix representing the layer. Enlarge matrix to ``dimension``."""
        layer = [_ry(y) for y in self.angles_ry]  # type: ignore
        if self.shifted:
            layer = [np.eye(1)] + layer + [np.eye(dimension - 2 * len(layer) - 1)]
        else:
            layer = layer + [np.eye(dimension - 2 * len(layer))]
        return block_diag(*layer)

    def commute_through_phases(self, phases: np.ndarray) -> "RyLayer":
        """
        Commute the ``phases`` trough the layer, potentially changing signs in the
        ``angles_ry``of the layer. The ``phases`` are not changed.
        """
        if self.is_symbolic():
            raise ValueError("Not implemented for symbolic object.")
        return _commute_through_phases(self, phases)  # type: ignore


@frozen(cache_hash=True)
class RzRyLayer:
    """
    A layer of ``Ry * Rz`` rotations of the form equ. (23) in the Berry et al. paper if
    ``shifted`` is ``False`` and (24) if ``True``.
    """

    angles_ry: HasLen = field(eq=lambda x: data_to_tuple(x))
    """
    One-dimensional array containing the ``Ry`` rotation angles (in radians) for each 
    rotation in the layer.
    """

    angles_rz: HasLen = field(eq=lambda x: data_to_tuple(x))
    """
    One-dimensional array containing the ``Rz`` rotation angles (in radians) for each 
    rotation in the layer.
    """

    shifted: bool
    """
    Indicate whether the layer is shifted by one, i.e. if it has the form (24) instead 
    of (24) in the reference.
    """

    def __attrs_post_init__(self):
        assert slen(self.angles_ry) == slen(self.angles_rz), (
            f"Rz- and Ry-angles must have same length. Have Ry={slen(self.angles_ry)} and Rz={slen(self.angles_rz)}."
        )

    def is_symbolic(self) -> bool:
        return is_symbolic(self.angles_ry, self.angles_rz)

    def _to_matrix(self, dimension: int) -> np.ndarray:
        """Create a matrix representing the layer. Enlarge matrix to ``dimension``."""
        layer = [_ry(y) @ _rz(z) for y, z in zip(self.angles_ry, self.angles_rz)]  # type: ignore
        if self.shifted:
            layer = [np.eye(1)] + layer + [np.eye(dimension - 2 * len(layer) - 1)]
        else:
            layer = layer + [np.eye(dimension - 2 * len(layer))]
        return block_diag(*layer)

    def commute_through_phases(self, phases: np.ndarray) -> "RzRyLayer":
        """
        Commute the ``phases`` trough the layer, potentially changing signs in the
        ``angles_ry``of the layer. The ``phases`` are not changed.
        """
        if self.is_symbolic():
            raise ValueError("Not implemented for symbolic object.")
        return _commute_through_phases(self, phases)  # type: ignore


def _commute_through_phases(
    layer: RzRyLayer | RyLayer, phases: np.ndarray
) -> RzRyLayer | RyLayer:
    """
    Commute the ``phases`` trough the layer, potentially changing signs in the
    ``angles_ry``of the layer. The ``phases`` are not changed.
    """
    shift = layer.shifted
    sign_flips = np.array(
        [
            (-1) ** (phases[2 * i + shift] != phases[2 * i + shift + 1])
            for i, _ in enumerate(layer.angles_ry)  # type: ignore
        ]
    )
    return evolve(layer, angles_ry=sign_flips * layer.angles_ry)


@frozen(cache_hash=True)
class RyRotation(Bloq):
    """
    Apply a Ry-Rotation to a qubit with the angle(s) stored in an angle-register making
    use of a phase-gradient state.

    At the moment the Bloq is not symbolic.

    Registers
    ----------
    - q : ``QBit()``:
        The qubit the Ry-rotation is applied to.

    - angles : ``self.phase_gradient_dtype``:
        The register storing the angles for the rotation to be applied.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations.  It is passed through unchanged.
    """

    phase_gradient_dtype: QFxp
    """
    Datatype used for the phase-gradient register determining the accuracy of the 
    rotations.
    """

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("q", QBit()),
                Register("angles", self.phase_gradient_dtype),
                Register("phase_gradient", self.phase_gradient_dtype),
            ]
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, q: SoquetT, angles: SoquetT, phase_gradient: SoquetT
    ) -> dict[str, SoquetT]:  # type:ignore
        """@private"""
        q = bb.add(SGate().adjoint(), q=q)
        q = bb.add(Hadamard(), q=q)
        q, angles, phase_gradient = bb.add(
            RzViaPhaseGradient(
                self.phase_gradient_dtype,
                self.phase_gradient_dtype,
            ),
            q=q,
            angle=angles,
            phase_grad=phase_gradient,
        )
        q = bb.add(Hadamard(), q=q)
        q = bb.add(SGate(), q=q)
        return {"q": q, "angles": angles, "phase_gradient": phase_gradient}

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        return {
            RzViaPhaseGradient(self.phase_gradient_dtype, self.phase_gradient_dtype): 1,
            SGate(): 1,
            SGate().adjoint(): 1,
            Hadamard(): 2,
        }


@frozen(cache_hash=True)
class ZYRotations(Bloq):
    """
    Apply a layer of ``Ry`` rotations or ``Ry * Rz`` rotations.

    The Bloq takes a tuple of ``RyLayer`` or ``RzRyLayer`` (all of the same form) and
    creates a quantum circuit that applies the corresponding rotations on the
    ``target_register``. If more than one layer object is provided the i-th rotation is
    applied if the subspace register state is ``|i>``.

    The rotations are applied using a phase-gradient register.
    The Bloq may be controlled on a control qubit if ``controlled`` is set.
    The qubit/Toffoli tradeoff in the QROAM can be controlled via
    ``max_qroam_junk_qubits``.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. The measurement results are simply discarded. See
    ``tensor_simulation`` for how those measurements can be treated in simulations.

    Registers
    ----------
    - target : ``self.target_dtype``:
        The target register on which the rotations act.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations.  It is passed through unchanged.

    - subspace : ``QUInt(self.subspace_bitsize)`` (optional):
        Register for selecting subspaces the unitaries are applied to. Only created if
        more than one matrix is supplied.

    - control : ``QBit`` (optional):
        Qubit that acts as a control qubit for the unitaries. Only created if
        ``controlled`` is set.
    """

    rotations: tuple[RyLayer, ...] | tuple[RzRyLayer, ...]
    """Rotation layer to be applied (one per value in subspace)."""

    target_dtype: QUInt
    """Target datatype for the rotations."""

    phase_gradient_dtype: QFxp
    """Fixed-point type for the phase-gradient register."""

    controlled: bool = False
    """
    If ``True`` the rotations are controlled on an extra ``QBit``. Defaults to 
    ``False``.
    """

    signs_in: HasLen | None = field(eq=lambda x: data_to_tuple(x), default=None)
    """
    Incoming signs for each basis state in the joint ``subspace``+``target`` register. 
    Defaults to ``None``.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor 
    simulation. This replaces the X-measurements by unphysical fake X-measurements that 
    are independent of the state that is measured and avoid classical controlled 
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e. 
    no phase flips are applied. Defaults to ``False``.
    """

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(
            *self.rotations,
            self.signs_in,
        )

    @property
    def subspace_bitsize(self) -> int:
        """
        Size of the subspace register that holds the indexes of the ``rotations``. Is
        zero if ``rotations`` consists of a single object.
        """
        return bit_length(len(self.rotations) - 1)

    @cached_property
    def _active_target_bitsize(self) -> int:
        """
        Bitsize that is actually neded for the rotation. All other qubits can be
        transfomed into QROAM controls.
        """
        m = max(slen(x.angles_ry) for x in self.rotations)
        if not self._ry_only:
            m_z = max([slen(x.angles_rz) for x in self.rotations])  # type: ignore
            m = max(m, m_z)
        return bit_length(max(1, m - 1))

    @property
    def _address_bitsize(self) -> int:
        """Number of bits needed to address the rotation angles."""
        return self._active_target_bitsize + self.subspace_bitsize

    @property
    def _passive_address_bitsize(self) -> int:
        """Bitsize of the target qubits that act as controls in the QROAM."""
        return self.target_dtype.num_bits - self._active_target_bitsize - 1

    def __attrs_post_init__(self):
        assert all(isinstance(rot, RzRyLayer) for rot in self.rotations) or all(
            isinstance(rot, RyLayer) for rot in self.rotations
        ), (
            f"All rotation types must be equal. Have {[type(rot) for rot in self.rotations]}"
        )
        assert slen(set(rot.shifted for rot in self.rotations)) == 1, (
            f"All rotations must either be shifted or not. Have {[rot.shifted for rot in self.rotations]}."
        )
        assert 1 << self.subspace_bitsize == slen(self.rotations), (
            f"Need {1 << self.subspace_bitsize} many subspace matrices. Have {len(self.rotations)}."
        )
        assert self._passive_address_bitsize >= 0, "Need enough space for angles."
        if self.signs_in is not None:
            assert slen(self.signs_in) == 1 << (
                self.target_dtype.num_bits + self.subspace_bitsize
            ), f"Sign_in length {slen(self.signs_in)} must be {
                1 << (self.target_dtype.num_bits + self.subspace_bitsize)
            }."

    @property
    def signature(self) -> Signature:
        """@private"""
        regs = [
            Register("target", self.target_dtype),
            Register("phase_gradient", self.phase_gradient_dtype),
        ]
        if self.subspace_bitsize > 0:
            regs.append(Register("subspace", QUInt(self.subspace_bitsize)))
        if self.controlled:
            regs.append(Register("control", QBit()))
        return Signature(regs)

    @property
    def signs_out(self) -> HasLen:
        """
        Outgoing signs for each basis state in the joint ``subspace``+``target``
        register.
        """
        if self.signs_in is not None:
            return combine_sign_flips(self._sign_flips_qroam, self.signs_in)
        return self._sign_flips_qroam

    @property
    def _ry_only(self) -> bool:
        """Indicate whether only the Ry rotation is applied."""
        return isinstance(self.rotations[0], RyLayer)

    @property
    def _shifted(self) -> bool:
        """Indicate whether the rotation layer is shifted by one."""
        return self.rotations[0].shifted

    @property
    def _rotations_after_commutations(
        self,
    ) -> tuple[RyLayer, ...] | tuple[RzRyLayer, ...]:
        """
        Change the Ry-rotation angles to take into account the minuses resulting from
        commuting through the signs from ``signs_in``.
        """
        if self.signs_in is not None:
            block_size = 1 << self.target_dtype.num_bits
            return tuple(
                rot.commute_through_phases(
                    self.signs_in[
                        i * block_size : (i + 1) * block_size
                    ]  # type : ignore
                )
                for i, rot in enumerate(self.rotations)
            )  # type: ignore
        return self.rotations

    @property
    def _subspace_angles(
        self,
    ) -> tuple[tuple[HasLen, ...]] | tuple[tuple[HasLen, ...], tuple[HasLen, ...]]:
        """Rotation angles for the Ry and Ry layer of each subspace in binary."""
        if self.shapes_only:
            ry = tuple(HasLength(slen(rot.angles_ry)) for rot in self.rotations)
        else:
            ry = tuple(
                angle_to_binary(rot.angles_ry, self.phase_gradient_dtype.num_bits)  # type: ignore
                for rot in self._rotations_after_commutations
            )
        if not self._ry_only:
            if self.shapes_only:
                rz = tuple(HasLength(slen(rot.angles_rz)) for rot in self.rotations)  # type: ignore
            else:
                rz = tuple(
                    angle_to_binary(
                        rot.angles_rz,  # type: ignore
                        self.phase_gradient_dtype.num_bits,
                    )
                    for rot in self._rotations_after_commutations
                )
            return (ry, rz)
        return (ry,)

    @property
    def _rotation_angles(
        self,
    ) -> tuple[HasLen] | tuple[HasLen, HasLen]:
        """Rotation angles for the Ry and Ry layer padded."""
        padded_len = 1 << self._active_target_bitsize
        padded_ry = [pad(x, padded_len) for x in self._subspace_angles[0]]

        if not self._ry_only:
            padded_rz = [pad(x, padded_len) for x in self._subspace_angles[1]]  # type: ignore
            if self.shapes_only:
                return (
                    HasLength(sum(slen(x) for x in padded_ry)),
                    HasLength(sum(slen(x) for x in padded_rz)),
                )
            else:
                return (np.hstack(padded_ry), np.hstack(padded_rz))  # type: ignore
        if self.shapes_only:
            return (HasLength(sum(slen(x) for x in padded_ry)),)
        else:
            return (np.hstack(padded_ry),)  # type: ignore

    @property
    def _qroam(self) -> QROAMClean:
        """QROAM for loading the rotation angles."""
        num_controls = self._passive_address_bitsize
        if self.controlled:
            num_controls += 1

        target_bitsizes = (self.phase_gradient_dtype.num_bits,) * len(
            self._rotation_angles
        )
        if self.shapes_only:
            qroam = QROAMCleanExactCSwap.build_from_bitsize(
                slen(
                    self._rotation_angles[0]
                ),  # need only one dataset to make .build_from_bitsize happy
                target_bitsizes=target_bitsizes,
                num_controls=num_controls,
            )
        else:
            qroam = QROAMCleanExactCSwap.build_from_data(
                *self._rotation_angles,  # type: ignore
                target_bitsizes=target_bitsizes,
                num_controls=num_controls,
            )
        return set_qroam_max_junk_size(qroam, self.max_qroam_junk_qubits)

    @property
    def _sign_flips_qroam(self) -> HasLen:
        """Get random sign flips, imitating the flips caused by X-measurements."""
        address_dim = 1 << self._address_bitsize
        passive_address_dim = 1 << self._passive_address_bitsize
        # The +1 is not accurate, since the last target qubit is not a control qubit,
        # For simplicity we cheat here.
        if self.shapes_only:
            return HasLength(2 * passive_address_dim * address_dim)
        if self.tensor_simulation:
            return np.zeros(2 * passive_address_dim * address_dim, dtype=bool)
        # TODO: Compute the values from the X-measurements using classical registers.
        random = random_signs(address_dim, seed=1999999)
        return np.hstack(2 * passive_address_dim * [random])

    def _load_and_rotate(
        self,
        bb: BloqBuilder,
        address: SoquetT,
        active: SoquetT,
        phase_gradient: SoquetT,
        **soqs: SoquetT,
    ) -> tuple[SoquetT, SoquetT, SoquetT, dict[str, SoquetT]]:
        """Load the angles and apply the rotations."""
        fake_random_meas = False if self.tensor_simulation else None

        # Load data
        soqs = bb.add_d(self._qroam, selection=address, **soqs)
        soqs = clear_qroam_junk_registers(
            bb, self.phase_gradient_dtype, fake_random_meas, **soqs
        )
        if not self._ry_only:
            # Apply Rz rotation
            active, angles_rz, phase_gradient = bb.add(
                RzViaPhaseGradient(
                    self.phase_gradient_dtype, self.phase_gradient_dtype
                ),
                q=active,
                angle=soqs.pop("target1_"),
                phase_grad=phase_gradient,
            )
            bb.add(
                MeasureInX(self.phase_gradient_dtype, fake_random_meas),
                to_measure=angles_rz,
            )
        # Apply Ry rotation.
        active, angles_ry, phase_gradient = bb.add(
            RyRotation(self.phase_gradient_dtype),
            q=active,
            angles=soqs.pop("target0_"),
            phase_gradient=phase_gradient,
        )
        bb.add(
            MeasureInX(self.phase_gradient_dtype, fake_random_meas),
            to_measure=angles_ry,
        )  # TODO: Collect measurement results in classical register and compute sign
        # flips.
        return soqs.pop("selection"), active, phase_gradient, soqs

    @property
    def _active_qubit_partition(self) -> Partition:
        """
        Peel off the active qubit on which the Ry-rotation is applied. Moreover isolate
        the qubits on which we do not rotate.
        """
        regs = [
            Register("address", QUInt(self._active_target_bitsize)),
            Register("active", QBit()),
        ]
        if self._passive_address_bitsize > 0:
            regs.insert(0, Register("control", QUInt(self._passive_address_bitsize)))
        return Partition(self.target_dtype.num_bits, tuple(regs))

    @property
    def _control_partition(self) -> Partition | None:
        """
        Join the control qubits from the bloqs control and the target qubits for which
        the rotation is zero. They serve as further QROAM controls.
        """
        diff = self._passive_address_bitsize
        if self.controlled and diff > 0:
            return Partition(
                diff + 1, (Register("c1", QBit()), Register("c2", QUInt(diff)))
            )
        return None

    @property
    def _subspace_partition(self) -> None | Partition:
        """Partition joining the target and subspace register if the latter exists."""
        return (
            Partition(
                self._address_bitsize,
                (
                    Register("subspace", QUInt(self.subspace_bitsize)),
                    Register("address", QUInt(self._active_target_bitsize)),
                ),
            )
            if self.subspace_bitsize > 0
            else None
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, phase_gradient: SoquetT, **soqs: SoquetT
    ) -> dict[str, SoquetT]:  # type: ignore
        """@private"""
        target_bitsize = self.target_dtype.num_bits

        if self._shifted:  # Shift by one.
            soqs["target"] = bb.add(
                AddK(QUInt(target_bitsize), 1).adjoint(), x=soqs["target"]
            )
        soqs_f = bb.add_d(self._active_qubit_partition, x=soqs.pop("target"))
        active, address = soqs_f.pop("active"), soqs_f.pop("address")

        if (c := self._passive_address_bitsize) > 0:
            soqs_f["control"] = bb.add(OnEach(c, XGate()), q=soqs_f.pop("control"))

        if self._control_partition is not None:
            soqs["control"] = bb.add(
                self._control_partition.adjoint(),
                c1=soqs.pop("control"),
                c2=soqs_f.pop("control"),
            )
        else:
            soqs.update(soqs_f)

        if self._subspace_partition is not None:
            # Adjust QROAM address register to accomodate the subspaces.
            address = bb.add(
                self._subspace_partition.adjoint(),
                subspace=soqs.pop("subspace"),
                address=address,
            )
        # Apply the rotations.
        address, active, phase_gradient, soqs_f = self._load_and_rotate(
            bb, address, active, phase_gradient, **soqs
        )
        soqs = {"phase_gradient": phase_gradient}

        # Undo all the partitioning
        if self._subspace_partition is not None:
            soqs["subspace"], address = bb.add(self._subspace_partition, x=address)

        if self._control_partition is not None:
            soqs["control"], soqs_f["control"] = bb.add(
                self._control_partition, x=soqs_f["control"]
            )
        elif self.controlled:
            soqs["control"] = soqs_f.pop("control")

        if (c := self._passive_address_bitsize) > 0:
            soqs_f["control"] = bb.add(OnEach(c, XGate()), q=soqs_f.pop("control"))

        soqs["target"] = bb.add(
            self._active_qubit_partition.adjoint(),
            address=address,
            active=active,
            **soqs_f,
        )
        if self._shifted:  # Undo the shifting.
            soqs["target"] = bb.add(AddK(QUInt(target_bitsize), 1), x=soqs["target"])
        return soqs

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        grad_dtype = self.phase_gradient_dtype
        c = [RyRotation(grad_dtype), self._qroam]
        if not self._ry_only:
            c += [RzViaPhaseGradient(grad_dtype, grad_dtype)]  # type: ignore
        if (size := self._passive_address_bitsize) > 0:
            c += 2 * [OnEach(size, XGate())]  # type: ignore
        return Counter(c)

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        return Counter([sum(j.total_qubits() for j in self._qroam.junk_registers)])


@frozen(cache_hash=True)
class Phase(Bloq):
    """
    Apply diagonal phases.

    The Bloq takes a tuple of phase vectors (all of the same length) and synthesises a
    quantum circuit that applies the corresponding phases on the ``target_register``.
    If more than one phase vector is provided the i-th phase vector is applied if the
    subspace register state is ``|i>``.

    The rotations are applied using a phase-gradient register.
    The Bloq may be controlled on a control qubit if ``controlled`` is set.
    The qubit/Toffoli tradeoff in the QROAM can be controlled via
    ``max_qroam_junk_qubits``.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. The measurement results are simply discarded. See
    ``tensor_simulation`` for how those measurements can be treated in simulations.

    Registers
    ----------
    - target : ``self.target_dtype``:
        The target register on which the phases act.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations.  It is passed through unchanged.

    - subspace : ``QUInt(self.subspace_bitsize)`` (optional):
        Register for selecting subspaces the unitaries are applied to. Only created if
        more than one matrix is supplied.

    - control : ``QBit`` (optional):
        Qubit that acts as a control qubit for the unitaries. Only created if
        ``controlled`` is set.
    """

    phases: tuple[HasLen, ...] = field(eq=lambda x: tuple(data_to_tuple(y) for y in x))
    """Tuple of phase vectors (one per value in subspace)."""

    target_dtype: QUInt
    """Target datatype for the phase rotations."""

    phase_gradient_dtype: QFxp
    """Fixed-point type for the phase-gradient register."""

    controlled: bool = False
    """
    If ``True`` the phase loading is controlled on an extra ``QBit``. Defaults to
    ``False``.
    """

    signs_in: HasLen | None = field(eq=lambda x: data_to_tuple(x), default=None)
    """
    Incoming signs for each basis state in the joint ``subspace``+``target`` register. 
    Defaults to ``None``.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor
    simulation. This replaces the X-measurements by unphysical fake X-measurements that
    are independent of the state that is measured and avoid classical controlled
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e.
    no phase flips are applied. Defaults to ``False``
    """

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(*self.phases, self.signs_in)

    @property
    def subspace_bitsize(self) -> int:
        """
        Size of the subspace register that holds the indexes of the ``phases``. Is zero
        if ``phases`` consists of a single object.
        """
        return bit_length(slen(self.phases) - 1)

    @property
    def _active_target_bitsize(self) -> int:
        """
        Target bitsize that would be needed to accomodate the phases. Can be smaller
        than the actual target bitsize. We pad in this case.
        """
        return bit_length(max(slen(x) for x in self.phases) - 1)

    @property
    def _address_bitsize(self) -> int:
        """Number of bits needed to address the phase vector."""
        return self.target_dtype.num_bits + self.subspace_bitsize

    def __attrs_post_init__(self):
        assert 1 << self.subspace_bitsize == len(self.phases), (
            f"Need {1 << self.subspace_bitsize} many subspace phase arrays. Have {len(self.phases)}."
        )
        assert self._active_target_bitsize <= self.target_dtype.num_bits, (
            f"Need {self._active_target_bitsize} qubits for phases. Have {self.target_dtype.num_bits}."
        )
        if self.signs_in is not None:
            assert slen(self.signs_in) == 1 << self._address_bitsize, (
                f"Sign_in length {slen(self.signs_in)} must be {1 << self._address_bitsize}."
            )

    @property
    def signature(self) -> Signature:
        """@private"""
        regs = [
            Register("target", self.target_dtype),
            Register("phase_gradient", self.phase_gradient_dtype),
        ]
        if self.subspace_bitsize > 0:
            regs.append(Register("subspace", QUInt(self.subspace_bitsize)))
        if self.controlled:
            regs.append(Register("control", QBit()))
        return Signature(regs)

    @property
    def signs_out(self) -> HasLen:
        """
        Outgoing signs for each basis state in the joint ``subspace``+``target``
        register.
        """
        if self.signs_in is not None:
            return combine_sign_flips(self._sign_flips_qroam, self.signs_in)
        return self._sign_flips_qroam

    @property
    def _phases_angles(self) -> HasLen:
        """Phase angles padded and in binary form."""
        angles = tuple(
            (
                HasLength(slen(phases))
                if self.shapes_only
                else angle_to_binary(phases, self.phase_gradient_dtype.num_bits)  # type: ignore
            )
            for phases in self.phases
        )
        padded_len = 1 << self.target_dtype.num_bits
        padded_angles = [pad(x, padded_len) for x in angles]
        if self.shapes_only:
            return HasLength(sum(slen(x) for x in padded_angles))
        return np.hstack(padded_angles)  # type: ignore

    @property
    def _qroam(self) -> QROAMClean:
        """QROAM for loading the phase angles."""
        if self.shapes_only:
            qroam = QROAMCleanExactCSwap.build_from_bitsize(
                slen(self._phases_angles),
                target_bitsizes=(self.phase_gradient_dtype.num_bits,),
                num_controls=1 if self.controlled else 0,
            )
        else:
            qroam = QROAMCleanExactCSwap.build_from_data(
                self._phases_angles,  # type: ignore
                target_bitsizes=(self.phase_gradient_dtype.num_bits,),
                num_controls=1 if self.controlled else 0,
            )
        return set_qroam_max_junk_size(qroam, self.max_qroam_junk_qubits)

    @property
    def _sign_flips_qroam(self) -> HasLen:
        """Get random sign flips, imitating the flips caused by X-measurements."""
        address_dim = 1 << self._address_bitsize
        if self.shapes_only:
            return HasLength(address_dim)
        if self.tensor_simulation:
            return np.zeros(address_dim, dtype=bool)
        # TODO: Compute the values from the X-measurements using classical registers.
        return random_signs(address_dim, seed=1999999)

    def _load_and_rotate(
        self,
        bb: BloqBuilder,
        address: SoquetT,
        phase_gradient: SoquetT,
        **soqs: SoquetT,
    ) -> tuple[SoquetT, SoquetT, dict[str, SoquetT]]:
        """Load the phase angles and apply the rotation"""
        soqs = bb.add_d(
            self._qroam,
            selection=address,
            **soqs,
        )
        address, angles = soqs.pop("selection"), soqs.pop("target0_")
        soqs = clear_qroam_junk_registers(
            bb,
            self.phase_gradient_dtype,
            False if self.tensor_simulation else None,
            **soqs,
        )  # TODO: Collect measurement results in classical register and compute sign
        # flips.

        # Rotate on ancillary qubit.
        anc = bb.add(OneState())
        anc, angles, phase_gradient = bb.add(
            RzViaPhaseGradient(
                angle_dtype=self.phase_gradient_dtype,
                phasegrad_dtype=self.phase_gradient_dtype,
            ),
            q=anc,
            angle=angles,
            phase_grad=phase_gradient,
        )
        bb.add(OneEffect(), q=anc)

        # Delete angle register.
        bb.add(
            MeasureInX(
                self.phase_gradient_dtype, False if self.tensor_simulation else None
            ),
            to_measure=angles,
        )  # TODO: Collect measurement results in classical register and compute sign
        # flips.
        return address, phase_gradient, soqs

    @property
    def _subspace_partition(self) -> None | Partition:
        """Partition joining the target and subspace register if the latter exists."""
        return (
            Partition(
                self._address_bitsize,
                (
                    Register("subspace", QUInt(self.subspace_bitsize)),
                    Register("target", self.target_dtype),
                ),
            )
            if self.subspace_bitsize > 0
            else None
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, **soqs: SoquetT
    ) -> dict[str, SoquetT]:
        """@private"""

        target, phase_gradient = soqs.pop("target"), soqs.pop("phase_gradient")
        address = (
            bb.add(
                self._subspace_partition.adjoint(),
                subspace=soqs.pop("subspace"),
                target=target,
            )
            if self._subspace_partition is not None
            else target
        )
        address, phase_gradient, soqs = self._load_and_rotate(
            bb, address, phase_gradient, **soqs
        )
        soqs_f = (
            bb.add_d(self._subspace_partition, x=address)
            if self._subspace_partition is not None
            else {"target": address}
        )
        if self.controlled:
            soqs_f["control"] = soqs.pop("control")

        soqs_f["phase_gradient"] = phase_gradient
        return soqs_f

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        grad_dtype = self.phase_gradient_dtype
        return Counter([self._qroam, RzViaPhaseGradient(grad_dtype, grad_dtype)])

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        return Counter([sum(j.total_qubits() for j in self._qroam.junk_registers)])


_angles_0 = np.array(
    [
        0.9817477,
        5.89048623,
        0.39269908,
        5.10508806,
        6.08683577,
        4.71238898,
        5.49778714,
        2.15984495,
        5.49778714,
        2.55254403,
        5.89048623,
        0.0,
        5.10508806,
    ]
)
_angles_1 = np.array(
    [
        3.14159265,
        1.76714587,
        4.90873852,
        1.17809725,
        0.0,
        4.90873852,
        5.89048623,
        0.58904862,
        5.49778714,
        0.0,
        4.90873852,
        3.53429174,
        2.15984495,
    ]
)


@bloq_example(generalizer=generalizer)
def _zy_rotation() -> ZYRotations:
    return ZYRotations(
        (
            RzRyLayer(_angles_0, _angles_1, False),
            RzRyLayer(_angles_1, _angles_0, False),
        ),
        QUInt(5),
        QFxp(5, 5),
    )


@bloq_example(generalizer=generalizer)
def _y_rotation() -> ZYRotations:
    return ZYRotations(
        (
            RyLayer(_angles_0, False),
            RyLayer(_angles_1, False),
        ),
        QUInt(5),
        QFxp(5, 5),
    )


@bloq_example(generalizer=generalizer)
def _phase() -> Phase:
    return Phase(
        (
            _angles_0,
            _angles_1,
        ),
        QUInt(4),
        QFxp(5, 5),
    )
