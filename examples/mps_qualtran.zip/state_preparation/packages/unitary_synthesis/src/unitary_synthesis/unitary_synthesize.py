# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

from collections import Counter

import numpy as np
from attrs import field, frozen
from isometry.utils import HasLen, HasShape, data_to_tuple, pad
from qualtran import (
    Bloq,
    BloqBuilder,
    QBit,
    QFxp,
    QUInt,
    Register,
    Signature,
    SoquetT,
    bloq_example,
)
from qualtran.bloqs.bookkeeping import Partition
from qualtran.resource_counting import BloqCountDictT, SympySymbolAllocator
from qualtran.symbolics import bit_length, is_symbolic, slen
from qualtran.symbolics.types import HasLength
from scipy.linalg import block_diag

from ._givens_decomposition import (
    decompose_complex,
    decompose_real,
)
from .rotations import Phase, RyLayer, RzRyLayer, ZYRotations
from .uncompute import SignFixUp
from .utils import combine_sign_flips, generalizer


@frozen(cache_hash=True)
class RealNormalForm:
    """
    Normal form of a real unitary matrix given as ``D * R_k * ... * R_0`` where ``D`` is
    a diagonal matrix with entries +/-1. Each ``R`` is a a layer of Ry-rotations of
    either the form (23) or (24) in the Berry et al. paper.
    """

    _layers: tuple[RyLayer, ...]
    """Layers of Ry-rotations."""

    _phases: HasLen = field(eq=lambda x: data_to_tuple(x))
    """Sign of phases for ``D``, ``True`` is ``-1``, ``False`` is ``1``."""

    def is_symbolic(self) -> bool:
        """@private"""
        return is_symbolic(*self._layers, self._phases)

    @classmethod
    def from_matrix(cls, matrix: HasShape) -> "RealNormalForm":
        """Decompose a real unitary ``matrix`` into its normal form."""
        assert matrix.shape[0] == matrix.shape[1], (
            f"Need quadratic matrix. Have {matrix.shape}."
        )
        if is_symbolic(matrix):
            m = matrix.shape[0]
            return cls(
                m * (RyLayer(HasLength(m // 2), True),),
                HasLength(m),
            )
        phases, layers = decompose_real([matrix.astype(np.float64)])  # type: ignore
        return cls(
            tuple(RyLayer(np.asarray(lay.angles_ry), lay.shifted) for lay in layers),
            np.asarray(phases),
        )

    @classmethod
    def from_block_diagonal_matrix(
        cls, blocks: tuple[HasShape, ...]
    ) -> "RealNormalForm":
        """
        Decompose a real unitary block matrix consiting of ``blocks`` into its normal
        form.
        """
        assert all(b.shape[0] == b.shape[1] for b in blocks), (
            f"Need quadratic matrices. Have {[b.shape for b in blocks]}."
        )
        if is_symbolic(*blocks):
            layers, dim = _shaped_blocks_to_rotations(blocks, True)
            return cls(tuple(layers), HasLength(dim))  # type: ignore
        phases, layers = decompose_real(
            tuple(b.astype(np.float64) for b in blocks)  # type: ignore
        )
        return cls(
            tuple(RyLayer(np.asarray(lay.angles_ry), lay.shifted) for lay in layers),
            np.asarray(phases),
        )

    def to_matrix(self) -> np.ndarray:
        """Create a matrix representing the decomposition."""
        if self.is_symbolic():
            raise ValueError("Not implemented for symbolic object.")
        return np.diag((-1) ** self._phases) @ _rotation_matrix(  # type: ignore
            len(self._phases),  # type: ignore
            self._layers,
        )


def _shaped_blocks_to_rotations(
    blocks: tuple[HasShape, ...], ry_only: bool
) -> tuple[list[RyLayer | RzRyLayer], int]:
    """
    Compute rotation layers from the blocks of a symbolically given block-diagonal
    matrix consisting of ``blocks``. If ``ry_only`` is set, the layers are ``RyLayer``,
    otherwise ``RzRyLayer``. Also return the size of the full unitary.
    """
    lens = [b.shape[0] for b in blocks]
    assert all(isinstance(le, int) for le in lens), (
        f"Only support non-symbolic shape. Have {[type(le) for le in lens]}"
    )

    lens = np.array(lens)
    cum_lens = np.cumsum(lens)
    size = cum_lens[-1]

    layers = []
    for i in range(np.max(lens)):
        u = HasLength(cum_lens[np.argwhere(lens > 0)[-1][0]] // 2)
        shifted: bool = i % 2 == 0
        layers.append(RyLayer(u, shifted) if ry_only else RzRyLayer(u, u, shifted))
        lens = lens - 1

    return layers, size


def _rotation_matrix(
    dim: int, layers: tuple[RyLayer, ...] | tuple[RzRyLayer, ...]
) -> np.ndarray:
    """Create the ``dim x dim`` matrix corresponding to the ``layers`` of rotations."""
    matrices = [lay._to_matrix(dim) for lay in layers][::-1]
    matrices = [
        m if m.shape[0] == dim else block_diag(m, np.eye(dim - m.shape[0]))
        for m in matrices
    ]
    return np.linalg.multi_dot(matrices) if len(matrices) > 1 else matrices[0]


@frozen(cache_hash=True)
class ComplexNormalForm:
    """
    Normal form of a complex unitary matrix given as ``D * R_k * ... * R_0`` where ``D``
    is a diagonal matrix ``e^(1j*phases)``. Each ``R`` is a layer of Rz and Ry-rotations
    of either the form (23) or (24) in the Berry et al. paper.
    """

    _layers: tuple[RzRyLayer, ...]
    """Layers of RzRy-Rotations."""

    _phases: HasLen = field(eq=lambda x: data_to_tuple(x))
    """Diagonal phase angles (in radians)."""

    def is_symbolic(self) -> bool:
        """@private"""
        return is_symbolic(*self._layers, self._phases)

    @classmethod
    def from_matrix(cls, matrix: np.ndarray) -> "ComplexNormalForm":
        """Decompose a complex unitary ``matrix`` into its normal form."""
        if is_symbolic(matrix):
            m = matrix.shape[0]
            h = HasLength(m // 2)
            return cls(
                m * (RzRyLayer(h, h, True),),
                HasLength(m),
            )
        phases, layers = decompose_complex([matrix.astype(np.complex128, copy=False)])  # type: ignore
        return cls(
            tuple(
                RzRyLayer(
                    np.asarray(lay.angles_ry), np.asarray(lay.angles_rz), lay.shifted
                )
                for lay in layers
            ),
            np.asarray(phases),
        )

    @classmethod
    def from_block_diagonal_matrix(
        cls, blocks: tuple[np.ndarray, ...]
    ) -> "ComplexNormalForm":
        """
        Decompose a complex unitary block matrix consiting of ``blocks`` into its normal
        form.
        """
        assert all(b.shape[0] == b.shape[1] for b in blocks), (
            f"Need quadratic matrices. Have {[b.shape for b in blocks]}."
        )

        if is_symbolic(*blocks):
            layers, dim = _shaped_blocks_to_rotations(blocks, False)
            return cls(tuple(layers), HasLength(dim))  # type: ignore
        phases, layers = decompose_complex([b.astype(np.complex128) for b in blocks])  # type: ignore
        return cls(
            tuple(
                RzRyLayer(
                    np.asarray(lay.angles_ry), np.asarray(lay.angles_rz), lay.shifted
                )
                for lay in layers
            ),
            np.asarray(phases),
        )

    def to_matrix(self) -> np.ndarray:
        """Create a matrix representing the decomposition."""
        if self.is_symbolic():
            raise ValueError("Not implemented for symbolic object.")
        return np.diag(np.exp(1j * self._phases)) @ _rotation_matrix(  # type: ignore
            len(self._phases),  # type:ignore
            self._layers,
        )


@frozen(cache_hash=True)
class Unitary(Bloq):
    r"""
    Implements an arbitrary unitary (or a family of unitaries).

    The Bloq takes a tuple of unitary square matrices (all of the same dimension)
    saved in a normal form and synthesises a quantum circuit that applies the
    corresponding unitary on a register of size log2(dimension). If
    more than one matrix is provided the i-th unitary is applied for the subspace
    register state being |i>.

    The rotations are applied using a phase-gradient register.
    The unitary may be controlled on a control qubit if ``controlled`` is set.
    The final step fixing sign flips from measuring the QROAM ancilla qubits may be
    disabled by setting ``fix_signs`` to ``False``. Note that this is just for ressource
    estimation purposes as these signs can not be simulated accurately yet (see below).
    The qubit/Toffoli tradeoff in the QROAM can be controlled via
    ``max_qroam_junk_qubits``.

    The decomposition into Givens-rotations follows the references, but the actuall way
    those rotations are applied differs.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. The measurement results are simply discarded. In
    actual implementations the signs of the Ry-Rotation layers must be dynamically
    adjusted! See ``tensor_simulation`` for how those measurements can be treated in
    simulations.

    Registers
    ----------
    - target : ``self.target_dtype``:
        The target register on which the unitary/unitaries act.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations. It is passed through unchanged.

    - subspace : ``QUInt(self.subspace_bitsize)`` (optional):
        Register for selecting subspaces the unitaries are applied to. Only created if
        more than one matrix is supplied.

    - control : ``QBit()`` (optional):
        Qubit that acts as a control qubit for the unitaries. Only created if
        ``controlled`` is set.

    References
    ----------
        An Optimal Design for Universal Multiport Interferometers
        Clements, Humphreys, Metcalf, Kolthammer, Walmsley. 2016.
        (https://arxiv.org/abs/1603.08788).

        Rapid initial state preparation for the quantum simulation of strongly
        correlated molecules
        Berry, Tong, Khattar, White, Kim, Boixo, Lin, Lee, Chan, Babbush, Rubin. 2024
        (https://arxiv.org/abs/2409.11748)
    """

    matrices: tuple[RealNormalForm, ...] | tuple[ComplexNormalForm, ...]
    """
    Tuple of unitary matrices to be implemented in normal forms (one per value in
    subspace).
    """

    target_dtype: QUInt
    """Target datatype for the unitary."""

    phase_gradient_dtype: QFxp
    """Datatype for the phase-gradient register."""

    controlled: bool = False
    """
    If ``True`` a global control qubit named ``control`` is added to the signature. If 
    ``False`` (default) no extra control is added.
    """

    signs_in: HasLen | None = field(eq=lambda x: data_to_tuple(x), default=None)
    """
    Incoming signs for each basis state in the joint ``subspace``+``target`` register. 
    Defaults to ``None``.
    """

    fix_signs: bool = True
    """
    If ``False`` do not 'fix' any sign flips present at the end of the circuit. This 
    makes sense if the signs can be fixed at a later stage. Defaults to ``True``.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum value for k used in any QROAM. If ``None`` compute the optimal value. If 
    ``0`` use QROM.
    """

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor
    simulation. This replaces the X-measurements by unphysical fake X-measurements that
    are independent of the state that is measured and avoid classical controlled
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e.
    no phase flips are applied. Do not use when doing ressource estimates! Defaults to
    ``False``.
    """

    @property
    def shapes_only(self) -> bool:
        "@private"
        return is_symbolic(*self.matrices, self.signs_in)

    @classmethod
    def from_matrices(
        cls,
        matrices: tuple[HasShape, ...],
        target_dtype: QUInt,
        phase_gradient_dtype: QFxp,
        is_complex: bool,
        controlled: bool = False,
        signs_in: HasLen | None = None,
        fix_signs: bool = True,
        max_qroam_junk_qubits: None | int = None,
        tensor_simulation: bool = False,
    ) -> "Unitary":
        """
        Build a unitary from a sequence of unitaries ``matrices``, each corresponding to
        an element in the subspace. If any matric is complex, all normal forms are
        chosen to be complex.
        """
        normal_form = ComplexNormalForm if is_complex else RealNormalForm
        matrices_nf = tuple(normal_form.from_matrix(m) for m in matrices)  # type: ignore

        return cls(
            matrices_nf,  # type: ignore
            target_dtype,
            phase_gradient_dtype,
            controlled,
            signs_in,
            fix_signs,
            max_qroam_junk_qubits,
            tensor_simulation,
        )

    @classmethod
    def from_block_diagonal_matrices(
        cls,
        matrices: tuple[tuple[HasShape, ...], ...],
        target_dtype: QUInt,
        phase_gradient_dtype: QFxp,
        is_complex: bool,
        controlled: bool = False,
        signs_in: HasLen | None = None,
        fix_signs: bool = True,
        max_qroam_junk_qubits: None | int = None,
        tensor_simulation: bool = False,
    ) -> "Unitary":
        """
        Build a unitary from a sequence of block-diagonal unitaries ``matrices``, each
        correspondingto an element in the subspace. If any matric is complex, all normal
        forms are chosen to be complex.
        """
        normal_form = ComplexNormalForm if is_complex else RealNormalForm
        matrices_nf = tuple(normal_form.from_block_diagonal_matrix(m) for m in matrices)  # type: ignore

        return cls(
            matrices_nf,  # type: ignore
            target_dtype,
            phase_gradient_dtype,
            controlled,
            signs_in,
            fix_signs,
            max_qroam_junk_qubits,
            tensor_simulation,
        )

    @property
    def subspace_bitsize(self) -> int:
        """
        Size of the subspace register that holds the indexes of the ``matrices``. Is
        zero if only a single matrix is provided.
        """
        return bit_length(len(self.matrices) - 1)

    def __attrs_post_init__(self):
        assert all(isinstance(m, RealNormalForm) for m in self.matrices) or all(
            isinstance(m, ComplexNormalForm) for m in self.matrices
        ), (
            f"All matrices need to be of the same normal form type. Have {[type(m) for m in self.matrices]}."
        )
        assert 1 << self.subspace_bitsize == len(self.matrices), (
            f"Need {1 << self.subspace_bitsize} many subspace matrices. Have {len(self.matrices)}."
        )
        if self.signs_in is not None:
            assert slen(self.signs_in) == 1 << self._address_bitsize, (
                f"Sign_in length {slen(self.signs_in)} must be {1 << self._address_bitsize}."
            )

    @property
    def signature(self) -> Signature:
        """@private"""
        regs = [
            Register("target", self.target_dtype),
            Register("phase_gradient", self.phase_gradient_dtype),
        ]
        if self.subspace_bitsize > 0:
            regs.append(Register("subspace", QUInt(self.subspace_bitsize)))
        if self.controlled:
            regs.append(Register("control", QBit()))
        return Signature(regs)

    @property
    def signs_out(self) -> HasLen:
        """
        Outgoing signs for each basis state in the joint ``subspace``+``target``
        register.
        """
        if self.shapes_only or not self.fix_signs:
            return self._sign_flips
        return np.zeros(len(self._sign_flips), dtype=bool)  # type: ignore

    @property
    def _is_real(self) -> bool:
        """Check if all unitaries are real."""
        return all(isinstance(matrix, RealNormalForm) for matrix in self.matrices)

    @property
    def _address_bitsize(self) -> int:
        """Joint bitsize of the subspace and target registers."""
        return self.target_dtype.num_bits + self.subspace_bitsize

    @property
    def _subspace_partition(self) -> None | Partition:
        """
        Join the ``subspace`` and ``target`` registers, if a ``subspace`` register
        exists
        """
        return (
            Partition(
                self._address_bitsize,
                (
                    Register("subspace", QUInt(self.subspace_bitsize)),
                    Register("target", self.target_dtype),
                ),
            )
            if self.subspace_bitsize > 0
            else None
        )

    @property
    def _rotations_with_signs(
        self,
    ) -> tuple[list[ZYRotations], HasLen]:
        """ "
        Rotate the incoming signs through the rotations and return both the adapted
        rotation and the outgoing signs.
        """
        signs = self.signs_in
        rotations = []
        for layer_family in zip(*[nf._layers for nf in self.matrices]):
            rot = ZYRotations(
                layer_family,
                self.target_dtype,
                self.phase_gradient_dtype,
                self.controlled,
                signs,
                self.max_qroam_junk_qubits,
                self.tensor_simulation,
            )
            signs = rot.signs_out
            rotations.append(rot)
        return rotations, signs  # type: ignore

    @property
    def _rotation_bloqs(self) -> list[ZYRotations]:
        """Iterator over the ``ZYRotations`` to be applied."""
        return self._rotations_with_signs[0]

    @property
    def _complex_phase_bloq(self) -> Phase | None:
        """Bloq encoding the phases if the matrix is complex."""
        return (
            Phase(
                tuple(nf._phases for nf in self.matrices),
                self.target_dtype,
                self.phase_gradient_dtype,
                self.controlled,
                self._rotations_with_signs[1],
                self.max_qroam_junk_qubits,
                self.tensor_simulation,
            )
            if not self._is_real
            else None
        )

    @property
    def _sign_flips(self) -> HasLen:
        """
        Sign-flips at the end of the circuit. They are corrected if ``fix_signs`` is
        set.
        """
        if self._complex_phase_bloq is not None:
            return self._complex_phase_bloq.signs_out

        target_dim = 1 << self.target_dtype.num_bits
        if self.shapes_only:
            phase_signs = HasLength(len(self.matrices) * target_dim)
        else:
            phase_signs = np.hstack(  # type: ignore
                [pad(nf._phases, target_dim) for nf in self.matrices]
            )
        return combine_sign_flips(phase_signs, self._rotations_with_signs[1])

    @property
    def _sign_fix_up(self) -> SignFixUp:
        """``SingFixUp``-bloq used to fix the signs."""
        return SignFixUp(
            self._sign_flips,
            self.max_qroam_junk_qubits,
            self.controlled,
            self.tensor_simulation,
        )

    def _apply_sign_fix_up(
        self, bb: BloqBuilder, **soqs: SoquetT
    ) -> dict[str, SoquetT]:
        """Apply the sign fix."""
        phase_gradient = soqs.pop("phase_gradient")

        address = (
            bb.add(
                self._subspace_partition.adjoint(),
                subspace=soqs.pop("subspace"),
                target=soqs.pop("target"),
            )
            if self._subspace_partition is not None
            else soqs.pop("target")
        )
        soqs = bb.add_d(self._sign_fix_up, address=address, **soqs)
        if self._subspace_partition is not None:
            soqs["subspace"], soqs["target"] = bb.add(
                self._subspace_partition, x=soqs.pop("address")
            )
        else:
            soqs["target"] = soqs.pop("address")

        soqs["phase_gradient"] = phase_gradient
        return soqs

    def build_composite_bloq(self, bb: BloqBuilder, **soqs):
        """@private"""
        for rot in self._rotation_bloqs:
            soqs = bb.add_d(rot, **soqs)
        if self._complex_phase_bloq is not None:
            soqs = bb.add_d(self._complex_phase_bloq, **soqs)
        if self.fix_signs:
            soqs = self._apply_sign_fix_up(bb, **soqs)
        return soqs

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        c = self._rotation_bloqs
        if self._complex_phase_bloq is not None:
            c += [self._complex_phase_bloq]  # type: ignore
        if self.fix_signs:
            c += [self._sign_fix_up]  # type :ignore
        return Counter(c)

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        c = sum((rot.junk_register_qubits for rot in self._rotation_bloqs), Counter())
        if self._complex_phase_bloq is not None:
            c += self._complex_phase_bloq.junk_register_qubits
        return c


_u_complex = np.array(
    [
        [
            -0.44283246 - 2.32171711e-01j,
            0.10648397 + 1.03629853e-01j,
            -0.04447293 - 5.84125713e-01j,
            -0.42121746 - 1.39079076e-01j,
            -0.40055255 - 1.65914297e-01j,
        ],
        [
            0.64784163 - 1.15434015e-01j,
            -0.27916231 - 4.69515452e-01j,
            -0.03020749 - 3.18092775e-01j,
            -0.19717483 + 3.20333951e-02j,
            -0.27504435 + 2.25723064e-01j,
        ],
        [
            -0.25302003 - 5.91334065e-02j,
            -0.12648374 - 3.04658990e-03j,
            0.4251386 + 3.54577664e-01j,
            0.06618906 - 1.98403669e-01j,
            -0.51332407 + 5.50238067e-01j,
        ],
        [
            -0.17125746 - 3.59026822e-01j,
            0.42784907 - 4.01468040e-01j,
            0.25135583 - 1.84919583e-01j,
            0.36984731 + 5.03385162e-01j,
            0.04938743 + 8.68414213e-02j,
        ],
        [
            0.30203749 - 6.93889390e-18j,
            0.31393741 + 4.69840536e-01j,
            -0.22271786 - 3.18241105e-01j,
            0.53536257 - 2.06850356e-01j,
            -0.22965503 + 2.37580072e-01j,
        ],
    ]
)

_u_real = np.array(
    [
        [-0.47178128, -0.05261335, -0.16270166, -0.76284019, 0.40774658],
        [0.7310845, -0.26745634, 0.42452942, -0.40774658, 0.21794509],
        [-0.31352647, -0.28552311, 0.46909853, -0.27380446, -0.72467606],
        [-0.23548774, 0.5695347, 0.71917363, 0.11341352, 0.30017065],
        [0.29863784, 0.72097553, -0.23672517, -0.40495192, -0.41350315],
    ]
)


_blocks = (
    np.array(
        [
            [-0.06529681, 0.99196206, -0.0314629, -0.10371929],
            [-0.21823697, -0.05352461, -0.97114398, -0.07991947],
            [0.80873407, 0.10145871, -0.23105394, 0.53129032],
            [-0.54227129, 0.05340906, 0.05003537, 0.83701003],
        ]
    ),
    np.array(
        [
            [-0.71416854, -0.29581829, 0.63439328],
            [0.38268343, -0.92387953, -0.0],
            [0.58610297, 0.2427718, 0.77301045],
        ]
    ),
    np.array([[-0.70710678, -0.70710678], [-0.70710678, 0.70710678]]),
    np.array([[1.0]]),
)


@bloq_example(generalizer=generalizer)
def _unitary_blocks() -> Unitary:
    return Unitary.from_block_diagonal_matrices(
        (tuple(b.copy() for b in _blocks),),
        QUInt(4),
        QFxp(6, 6),
        False,
    )


@bloq_example(generalizer=generalizer)
def _unitary_complex() -> Unitary:
    return Unitary.from_matrices((_u_complex.copy(),), QUInt(3), QFxp(6, 6), True)


@bloq_example(generalizer=generalizer)
def _unitary_real() -> Unitary:
    return Unitary.from_matrices((_u_real.copy(),), QUInt(3), QFxp(6, 6), False)


@bloq_example(generalizer=generalizer)
def _unitary_subspace() -> Unitary:
    return Unitary.from_matrices(
        (_u_complex.copy(), _u_real.copy()), QUInt(3), QFxp(6, 6), True
    )
