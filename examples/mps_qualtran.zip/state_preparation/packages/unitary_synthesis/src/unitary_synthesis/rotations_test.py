# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import pytest
from attrs import evolve
from isometry.utils import random_signs
from isometry.utils_test import bloq_autotester_with_counts  # noqa: F401
from qualtran import BloqBuilder, QBit, QUInt, Register
from qualtran.bloqs.rotations import PhaseGradientState
from qualtran.testing import assert_equivalent_bloq_example_counts
from scipy.linalg import block_diag

from .rotations import (
    _phase,
    _y_rotation,
    _zy_rotation,
)


@pytest.mark.parametrize(
    "bloq_ex",
    [_zy_rotation, _y_rotation, _phase],
)
def test_example(bloq_autotester_with_counts, bloq_ex):  # noqa: F811
    bloq_autotester_with_counts(bloq_ex)
    assert_equivalent_bloq_example_counts(bloq_ex)


@pytest.mark.parametrize(
    "signs_in_random",
    [True, False],
)
@pytest.mark.parametrize(
    "controlled",
    [False, True],
)
@pytest.mark.parametrize(
    "bloq_ex",
    [_zy_rotation, _y_rotation],
)
@pytest.mark.parametrize(
    "shifted",
    [True, False],
)
@pytest.mark.parametrize(
    "target_dtype",
    [QUInt(5), QUInt(6)],
)
def test_zy_rotation_subspace(
    signs_in_random, controlled, bloq_ex, shifted, target_dtype
):
    rotations = tuple(evolve(r, shifted=shifted) for r in bloq_ex().rotations)
    signs_in = (
        random_signs(1 << (target_dtype.num_bits + 1), 2341253)
        if signs_in_random
        else None
    )
    rot = evolve(
        bloq_ex(),
        target_dtype=target_dtype,
        rotations=rotations,
        tensor_simulation=True,
        controlled=controlled,
        signs_in=signs_in,
        max_qroam_junk_qubits=0 if (controlled and bloq_ex is _zy_rotation) else None,
    )
    phase_gradient_state = PhaseGradientState(rot.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    if controlled:
        soqs["control"] = bb.add_register(Register("control", QBit()))
    soqs["subspace"] = bb.add_register(Register("subspace", QBit()))
    soqs["target"] = bb.add_register(Register("target", target_dtype))
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(rot, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))

    if controlled:
        bloq = bb.finalize(
            control=soqs.pop("control"),
            subspace=soqs.pop("subspace"),
            target=soqs.pop("target"),
        )
    else:
        bloq = bb.finalize(
            subspace=soqs.pop("subspace"),
            target=soqs.pop("target"),
        )

    block_matrices = [r._to_matrix(1 << target_dtype.num_bits) for r in rot.rotations]
    if controlled:
        block_matrices = [np.eye(1 << (target_dtype.num_bits + 1))] + block_matrices
        signs_out = np.hstack([np.zeros(len(rot.signs_out), dtype=bool), rot.signs_out])
    else:
        signs_out = rot.signs_out

    tensor = np.diag((-1) ** signs_out) @ bloq.tensor_contract()

    if signs_in is not None:
        if controlled:
            signs_in = np.hstack([np.zeros(len(signs_in), dtype=bool), signs_in])

        assert np.allclose(
            block_diag(*block_matrices) @ np.diag((-1) ** signs_in),
            tensor,
        )
    else:
        assert np.allclose(block_diag(*block_matrices), tensor)


@pytest.mark.parametrize(
    "signs_in_random",
    [True, False],
)
@pytest.mark.parametrize(
    "controlled",
    [False, True],
)
@pytest.mark.parametrize(
    "bloq_ex",
    [_zy_rotation, _y_rotation],
)
@pytest.mark.parametrize(
    "i",
    [0, 1],
)
@pytest.mark.parametrize(
    "shifted",
    [True, False],
)
@pytest.mark.parametrize(
    "target_dtype",
    [QUInt(5), QUInt(6)],
)
def test_zy_rotation(signs_in_random, controlled, bloq_ex, i, shifted, target_dtype):
    rotations = (evolve(bloq_ex().rotations[i], shifted=shifted),)
    signs_in = (
        random_signs(1 << target_dtype.num_bits, 2341253) if signs_in_random else None
    )

    rot = evolve(
        bloq_ex(),
        rotations=rotations,
        target_dtype=target_dtype,
        tensor_simulation=True,
        controlled=controlled,
        signs_in=signs_in,
    )
    phase_gradient_state = PhaseGradientState(rot.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    if controlled:
        soqs["control"] = bb.add_register(Register("control", QBit()))
    soqs["target"] = bb.add_register(Register("target", target_dtype))
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(rot, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))

    if controlled:
        bloq = bb.finalize(
            control=soqs.pop("control"),
            target=soqs.pop("target"),
        )
    else:
        bloq = bb.finalize(
            target=soqs.pop("target"),
        )

    block_matrices = [rot.rotations[0]._to_matrix(1 << target_dtype.num_bits)]
    if controlled:
        block_matrices = [np.eye(1 << target_dtype.num_bits)] + block_matrices
        signs_out = np.hstack([np.zeros(len(rot.signs_out), dtype=bool), rot.signs_out])
    else:
        signs_out = rot.signs_out

    tensor = np.diag((-1) ** signs_out) @ bloq.tensor_contract()

    if signs_in is not None:
        if controlled:
            signs_in = np.hstack([np.zeros(len(signs_in), dtype=bool), signs_in])

        assert np.allclose(
            block_diag(*block_matrices) @ np.diag((-1) ** signs_in),
            tensor,
        )
    else:
        assert np.allclose(block_diag(*block_matrices), tensor)


@pytest.mark.parametrize(
    "signs_in",
    [None, random_signs(32, 2341253)],
)
@pytest.mark.parametrize(
    "controlled",
    [False, True],
)
def test_phase_subspace(signs_in, controlled):
    phase = evolve(
        _phase(), tensor_simulation=True, controlled=controlled, signs_in=signs_in
    )
    phase_gradient_state = PhaseGradientState(phase.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    if controlled:
        soqs["control"] = bb.add_register(Register("control", QBit()))

    soqs["subspace"] = bb.add_register(Register("subspace", QBit()))
    soqs["target"] = bb.add_register(Register("target", QUInt(4)))
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(phase, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))

    if controlled:
        bloq = bb.finalize(
            control=soqs.pop("control"),
            subspace=soqs.pop("subspace"),
            target=soqs.pop("target"),
        )
    else:
        bloq = bb.finalize(
            subspace=soqs.pop("subspace"),
            target=soqs.pop("target"),
        )

    angles = [
        phase.phases[0],
        np.zeros(3),
        phase.phases[1],
        np.zeros(3),
    ]
    if controlled:
        angles = [np.zeros(32)] + angles
        signs_out = np.hstack(  # type: ignore
            [np.zeros(len(phase.signs_out), dtype=bool), phase.signs_out]  # type: ignore
        )
    else:
        signs_out = phase.signs_out

    tensor = np.diag((-1) ** signs_out) @ bloq.tensor_contract()  # type: ignore

    if signs_in is not None:
        if controlled:
            signs_in = np.hstack([np.zeros(len(signs_in), dtype=bool), signs_in])

        assert np.allclose(
            np.diag(np.exp(1j * np.hstack(angles))) @ np.diag((-1) ** signs_in),  # type: ignore
            tensor,
        )
    else:
        assert np.allclose(np.diag(np.exp(1j * np.hstack(angles))), tensor)  # type: ignore


@pytest.mark.parametrize(
    "signs_in",
    [None, random_signs(16, 2341253)],
)
@pytest.mark.parametrize(
    "controlled",
    [False, True],
)
@pytest.mark.parametrize(
    "i",
    [0, 1],
)
def test_phase(signs_in, controlled, i):
    phase = evolve(
        _phase(),
        phases=(_phase().phases[i],),
        tensor_simulation=True,
        controlled=controlled,
        signs_in=signs_in,
    )
    phase_gradient_state = PhaseGradientState(phase.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    if controlled:
        soqs["control"] = bb.add_register(Register("control", QBit()))
    soqs["target"] = bb.add_register(Register("target", QUInt(4)))
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(phase, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))

    if controlled:
        bloq = bb.finalize(
            control=soqs.pop("control"),
            target=soqs.pop("target"),
        )
    else:
        bloq = bb.finalize(
            target=soqs.pop("target"),
        )
    angles = [
        phase.phases[0],
        np.zeros(3),
    ]
    if controlled:
        angles = [np.zeros(16)] + angles
        signs_out = np.hstack(  # type: ignore
            [np.zeros(len(phase.signs_out), dtype=bool), phase.signs_out]  # type: ignore
        )
    else:
        signs_out = phase.signs_out

    tensor = np.diag((-1) ** signs_out) @ bloq.tensor_contract()  # type: ignore

    if signs_in is not None:
        if controlled:
            signs_in = np.hstack([np.zeros(len(signs_in), dtype=bool), signs_in])

        assert np.allclose(
            np.diag(np.exp(1j * np.hstack(angles))) @ np.diag((-1) ** signs_in),  # type: ignore
            tensor,
        )
    else:
        assert np.allclose(np.diag(np.exp(1j * np.hstack(angles))), tensor)  # type: ignore
