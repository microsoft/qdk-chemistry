# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import pytest
from attrs import evolve
from isometry.utils import random_signs
from isometry.utils_test import bloq_autotester_with_counts  # noqa: F401
from qualtran import BloqBuilder, QBit, QUInt, Register
from qualtran.bloqs.rotations import PhaseGradientState
from scipy.linalg import block_diag
from scipy.stats import ortho_group, unitary_group

from .unitary_synthesize import (
    ComplexNormalForm,
    RealNormalForm,
    _unitary_blocks,
    _unitary_complex,
    _unitary_real,
    _unitary_subspace,
)


@pytest.mark.parametrize(
    "bloq_ex",
    [
        _unitary_complex,
        _unitary_real,
        _unitary_subspace,
        _unitary_blocks,
    ],
)
def test_example(bloq_autotester_with_counts, bloq_ex):  # noqa: F811
    bloq_autotester_with_counts(bloq_ex)


@pytest.mark.parametrize(
    "fix_signs",
    [True, False],
)
@pytest.mark.parametrize(
    "signs_in",
    [None, random_signs(16, 2341253)],
)
@pytest.mark.parametrize(
    "controlled",
    [False, True],
)
@pytest.mark.parametrize(
    "bloq_ex",
    [
        _unitary_complex,
        _unitary_real,
        _unitary_blocks,
    ],
)
def test_unitary(fix_signs, signs_in, controlled, bloq_ex):
    if bloq_ex != _unitary_blocks and signs_in is not None:
        signs_in = signs_in[:8]
    unitary = evolve(
        bloq_ex(),
        tensor_simulation=True,
        controlled=controlled,
        signs_in=signs_in,
        fix_signs=fix_signs,
    )
    phase_gradient_state = PhaseGradientState(unitary.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    if controlled:
        soqs["control"] = bb.add_register(Register("control", QBit()))
    soqs["target"] = bb.add_register(
        Register("target", QUInt(3 if bloq_ex != _unitary_blocks else 4))
    )
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(unitary, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))

    if controlled:
        bloq = bb.finalize(control=soqs.pop("control"), target=soqs.pop("target"))
    else:
        bloq = bb.finalize(target=soqs.pop("target"))

    block_matrices = [
        unitary.matrices[0].to_matrix(),
        np.eye(3 if bloq_ex != _unitary_blocks else 6),
    ]
    if controlled:
        block_matrices = [
            np.eye(1 << (3 if bloq_ex != _unitary_blocks else 4))
        ] + block_matrices
        signs_out = np.hstack(
            [np.zeros(len(unitary.signs_out), dtype=bool), unitary.signs_out]
        )
    else:
        signs_out = unitary.signs_out

    tensor = np.diag((-1) ** signs_out) @ bloq.tensor_contract()

    if signs_in is not None:
        if controlled:
            signs_in = np.hstack([np.zeros(len(signs_in), dtype=bool), signs_in])
        assert np.allclose(
            block_diag(*block_matrices) @ np.diag((-1) ** signs_in),
            tensor,
        )
    else:
        assert np.allclose(block_diag(*block_matrices), tensor)


@pytest.mark.parametrize(
    "fix_signs",
    [True, False],
)
@pytest.mark.parametrize(
    "signs_in",
    [None, random_signs(16, 2341253)],
)
@pytest.mark.parametrize(
    "controlled",
    [True, False],
)
@pytest.mark.parametrize(
    "bloq_ex",
    [_unitary_subspace],
)
def test_unitary_subspace(fix_signs, signs_in, controlled, bloq_ex):
    unitary = evolve(
        bloq_ex(),
        tensor_simulation=True,
        controlled=controlled,
        signs_in=signs_in,
        fix_signs=fix_signs,
    )
    phase_gradient_state = PhaseGradientState(unitary.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    if controlled:
        soqs["control"] = bb.add_register(Register("control", QBit()))
    soqs["subspace"] = bb.add_register(Register("subspace", QBit()))
    soqs["target"] = bb.add_register(Register("target", QUInt(3)))
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(unitary, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))

    if controlled:
        bloq = bb.finalize(
            control=soqs.pop("control"),
            subspace=soqs.pop("subspace"),
            target=soqs.pop("target"),
        )
    else:
        bloq = bb.finalize(
            subspace=soqs.pop("subspace"),
            target=soqs.pop("target"),
        )

    block_matrices = [
        unitary.matrices[0].to_matrix(),
        np.eye(3),
        unitary.matrices[1].to_matrix(),
        np.eye(3),
    ]
    if controlled:
        block_matrices = [np.eye(1 << 4)] + block_matrices
        signs_out = np.hstack(
            [np.zeros(len(unitary.signs_out), dtype=bool), unitary.signs_out]
        )
    else:
        signs_out = unitary.signs_out

    tensor = np.diag((-1) ** signs_out) @ bloq.tensor_contract()

    if signs_in is not None:
        if controlled:
            signs_in = np.hstack([np.zeros(len(signs_in), dtype=bool), signs_in])

        assert np.allclose(
            block_diag(*block_matrices) @ np.diag((-1) ** signs_in),
            tensor,
        )
    else:
        assert np.allclose(block_diag(*block_matrices), tensor)


@pytest.mark.parametrize(
    "dim",
    [2, 3, 4, 5, 51, 52, 101, 102],
)
def test_complex_normal_form(dim):
    matrix = unitary_group.rvs(dim=dim, random_state=123)
    assert np.allclose(matrix, ComplexNormalForm.from_matrix(matrix.copy()).to_matrix())


@pytest.mark.parametrize(
    "dims", [(2, 5, 51, 52, 3, 4), (23,), (19, 65, 2, 3, 1), (14, 14, 9, 2)]
)
def test_real_normal_form_block(dims):
    matrices = tuple(ortho_group.rvs(dim=dim, random_state=5677) for dim in dims)
    joint_matrix = block_diag(*matrices)
    assert np.allclose(
        joint_matrix,
        RealNormalForm.from_block_diagonal_matrix(matrices).to_matrix(),
    )


@pytest.mark.parametrize(
    "dims", [(2, 5, 51, 52, 3, 4), (23,), (19, 65, 2, 3, 1), (14, 14, 9, 2)]
)
def test_complex_normal_form_block(dims):
    matrices = tuple(unitary_group.rvs(dim=dim, random_state=5677) for dim in dims)
    joint_matrix = block_diag(*matrices)
    assert np.allclose(
        joint_matrix,
        ComplexNormalForm.from_block_diagonal_matrix(matrices).to_matrix(),
    )


@pytest.mark.parametrize(
    "dim",
    [2, 3, 4, 5, 51, 52, 101, 102],
)
def test_real_normal_form(dim):
    matrix = ortho_group.rvs(dim=dim, random_state=5677)
    assert np.allclose(matrix, RealNormalForm.from_matrix(matrix.copy()).to_matrix())


@pytest.mark.parametrize(
    "dim",
    [2, 3, 4, 5, 51, 52, 101, 102],
)
def test_commute_through_phases_ry_rz(dim):
    matrix = unitary_group.rvs(dim=dim, random_state=5677)
    for layer in ComplexNormalForm.from_matrix(matrix)._layers:
        signs = random_signs(dim, seed=2354435)
        layer_evolved = layer.commute_through_phases(signs)
        assert np.allclose(
            layer._to_matrix(dim) @ np.diag((-1) ** signs),
            np.diag((-1) ** signs) @ layer_evolved._to_matrix(dim),
        )


@pytest.mark.parametrize(
    "dim",
    [2, 3, 4, 5, 51, 52, 101, 102],
)
def test_commute_through_phases_ry(dim):
    matrix = ortho_group.rvs(dim=dim, random_state=5677)
    for layer in RealNormalForm.from_matrix(matrix)._layers:
        signs = random_signs(dim, seed=2354435)
        layer_evolved = layer.commute_through_phases(signs)
        assert np.allclose(
            layer._to_matrix(dim) @ np.diag((-1) ** signs),
            np.diag((-1) ** signs) @ layer_evolved._to_matrix(dim),
        )
