# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np
from attrs import field, frozen
from isometry.utils import HasLen, HasShape, data_to_tuple
from qualtran import (
    Bloq,
    BloqBuilder,
    CBit,
    CtrlSpec,
    QBit,
    QUInt,
    Register,
    Side,
    Signature,
    SoquetT,
    bloq_example,
)
from qualtran.bloqs.basic_gates import (
    CNOT,
    CZ,
    Discard,
    Hadamard,
    MeasureX,
    OneEffect,
    OneState,
    TwoBitCSwap,
    XGate,
    ZGate,
)
from qualtran.bloqs.bookkeeping import Partition
from qualtran.bloqs.data_loading import QROM
from qualtran.resource_counting import BloqCountDictT, SympySymbolAllocator
from qualtran.symbolics import bit_length
from qualtran.symbolics.types import HasLength, Shaped, is_symbolic, slen

from .utils import generalizer


@frozen(cache_hash=True)
class SignFixUp(Bloq):
    """
    Given a Boolean vector ``signs`` of length 2^n (where n is the number of
    bits of ``address_dtype``) the Bloq applies sign flips for for all states |i>
    in the address register for which ``signs[i]`` is ``True``.

    This is done with the circuits from the reference.

    Registers
    ----------
    - address : ``self.address_dtype``:
        Register that holds the computational basis states.

    - control : ``QBit()`` (optional):
        Qubit that acts as a control qubit for the uncomputation. Only created if
        ``controlled`` is set.

    References
    ----------
        Qubitization of Arbitrary Basis Quantum Chemistry Leveraging Sparsity and Low
        Rank Factorization
        Berry, Gidney, Motta, McClean, Babbush. 2019.
        https://arxiv.org/abs/1902.02134
    """

    signs: HasLen = field(eq=lambda x: data_to_tuple(x))
    """
    Boolean vector of length 2^n indicating which computational basis states need a 
    sign-flip.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    controlled: bool = False
    """
    If ``True`` a global control qubit named ``control`` is added to the signature. If 
    ``False`` (default) no extra control is added.
    """

    tensor_simulation: bool = False
    """
    Replace the optimized, measurement-based bloq :class:`BinToUnaryAdjoint` to the 
    automatic automatic adjoint of :class:`BinToUnary` in order to allow 
    (non-superoperator) tensor simulation. Defaults to ``False``. Dp not use when doing 
    ressource estimates!
    """

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(self.signs)

    @property
    def address_dtype(self) -> QUInt:
        """Datatype of the address register. Must fit the signs."""
        return QUInt(bit_length(slen(self.signs) - 1))

    def __attrs_post_init__(self):
        assert (1 << self.address_dtype.num_bits) == slen(self.signs), (
            f"Need a sign for each address state. Have {1 << self.address_dtype.num_bits} states, but {slen(self.signs)} signs."
        )

    @property
    def signature(self) -> Signature:
        """@private"""
        regs = []
        if self.controlled:
            regs.append(Register("control", QBit()))
        regs.append(Register("address", self.address_dtype))
        return Signature(regs)

    @property
    def k(self) -> int:
        """The ``k`` used for the QROAM-like construction."""
        k = self.address_dtype.num_bits // 2
        if self.max_qroam_junk_qubits is not None:
            while (1 << k) > self.max_qroam_junk_qubits and k > 0:
                k -= 1
        return k

    def _single_address_qubit(
        self, bb: BloqBuilder, **soqs: SoquetT
    ) -> dict[str, SoquetT]:
        """Fix signs in the case of a single address qubit."""
        # Only have a single address qubit.
        anc = bb.add(OneState())

        if np.array_equal(self.signs, np.array([True, True])):  # type: ignore
            if self.controlled:
                soqs["control"], anc = bb.add(CZ(), q1=soqs.pop("control"), q2=anc)
            else:
                anc = bb.add(ZGate(), q=anc)
        elif np.array_equal(self.signs, np.array([True, False])):  # type: ignore
            address = bb.add(XGate(), q=soqs.pop("address"))
            if self.controlled:
                [address, soqs["control"]], anc = bb.add(
                    CZ().controlled(),
                    q1=[address, soqs.pop("control")],
                    q2=anc,
                )
            else:
                address, anc = bb.add(CZ(), q1=address, q2=anc)
            soqs["address"] = bb.add(XGate(), q=address)
        elif np.array_equal(self.signs, np.array([False, True])):  # type: ignore
            if self.controlled:
                [soqs["control"], soqs["address"]], anc = bb.add(
                    CZ().controlled(),
                    q1=[soqs.pop("control"), soqs.pop("address")],
                    q2=anc,
                )
            else:
                soqs["address"], anc = bb.add(CZ(), q1=soqs.pop("address"), q2=anc)
        bb.add(OneEffect(), q=anc)
        return soqs

    @property
    def _bloq_counter_single_address_qubit(self) -> BloqCountDictT:
        """Count the bloqs for uncomputing with a single address qubit."""
        if self.shapes_only or not np.array_equal(self.signs, np.array([True, True])):  # type: ignore
            return {CZ().controlled() if self.controlled else CZ(): 1}
        return {CZ() if self.controlled else ZGate(): 1}

    @property
    def _fixup_table(self) -> HasLen | tuple[HasShape, ...]:
        """Compute the fix-up table."""
        if self.k == 0:  # eq. 68 in reference
            if self.shapes_only:
                return HasLength(slen(self.signs) // 2)
            pairs = self.signs.reshape(-1, 2)  # type: ignore
            return (pairs[:, 0].astype(np.uint8) << 1) | pairs[:, 1].astype(np.uint8)
        else:
            dim_k = 1 << self.k
            if self.shapes_only:
                return (Shaped((slen(self.signs) // dim_k,)),) * dim_k
            return tuple(
                self.signs[j::dim_k].astype(np.uint8)  # type: ignore
                for j in range(dim_k)
            )

    @property
    def _qrom_qrom(self) -> QROM:
        """QROM for the k=0 case."""
        if self.shapes_only:
            return QROM.build_from_bitsize(
                slen(self._fixup_table), (2,), num_controls=1 if self.controlled else 0
            )
        return QROM.build_from_data(
            self._fixup_table,  # type: ignore
            target_bitsizes=(2,),
            num_controls=1 if self.controlled else 0,
        )

    def _uncompute_with_qrom(
        self, bb: BloqBuilder, **soqs: SoquetT
    ) -> dict[str, SoquetT]:
        """Uncompute the k=0 case."""
        # Figure 5 in reference.
        partition = Partition(
            self.address_dtype.num_bits,
            regs=(
                Register("selection", QUInt(self.address_dtype.num_bits - 1)),
                Register("q", QBit()),
            ),
        )
        selection, q = bb.add(partition, x=soqs.pop("address"))
        u = bb.add(OneState())
        q, u = bb.add(CNOT(), ctrl=q, target=u)
        q = bb.add(Hadamard(), q=q)
        u = bb.add(Hadamard(), q=u)

        par = Partition(2, (Register("u", QBit()), Register("q", QBit())))
        target = bb.add(par.adjoint(), u=u, q=q)
        soqs = bb.add_d(self._qrom_qrom, selection=selection, target0_=target, **soqs)

        u, q = bb.add(par, x=soqs.pop("target0_"))
        u = bb.add(Hadamard(), q=u)
        q = bb.add(Hadamard(), q=q)
        q, u = bb.add(CNOT(), ctrl=q, target=u)
        bb.add(OneEffect(), q=u)
        soqs["address"] = bb.add(
            partition.adjoint(), selection=soqs.pop("selection"), q=q
        )
        return soqs

    @property
    def _bloq_counter_uncompute_with_qrom(self) -> BloqCountDictT:
        """Count the bloqs for uncomputing with QROAM."""
        return {CNOT(): 2, self._qrom_qrom: 1, Hadamard(): 4}

    @property
    def _qrom_qroam(self) -> QROM:
        """QROM for the k>0 case."""
        num_high_qubits = self.address_dtype.num_bits - self.k
        return QROM(
            self._fixup_table,
            (num_high_qubits,),
            (1,) * (1 << self.k),
            num_controls=1 if self.controlled else 0,
        )  # type: ignore

    def _uncompute_with_qroam(
        self, bb: BloqBuilder, **soqs: SoquetT
    ) -> dict[str, SoquetT]:
        """Uncompute the k>0 case."""
        # Figure 6 in reference.
        dim_k = 1 << self.k

        partition = Partition(
            self.address_dtype.num_bits,
            regs=(
                Register("high", QUInt(self.address_dtype.num_bits - self.k)),
                Register("low", QUInt(self.k)),
            ),
        )
        high, low = bb.add(partition, x=soqs.pop("address"))

        low, rest = bb.add(BinToUnary(QUInt(self.k)), address=low)
        rest = bb.split(rest)
        for i in range(dim_k):
            rest[i] = bb.add(Hadamard(), q=rest[i])

        soqs = bb.add_d(
            self._qrom_qroam,
            selection=high,
            **{f"target{i}_": rest[i] for i in range(dim_k)},
            **soqs,
        )
        high = soqs.pop("selection")
        rest = np.array([soqs.pop(f"target{i}_") for i in range(dim_k)])

        for i in range(dim_k):
            rest[i] = bb.add(Hadamard(), q=rest[i])
        rest = bb.join(rest)  # type: ignore
        low = bb.add(
            BinToUnaryAdjoint(QUInt(self.k))
            if not self.tensor_simulation
            else BinToUnary(QUInt(self.k)).adjoint(),
            address=low,
            target=rest,
        )
        soqs["address"] = bb.add(partition.adjoint(), high=high, low=low)
        return soqs

    @property
    def _bloq_counter_uncompute_with_qroam(self) -> BloqCountDictT:
        """Count the bloqs for uncomputing with QROM."""
        bin_to_unitary = BinToUnaryAdjoint(QUInt(self.k))
        return {
            bin_to_unitary: 1,
            bin_to_unitary.adjoint(): 1,
            self._qrom_qroam: 1,
            Hadamard(): 1 << (self.k + 1),
        }

    def build_composite_bloq(
        self, bb: BloqBuilder, **soqs: SoquetT
    ) -> dict[str, SoquetT]:
        """@private"""
        if self.address_dtype.num_bits == 1:
            return self._single_address_qubit(bb, **soqs)
        if self.k == 0:
            return self._uncompute_with_qrom(bb, **soqs)
        return self._uncompute_with_qroam(bb, **soqs)

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        if self.address_dtype.num_bits == 1:
            return self._bloq_counter_single_address_qubit
        if self.k == 0:
            return self._bloq_counter_uncompute_with_qrom
        return self._bloq_counter_uncompute_with_qroam


@frozen(cache_hash=True)
class BinToUnary(Bloq):
    """
    Circuit mapping a binary register to a one-hot unary register, i.e. a state |i>
    from the address register gets mapped to |i>|e_i> where |e_i> is the
    computational basis state with |1> at the i-th qubit.

    This is done with the circuits from the reference.

    Registers
    ----------
    - address : ``self.address_dtype``:
        Register that holds the computational basis states.


    - target : ``self.target_dtype`` (RIGHT side)
        Output unary register that will contain the one-hot encoding after the Bloq.

    References
    ----------
        Qubitization of Arbitrary Basis Quantum Chemistry Leveraging Sparsity and Low
        Rank Factorization
        Berry, Gidney, Motta, McClean, Babbush. 2019.
        https://arxiv.org/abs/1902.02134
    """

    address_dtype: QUInt
    """Datatype of the address register."""

    @property
    def target_dtype(self) -> QUInt:
        """Datatype used for the register storing the binary values."""
        return QUInt(1 << self.address_dtype.num_bits)

    @property
    def signature(self) -> Signature:
        """@private"""

        return Signature(
            [
                Register("address", self.address_dtype),
                Register("target", self.target_dtype, side=Side.RIGHT),
            ]
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, address: SoquetT
    ) -> dict[str, SoquetT]:  # type:ignore
        """@private"""

        # Figure 8 in reference.
        address = bb.split(address)[::-1]  # type: ignore
        target = bb.split(bb.allocate(dtype=self.target_dtype))
        target[0] = bb.add(XGate(), q=target[0])
        for i in range(self.address_dtype.num_bits):
            for j in range(1 << i):
                address[i], target[j], target[j + (1 << i)] = bb.add(
                    TwoBitCSwap(),
                    ctrl=address[i],
                    x=target[j],
                    y=target[j + (1 << i)],
                )

        return {
            "address": bb.join(address[::-1], dtype=self.address_dtype),
            "target": bb.join(target, dtype=self.target_dtype),  # type: ignore
        }

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        return {XGate(): 1, TwoBitCSwap(): (1 << self.address_dtype.num_bits) - 1}


@frozen(cache_hash=True)
class BinToUnaryAdjoint(Bloq):
    """
    Adjoint (inverse) of :class:`BinToUnary` using measurement based uncomputation with
    the circuit from the reference.

    Registers
    ----------
    - address : ``self.address_dtype``:
        Register that holds the computational basis states.


    - target : ``self.target_dtype`` (LEFT side)
        Unary register containing the one-hot encoding.

    References
    ----------
        Qubitization of Arbitrary Basis Quantum Chemistry Leveraging Sparsity and Low
        Rank Factorization
        Berry, Gidney, Motta, McClean, Babbush. 2019.
        https://arxiv.org/abs/1902.02134
    """

    address_dtype: QUInt
    """Datatype of the address register."""

    @property
    def target_dtype(self) -> QUInt:
        """Datatype used for the register storing the binary values."""
        return QUInt(1 << self.address_dtype.num_bits)

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("address", self.address_dtype),
                Register("target", self.target_dtype, side=Side.LEFT),
            ]
        )

    def adjoint(self) -> BinToUnary:
        """@private"""
        return BinToUnary(self.address_dtype)

    def build_composite_bloq(
        self, bb: BloqBuilder, address: SoquetT, target: SoquetT
    ) -> dict[str, SoquetT]:  # type:ignore
        """@private"""
        # Figure 10 in reference.

        target = bb.split(target)  # type: ignore
        address = bb.split(address)[::-1]  # type: ignore
        for i in reversed(range(self.address_dtype.num_bits)):
            for j in range(1 << i):
                target[j + (1 << i)], target[j] = bb.add(
                    CNOT(),
                    ctrl=target[j + (1 << i)],
                    target=target[j],
                )
                c = bb.add(MeasureX(), q=target[j + (1 << i)])
                c, address[i], target[j] = bb.add(
                    CZ().controlled(ctrl_spec=CtrlSpec(qdtypes=(CBit(),))),
                    ctrl=c,
                    q1=address[i],
                    q2=target[j],
                )
                bb.add(Discard(), c=c)
        bb.add(OneEffect(), q=target[0])
        return {"address": bb.join(address[::-1], dtype=self.address_dtype)}

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        w = (1 << self.address_dtype.num_bits) - 1
        return {CNOT(): w, CZ(): w}


@bloq_example(generalizer=generalizer)
def _binary_to_unary() -> BinToUnary:
    return BinToUnary(QUInt(5))


@bloq_example(generalizer=generalizer)
def _binary_to_unary_adj() -> BinToUnaryAdjoint:
    return BinToUnaryAdjoint(QUInt(5))


@bloq_example(generalizer=generalizer)
def _sign_fixup_0() -> SignFixUp:
    return SignFixUp(np.array([True, False, False, True]), max_qroam_junk_qubits=0)


_signs = np.array(
    [
        True,
        False,
        False,
        True,
        True,
        False,
        False,
        True,
        True,
        False,
        False,
        True,
        True,
        False,
        False,
        True,
    ]
)


@bloq_example(generalizer=generalizer)
def _sign_fixup_none() -> SignFixUp:
    return SignFixUp(
        _signs.copy(),
    )


@bloq_example(generalizer=generalizer)
def _sign_fixup_3() -> SignFixUp:
    return SignFixUp(
        _signs.copy(),
        max_qroam_junk_qubits=3,
    )
