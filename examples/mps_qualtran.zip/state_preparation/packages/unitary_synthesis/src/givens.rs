// SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
//
// SPDX-License-Identifier: Apache-2.0

use std::iter::once;
use std::{collections::VecDeque, fmt::Debug};

use faer::{
    c64,
    diag::DiagRef,
    linalg::jacobi::JacobiRotation,
    prelude::ReborrowMut,
    traits::{
        math_utils::{abs, conj, from_f64, mul, neg, one, sub, zero},
        ComplexField,
    },
    MatMut, MatRef,
};
use rayon::iter::ParallelIterator;

/// Abstract a 2x2 matrix.
pub trait TwoByTwoMatrix {
    type EntryType: ComplexField;
    /// Return
    /// (a b)
    /// (c d)
    /// as [a, b, c ,d].
    fn _matrix(&self) -> [[Self::EntryType; 2]; 2];
}

/// Generate Rz and RzRy rotations from Jacobi rotation.
pub trait FromJacobi<T: ComplexField, X: Phase<T>>: Send + Default + TwoByTwoMatrix {
    fn from_jacobi(jacobi: JacobiRotation<T>, phases: &mut [X]) -> Self;
}

/// Store phase. Use booleans for +/-1 phases (false/true) and f64 for the phase angle of general
/// phases.
pub trait Phase<T: ComplexField>: Default + Clone + Send {
    fn add_phase(&mut self, other: T);
    fn _phase(&self) -> T;
}

impl Phase<f64> for bool {
    fn add_phase(&mut self, other: f64) {
        *self ^= other.is_sign_negative();
    }
    fn _phase(&self) -> f64 {
        if *self {
            -1f64
        } else {
            1f64
        }
    }
}

impl Phase<c64> for f64 {
    fn add_phase(&mut self, other: c64) {
        *self += other.arg()
    }
    fn _phase(&self) -> c64 {
        (*self * c64::I).exp()
    }
}

#[derive(Debug, Clone, Copy, Default)]
/// Rz-Ry rotation
/// (cos x  -sin x) (e^(-iy)       0)
/// (sin x   cos x) (0        e^(iy))
/// with x=``ry_angle`` and y=``rz_angle``.
pub struct RzRy {
    /// Rz rotation angle.
    pub rz_angle: f64,
    /// Ry rotation angle.
    pub ry_angle: f64,
}

#[derive(Debug, Clone, Default, Copy)]
/// Ry rotation
/// (cos x  -sin x)
/// (sin x   cos x)
/// with x=``ry_angle``.
pub struct Ry {
    /// Rotation angle.
    pub ry_angle: f64,
}

impl FromJacobi<c64, f64> for RzRy {
    /// Converts a Jacobi rotation (Givens rotation) into RzRy rotation angles.
    /// Given the complex ``jacobi`` rotation with c and s, and diagonal phase rotations ``phases``
    /// with g and f being the angles, find the rotation angles x and y such that
    /// (c  -s.conj)  (e^(ip)       0) -> (e^(if)       0) (cos x  -sin x) (e^(-iy)       0)
    /// (s        c)  (0       e^(iq)) -> (0       e^(ig)) (sin x   cos x) (0        e^(iy))
    /// and update ``phases``.
    /// The number c is guaranteed to be real.
    fn from_jacobi(jacobi: JacobiRotation<c64>, phases: &mut [f64]) -> Self {
        let JacobiRotation { c, s } = jacobi;
        assert_eq!(c.im, 0f64, "The upper left value {} should be real.", c);
        let c = c.re;
        let (s, chi) = s.to_polar();
        let ry_angle = s.atan2(c);

        // Chosing the values as follows satisfies the relation.
        let rz_angle = 0.5 * (phases[1] - phases[0] - chi);
        let rho = phases[0] + phases[1];
        phases[0] = 0.5 * (rho - chi);
        phases[1] = 0.5 * (rho + chi);

        Self { ry_angle, rz_angle }
    }
}

impl FromJacobi<f64, bool> for Ry {
    /// Converts a real Jacobi rotation into an Ry rotation angle.
    /// Given the real ``jacobi`` rotation with c and s, and diagonal phase rotations ``phases``
    /// +/-1 with p and f, find the rotation angle x such that
    /// (c  -s)  (p  0) -> (f  0) (cos x  -sin x)
    /// (s   c)  (0  q) -> (0  g) (sin x   cos x)
    /// and update ``phases``.
    fn from_jacobi(jacobi: JacobiRotation<f64>, phases: &mut [bool]) -> Self {
        let JacobiRotation { c, s } = jacobi;
        let mut ry_angle = s.atan2(c);
        if phases[0] != phases[1] {
            ry_angle = -ry_angle;
        }
        Self { ry_angle }
    }
}

impl<T: ComplexField> TwoByTwoMatrix for JacobiRotation<T> {
    type EntryType = T;
    fn _matrix(&self) -> [[Self::EntryType; 2]; 2] {
        [
            [self.c.clone(), neg(&conj(&self.s))],
            [self.s.clone(), self.c.clone()],
        ]
    }
}

impl TwoByTwoMatrix for Ry {
    type EntryType = f64;
    fn _matrix(&self) -> [[Self::EntryType; 2]; 2] {
        let c = self.ry_angle.cos();
        let s = self.ry_angle.sin();
        [[c, -s], [s, c]]
    }
}

impl TwoByTwoMatrix for RzRy {
    type EntryType = c64;
    fn _matrix(&self) -> [[Self::EntryType; 2]; 2] {
        let one = c64::ONE;
        let c = self.ry_angle.cos() * one;
        let s = self.ry_angle.sin() * one;
        let p = (self.rz_angle * c64::I).exp();
        [[p.conj() * c, -p * s], [p.conj() * s, p * c]]
    }
}

#[derive(Clone, Debug)]
/// A layer of 2x2 rotations of one of the two unshifted/shifted forms of equations (23) and (24) in
/// https://doi.org/10.1103/PRXQuantum.6.020327.
pub struct Layer<R: TwoByTwoMatrix> {
    /// Layer has form (23) -> false or (24) -> true.
    pub shifted: bool,
    /// 2x2 rotations.
    pub rotations: Vec<R>,
}

impl<R: TwoByTwoMatrix> Layer<R> {
    fn new(shifted: bool, rotations: Vec<R>) -> Self {
        Self { shifted, rotations }
    }

    /// Compute the offset of the unshifted/shifted variants.
    fn offset(&self) -> usize {
        if self.shifted {
            1
        } else {
            0
        }
    }

    /// Mutably iterate over the rotations and the index of the upper-left element of the rotations.
    fn enum_iter_mut(&mut self, further_offset: usize) -> impl Iterator<Item = (usize, &mut R)> {
        let offset = self.offset() + further_offset;
        self.rotations
            .iter_mut()
            .enumerate()
            .map(move |(i, rot)| (offset + 2 * i, rot))
    }
}

/// Assert that the ``matrix`` is diagonal and all digaonal entries have absolut value 1.
fn assert_unitary_diagonal<T: ComplexField>(matrix: MatRef<T>, epsilon: f64) {
    let dim = matrix.nrows();
    for i in 0..dim {
        for j in 0..dim {
            let abs_val = abs(&matrix[(i, j)]);

            if i == j {
                assert!(
                    check_eq_t(abs_val, one(), epsilon.sqrt()),
                    "Matrix {:?}",
                    matrix
                );
            } else if i > j {
                assert!(check_eq_t(abs_val, zero(), epsilon), "Matrix {:?}", matrix);
            } else {
                assert!(
                    check_eq_t(abs_val, zero(), epsilon.sqrt()),
                    "Matrix {:?}",
                    matrix
                );
            }
        }
    }
}

/// Add the ``lower`` layer to the ``upper`` layer.
fn add_lower<T: ComplexField>(
    upper: &mut Layer<JacobiRotation<T>>,
    mut lower: Layer<JacobiRotation<T>>,
    diag: DiagRef<T>,
) {
    assert_eq!(
        upper.shifted, lower.shifted,
        "The layers should be both shifted or both unshifted. Have {} and {}",
        upper.shifted, lower.shifted
    );
    lower.rotations.reverse();
    lower
        .enum_iter_mut(2 * upper.rotations.len())
        .for_each(|(i, rot)| {
            rot.s = mul(&rot.s, &diag[i]);
            rot.s = mul(&rot.s, &conj(&diag[i + 1]));
        });

    upper.rotations.extend(lower.rotations);
}

/// Given a unitary ``matrix`` A of dimension d, find a decomposition A = D L_d ... L_1 consisting
/// of Jacobi layers L_i and a final diagonal phase matrix following the method described in
/// https://doi.org/10.1364/OPTICA.3.001460. Check that D is a diagonal unitary up to ``epsilon``.
pub fn jacobi_normal_form<T: ComplexField>(
    mut matrix: MatMut<T>,
    epsilon: f64,
) -> (DiagRef<T>, Vec<Layer<JacobiRotation<T>>>) {
    let dim: usize = matrix.nrows();
    assert_eq!(
        dim,
        matrix.ncols(),
        "Matrix must be square. Have {} rows and {} columns.",
        dim,
        matrix.ncols()
    );

    if dim <= 1 {
        (matrix.diagonal(), vec![])
    } else {
        // Have dim many layers. Distinguish layer left and right of U in Fig. 2 of the
        // reference -> upper/lower
        let num_layers = if dim == 2 { 1 } else { dim };
        let mut layers_upper: Vec<_> = (0..num_layers)
            .map(|i| {
                Layer::<JacobiRotation<T>>::new(!i.is_multiple_of(2), Vec::with_capacity(dim / 2))
            })
            .collect();
        let mut layers_lower: Vec<_> = layers_upper.clone().into_iter().rev().collect();

        for k in 0..dim - 1 {
            if k.is_multiple_of(2) {
                for (i, col_idx) in (0..=k).rev().enumerate() {
                    let row_idx = dim - 1 - i;
                    let (jacobi, _) = JacobiRotation::rotg(
                        matrix[(row_idx, col_idx + 1)].clone(),
                        matrix[(row_idx, col_idx)].clone(),
                    );
                    // transform between different conventions.
                    // note bug: adjoint = transpose and vice versa
                    let jacobi = jacobi.adjoint();
                    jacobi.conjugate().apply_on_the_right_in_place(
                        // take bug into account
                        matrix.rb_mut().two_cols_mut(col_idx, col_idx + 1),
                    );
                    layers_upper[i].rotations.push(jacobi.transpose()); // bring to other side
                }
            } else {
                for (col_idx, row_idx) in (dim - k - 1..dim).enumerate() {
                    let (jacobi, _) = JacobiRotation::rotg(
                        matrix[(row_idx - 1, col_idx)].clone(),
                        matrix[(row_idx, col_idx)].clone(),
                    );
                    // transform between different conventions.
                    let jacobi = jacobi.adjoint();
                    jacobi.apply_on_the_left_in_place(
                        matrix.rb_mut().two_rows_mut(row_idx - 1, row_idx),
                    );
                    layers_lower[col_idx].rotations.push(jacobi.transpose()); // bring to other side
                }
            }
        }

        assert_unitary_diagonal(matrix.as_ref(), epsilon);
        let diag = matrix.diagonal();

        // Combine upper and lower layers.
        layers_upper
            .iter_mut()
            .zip(layers_lower.into_iter().rev())
            .for_each(|(up, lower)| add_lower(up, lower, diag));
        (diag, layers_upper)
    }
}

/// Given a unitary ``matrix`` A of dimension d, find a decomposition A = D L_d ... L_1 consisting
/// of ``R``-layers L_i and a final diagonal phase matrix D of type ``X``. Check that D is a
/// diagonal unitary up to ``epsilon``.
pub fn normal_form<T: ComplexField, X: Phase<T>, R: FromJacobi<T, X>>(
    matrix: MatMut<T>,
    epsilon: f64,
) -> (Vec<X>, VecDeque<Layer<R>>) {
    let dim: usize = matrix.nrows();
    let (diagonal, jacobi_layers) = jacobi_normal_form(matrix, epsilon);

    // Tranform Jacobi rotations into (Rz-)Ry rotations and commute phases through to the end.
    let mut phases = vec![X::default(); dim];
    let r_layers = jacobi_layers
        .into_iter()
        .map(|layer| {
            let shifted = layer.shifted;
            let layer_offset = layer.offset();
            let rotations = layer
                .rotations
                .into_iter()
                .enumerate()
                .map(|(i, jacobi)| {
                    let start = 2 * i + layer_offset;
                    R::from_jacobi(jacobi, &mut phases[start..start + 2])
                })
                .collect();
            Layer::new(shifted, rotations)
        })
        .collect();

    // Combine phases with diagonal.
    phases
        .iter_mut()
        .zip(diagonal.column_vector().iter())
        .for_each(|(p, d)| p.add_phase(d.clone()));
    (phases, r_layers)
}

/// Given a unitary block-diagonal matrix A defined in terms of its ``blocks``, find a decomposition
/// A = D L_d ... L_1 consisting of ``R`` layers L_i and a final diagonal phase matrix D of type
/// ``X``. Check that D is a diagonal unitary up to ``epsilon``.
pub fn normal_form_blocks<'a, T: ComplexField + 'a, X: Phase<T>, R: FromJacobi<T, X> + Debug>(
    blocks: impl ParallelIterator<Item = MatMut<'a, T>>,
    epsilon: f64,
) -> (Vec<X>, Vec<Layer<R>>) {
    let (phases_list, mut decomp_list): (Vec<Vec<X>>, Vec<VecDeque<Layer<R>>>) =
        blocks.map(|mut b| normal_form(b.rb_mut(), epsilon)).unzip();

    // Find the diagonal indices at which each block starts.
    let block_starts: Vec<usize> = once(0)
        .chain(phases_list.iter().scan(0, |sum, x| {
            *sum += x.len();
            Some(*sum)
        }))
        .collect();

    // Find greatest block and check if its first layer is shifted or not.
    let max_block_idx = phases_list
        .iter()
        .enumerate()
        .max_by_key(|(_, p)| p.len())
        .map(|(i, _)| i)
        .expect("No blocks provided.");

    let mut global_shifted = decomp_list[max_block_idx]
        .front()
        .map(|l| l.shifted)
        .unwrap_or(false)
        ^ (!block_starts[max_block_idx].is_multiple_of(2));

    let total_len = *block_starts.last().unwrap_or(&0);

    // Join layers from blocks.
    let mut final_layers = Vec::new();
    while decomp_list.iter().any(|l| !l.is_empty()) {
        let current_offset = if global_shifted { 1usize } else { 0 };

        // Filter out the rotations from the leading layer of each block that are aligned.
        let mut rotations_with_gaps = decomp_list
            .iter_mut()
            .zip(&block_starts)
            .filter(|(layers, start)| {
                !layers.is_empty()
                    && (layers[0].offset() + *start + current_offset).is_multiple_of(2)
            })
            .flat_map(|(layers, start)| {
                let layer = layers.pop_front().unwrap();
                let layer_offset = layer.offset();
                layer
                    .rotations
                    .into_iter()
                    .enumerate()
                    .map(move |(i, rot)| (start + layer_offset + 2 * i, rot))
            })
            .peekable();

        // Fill gaps with trivial rotations.
        let rotations = (current_offset..total_len - 1)
            .step_by(2)
            .map(|i| {
                if rotations_with_gaps.peek().is_some_and(|(idx, _)| *idx == i) {
                    rotations_with_gaps.next().unwrap().1
                } else {
                    R::default()
                }
            })
            .collect();
        final_layers.push(Layer::new(global_shifted, rotations));
        global_shifted = !global_shifted;
    }

    (phases_list.into_iter().flatten().collect(), final_layers)
}

fn check_eq_t<T: ComplexField>(a: T, b: T, epsilon: f64) -> bool {
    let diff = sub(&a, &b);
    abs(&diff) < from_f64(epsilon)
}

#[cfg(test)]
mod tests {
    use super::*;
    use faer::{
        c64,
        rand::{rng, Rng},
        Col, Mat, MatRef,
    };
    use rayon::iter::IntoParallelRefMutIterator;
    use std::f64::consts::PI;

    impl<R: TwoByTwoMatrix + Debug> Layer<R> {
        /// For testing build the block diagonal matrix. Expand to ``dim```.
        fn to_matrix(&self, dim: usize) -> Mat<<R as TwoByTwoMatrix>::EntryType> {
            let mut mat = Mat::identity(dim, dim);
            let offset = if self.shifted { 1usize } else { 0 };
            assert!(
                dim >= 2 * self.rotations.len() + offset,
                "Dimension {} must fit {} rotations (shifted: {}): {:?}",
                dim,
                self.rotations.len(),
                self.shifted,
                self.rotations,
            );

            for (i, rot) in (offset..dim).step_by(2).zip(self.rotations.iter()) {
                mat[(i, i)] = rot._matrix()[0][0].clone();
                mat[(i, i + 1)] = rot._matrix()[0][1].clone();
                mat[(i + 1, i)] = rot._matrix()[1][0].clone();
                mat[(i + 1, i + 1)] = rot._matrix()[1][1].clone();
            }
            mat
        }
    }

    /// Assert that ``a`` and ``b`` are equal up to ``epsilon``.
    fn assert_matrix_approx_eq<T: ComplexField>(
        given: MatRef<T>,
        expected: MatRef<T>,
        epsilon: f64,
    ) {
        assert_eq!(given.nrows(), expected.nrows());
        assert_eq!(given.ncols(), expected.ncols());
        for i in 0..given.nrows() {
            for j in 0..given.ncols() {
                assert!(
                    check_eq_t(given[(i, j)].clone(), expected[(i, j)].clone(), epsilon),
                    "Left {:?}, Right {:?}",
                    given,
                    expected
                )
            }
        }
    }

    /// Creates a random complex unitary matrix using QR decomposition.
    fn random_unitary_complex(dim: usize) -> Mat<c64> {
        let mut rng = rng();
        let mut a = Mat::zeros(dim, dim);
        for i in 0..dim {
            for j in 0..dim {
                a[(i, j)] = c64::new(rng.random(), rng.random());
            }
        }
        a.qr().compute_Q()
    }

    /// Creates a random real unitary matrix using QR decomposition.
    fn random_unitary_real(dim: usize) -> Mat<f64> {
        let mut rng = rng();
        let mut a: Mat<f64> = Mat::zeros(dim, dim);
        for i in 0..dim {
            for j in 0..dim {
                a[(i, j)] = rng.random();
            }
        }
        a.qr().compute_Q()
    }

    /// Reconstructs a matrix from phases and rotation layers.
    fn reconstruct_matrix<T: ComplexField, R: TwoByTwoMatrix<EntryType = T> + Debug>(
        phases: DiagRef<T>,
        layers: impl IntoIterator<Item = Layer<R>>,
        dim: usize,
    ) -> Mat<T> {
        let mut result = Mat::identity(dim, dim);
        for layer in layers {
            let layer_mat = layer.to_matrix(dim);
            result = layer_mat.clone() * result;
        }
        result = phases * result;
        result
    }

    /// Build a block‑diagonal matrix from a list of square matrices.
    fn block_diagonal<'a, T: ComplexField + 'a>(
        blocks: impl Iterator<Item = MatRef<'a, T>> + Clone,
    ) -> Mat<T> {
        let total_dim: usize = blocks.clone().map(|b| b.nrows()).sum();
        let mut out = Mat::zeros(total_dim, total_dim);
        let mut offset = 0usize;
        for b in blocks {
            let n = b.nrows();
            out.submatrix_mut(offset, offset, n, n).copy_from(&b);
            offset += n;
        }
        out
    }

    #[test]
    fn test_from_jacobi_ry() {
        let mut rng = rng();
        let c = rng.random_range(-1f64..1f64);
        let s = (1. - c * c).sqrt();
        for jacobi in [
            JacobiRotation { c: 1.0, s: 0.0 },
            JacobiRotation { c: -1.0, s: 0.0 },
            JacobiRotation { c: 0.0, s: 1.0 },
            JacobiRotation { c: 0.0, s: -1.0 },
            JacobiRotation { c, s },
            JacobiRotation { c, s: -s },
            JacobiRotation { c: -c, s: -s },
            JacobiRotation { c: -c, s },
        ] {
            for mut phases in [[true, true], [true, false], [false, true], [false, false]] {
                let jac = Layer::new(false, vec![jacobi]).to_matrix(2);
                let phases_before =
                    Col::from_iter(phases.iter().map(|p| p._phase())).into_diagonal();

                let before = jac * phases_before;
                let ry = Layer::new(false, vec![Ry::from_jacobi(jacobi, &mut phases)]).to_matrix(2);

                let phases_after =
                    Col::from_iter(phases.iter().map(|p| p._phase())).into_diagonal();
                let after = phases_after * ry;
                assert_matrix_approx_eq(before.as_ref(), after.as_ref(), 1e-12);
            }
        }
    }

    #[test]
    fn test_from_jacobi_rzry() {
        let mut rng = rng();
        let c = rng.random_range(-1f64..1.);
        let s = (1. - c * c).sqrt();
        let c = c * c64::ONE;
        let s = (rng.random_range(0f64..2. * PI) * c64::I).exp() * s;
        for jacobi in [
            JacobiRotation {
                c: c64::ONE,
                s: c64::ZERO,
            },
            JacobiRotation {
                c: -c64::ONE,
                s: c64::ZERO,
            },
            JacobiRotation {
                c: c64::ZERO,
                s: c64::ONE,
            },
            JacobiRotation {
                c: c64::ZERO,
                s: -c64::ONE,
            },
            JacobiRotation {
                c: c64::ZERO,
                s: c64::I,
            },
            JacobiRotation {
                c: c64::ZERO,
                s: -c64::I,
            },
            JacobiRotation { c, s },
            JacobiRotation { c, s: -s },
            JacobiRotation { c: -c, s: -s },
            JacobiRotation { c: -c, s },
        ] {
            for mut phases in [
                [0., PI],
                [0., -PI],
                [0., 0.],
                [PI, 0.],
                [-PI, 0.],
                [PI, PI],
                [-PI, -PI],
                [PI, -PI],
                [-PI, PI],
                [
                    rng.random_range(0f64..2. * PI),
                    rng.random_range(0f64..2. * PI),
                ],
            ] {
                let jac = Layer::new(false, vec![jacobi]).to_matrix(2);
                let phases_before =
                    Col::from_iter(phases.iter().map(|p| p._phase())).into_diagonal();

                let before = jac * phases_before;
                let ry =
                    Layer::new(false, vec![RzRy::from_jacobi(jacobi, &mut phases)]).to_matrix(2);
                let phases_after =
                    Col::from_iter(phases.iter().map(|p| p._phase())).into_diagonal();
                let after = phases_after * ry;
                assert_matrix_approx_eq(before.as_ref(), after.as_ref(), 1e-12);
            }
        }
    }

    #[test]
    fn test_jacobi_normal_form_real() {
        for dim in [1, 2, 3, 4, 5, 6, 11, 12, 51, 52] {
            let unitary = random_unitary_real(dim);
            let mut mat = unitary.clone();
            let (diag, layers) = jacobi_normal_form(mat.as_mut(), 1e-12);

            let reconstructed = reconstruct_matrix(diag, layers, dim);
            assert_matrix_approx_eq(reconstructed.as_ref(), unitary.as_ref(), 1e-10);
        }
    }

    #[test]
    fn test_jacobi_normal_form_complex() {
        for dim in [1, 2, 3, 4, 5, 6, 11, 12, 51, 52] {
            let unitary = random_unitary_complex(dim);
            let mut mat = unitary.clone();
            let (diag, layers) = jacobi_normal_form(mat.as_mut(), 1e-12);

            let reconstructed = reconstruct_matrix(diag, layers, dim);
            assert_matrix_approx_eq(reconstructed.as_ref(), unitary.as_ref(), 1e-10);
        }
    }

    #[test]
    fn test_ry_normal_form_real() {
        for dim in [1, 2, 3, 4, 5, 6, 11, 12, 51, 52] {
            let unitary = random_unitary_real(dim);
            let mut mat = unitary.clone();
            let (diag, layers) = normal_form::<f64, bool, Ry>(mat.as_mut(), 1e-12);
            let d = Col::from_iter(diag.iter().map(|p| p._phase())).into_diagonal();

            let reconstructed = reconstruct_matrix(d.as_ref(), layers, dim);
            assert_matrix_approx_eq(reconstructed.as_ref(), unitary.as_ref(), 1e-10);
        }
    }

    #[test]
    fn test_rzry_normal_form_complex() {
        for dim in [1, 2, 3, 4, 5, 6, 11, 12, 51, 52] {
            let unitary = random_unitary_complex(dim);
            let mut mat = unitary.clone();
            let (diag, layers) = normal_form::<c64, f64, RzRy>(mat.as_mut(), 1e-12);
            let d = Col::from_iter(diag.iter().map(|p| p._phase())).into_diagonal();

            let reconstructed = reconstruct_matrix(d.as_ref(), layers, dim);
            assert_matrix_approx_eq(reconstructed.as_ref(), unitary.as_ref(), 1e-10);
        }
    }

    #[test]
    fn test_ry_normal_form_block_real() {
        for dims in [
            vec![1, 2, 2, 3, 4, 5, 11, 10],
            vec![1],
            vec![2],
            vec![3],
            vec![1, 1],
            vec![2, 2],
            vec![1, 2],
            vec![4, 3],
            vec![4, 3],
            vec![1, 2, 2, 1],
            vec![1, 3, 3, 4],
            vec![12, 11, 3, 11, 4],
            vec![5, 4, 3, 2, 1, 1],
            vec![2, 1, 2],
            vec![3, 1, 4, 1, 5, 9],
        ] {
            let mut matrices: Vec<Mat<f64>> =
                dims.iter().map(|i| random_unitary_real(*i)).collect();

            let mat = block_diagonal(matrices.iter().map(|m| m.as_ref()));

            let (diag, layers) = normal_form_blocks::<f64, bool, Ry>(
                matrices.par_iter_mut().map(|m| m.as_mut()),
                1e-12,
            );
            let d = Col::from_iter(diag.iter().map(|p| p._phase())).into_diagonal();

            let reconstructed = reconstruct_matrix(d.as_ref(), layers, dims.iter().sum());
            assert_matrix_approx_eq(reconstructed.as_ref(), mat.as_ref(), 1e-10);
        }
    }

    #[test]
    fn test_rzry_normal_form_block_complex() {
        for dims in [
            vec![1, 2, 2, 3, 4, 5, 11, 10],
            vec![1],
            vec![2],
            vec![3],
            vec![1, 1],
            vec![2, 2],
            vec![1, 2],
            vec![4, 3],
            vec![4, 3],
            vec![1, 2, 2, 1],
            vec![1, 3, 3, 4],
            vec![12, 11, 3, 11, 4],
            vec![5, 4, 3, 2, 1, 1],
            vec![2, 1, 2],
            vec![3, 1, 4, 1, 5, 9],
        ] {
            let mut matrices: Vec<Mat<c64>> =
                dims.iter().map(|i| random_unitary_complex(*i)).collect();

            let mat = block_diagonal(matrices.iter().map(|m| m.as_ref()));

            let (diag, layers) = normal_form_blocks::<c64, f64, RzRy>(
                matrices.par_iter_mut().map(|m| m.as_mut()),
                1e-12,
            );
            let d = Col::from_iter(diag.iter().map(|p| p._phase())).into_diagonal();

            let reconstructed = reconstruct_matrix(d.as_ref(), layers, dims.iter().sum());
            assert_matrix_approx_eq(reconstructed.as_ref(), mat.as_ref(), 1e-10);
        }
    }
}
