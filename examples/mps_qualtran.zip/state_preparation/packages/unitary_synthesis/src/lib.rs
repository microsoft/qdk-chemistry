// SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
//
// SPDX-License-Identifier: Apache-2.0

use faer::{c64, mat::AsMatMut};
use faer_ext::IntoFaer;
use numpy::PyReadonlyArray2;
use pyo3::prelude::*;

mod givens;

const EPSILON: f64 = 1e-12;

use givens::{normal_form_blocks, Layer, Ry, RzRy};
use rayon::iter::{IntoParallelRefMutIterator, ParallelIterator};

/// Given a complex block-diagonal unitary ``U`` consisting of ``block_matrices``, create a
/// decomposition ``U = ``D * R_k * ... * R_0`` where ``D`` is a diagonal matrix ``e^(1j*phases)``.
/// Each ``R`` is a layer of Rz and Ry-rotations of either the form (23) or (24) in the Berry et al.
/// paper. Return the phase angles ``phases`` and the RzRy-layers.
#[pyfunction]
fn decompose_complex(block_matrices: Vec<PyReadonlyArray2<c64>>) -> (Vec<f64>, Vec<RzRyLayerData>) {
    let mut block_matrices: Vec<_> = block_matrices
        .into_iter()
        .map(|b| b.into_faer().to_owned())
        .collect();
    let (phases, ry_layers) = normal_form_blocks::<c64, f64, RzRy>(
        block_matrices.par_iter_mut().map(|b| b.as_mat_mut()),
        EPSILON,
    );
    (
        phases,
        ry_layers
            .into_iter()
            .map(RzRyLayerData::from_rzry_layer)
            .collect(),
    )
}

/// Given a real block-diagonal unitary ``U`` consisting of ``block_matrices``, create a
/// decomposition ``U = ``D * R_k * ... * R_0`` where ``D`` is a diagonal matrix with entries +/-1
/// (``false``/``true``). Each ``R`` is a a layer of RzRy-rotations of either the form (23) or (24)
/// in the Berry et al. paper.
#[pyfunction]
fn decompose_real(block_matrices: Vec<PyReadonlyArray2<f64>>) -> (Vec<bool>, Vec<RyLayerData>) {
    let mut block_matrices: Vec<_> = block_matrices
        .into_iter()
        .map(|b| b.into_faer().to_owned())
        .collect();
    let (phases, ry_layers) = normal_form_blocks::<f64, bool, Ry>(
        block_matrices.par_iter_mut().map(|b| b.as_mat_mut()),
        EPSILON,
    );
    (
        phases,
        ry_layers
            .into_iter()
            .map(RyLayerData::from_ry_layer)
            .collect(),
    )
}

/// Data of a layer of ``Ry * Rz`` rotations of the form equ. (23) in the Berry et al. paper if
/// ``shifted`` is ``False`` and (24) if ``True``.
#[pyclass(frozen)]
#[derive(Clone, Debug)]
pub struct RzRyLayerData {
    #[pyo3(get)]
    /// The ``Rz`` rotation angles (in radians) for each rotation in the layer.
    angles_rz: Vec<f64>,
    #[pyo3(get)]
    /// The ``Ry`` rotation angles (in radians) for each rotation in the layer.
    angles_ry: Vec<f64>,
    #[pyo3(get)]
    /// Indicate whether the layer is shifted by one, i.e. if it has the form (24) instead of (23)
    /// in the reference.
    shifted: bool,
}

#[pymethods]
impl RzRyLayerData {
    fn __repr__(&self) -> PyResult<String> {
        Ok(format!("{:?}", self))
    }
}

impl RzRyLayerData {
    fn from_rzry_layer(layer: Layer<RzRy>) -> Self {
        let Layer { shifted, rotations } = layer;
        Self {
            angles_ry: rotations.iter().map(|rot| rot.ry_angle).collect(),
            angles_rz: rotations.iter().map(|rot| rot.rz_angle).collect(),
            shifted,
        }
    }
}

/// Data of a layer of ``Ry`` rotations of the form equ. (23) in the Berry et al. paper if
/// ``shifted`` is ``False`` and (24) if ``True``.
#[pyclass(frozen)]
#[derive(Clone, Debug)]
pub struct RyLayerData {
    #[pyo3(get)]
    /// The ``Ry`` rotation angles (in radians) for each rotation in the layer.
    angles_ry: Vec<f64>,
    #[pyo3(get)]
    /// Indicate whether the layer is shifted by one, i.e. if it has the form (24) instead of (23)
    /// in the reference.
    shifted: bool,
}

#[pymethods]
impl RyLayerData {
    fn __repr__(&self) -> PyResult<String> {
        Ok(format!("{:?}", self))
    }
}

impl RyLayerData {
    fn from_ry_layer(layer: Layer<Ry>) -> Self {
        let Layer { shifted, rotations } = layer;
        Self {
            angles_ry: rotations.iter().map(|rot| rot.ry_angle).collect(),
            shifted,
        }
    }
}

#[pymodule]
fn _givens_decomposition(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(decompose_complex, m)?)?;
    m.add_function(wrap_pyfunction!(decompose_real, m)?)?;
    m.add_class::<RyLayerData>()?;
    m.add_class::<RzRyLayerData>()?;
    Ok(())
}
