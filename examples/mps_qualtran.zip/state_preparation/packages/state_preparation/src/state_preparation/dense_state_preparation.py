# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

from collections import Counter
from functools import cached_property

import numpy as np
from attrs import field, frozen
from isometry import random_signs
from isometry.utils import HasLen, data_to_tuple
from qualtran import (
    Bloq,
    BloqBuilder,
    CtrlSpec,
    QFxp,
    QUInt,
    Register,
    Side,
    Signature,
    SoquetT,
    bloq_example,
)
from qualtran.bloqs.arithmetic import XorK
from qualtran.bloqs.basic_gates import OneEffect, OneState
from qualtran.bloqs.bookkeeping import Partition
from qualtran.bloqs.data_loading.qroam_clean import QROAMClean
from qualtran.bloqs.rotations import RzViaPhaseGradient
from qualtran.resource_counting import BloqCountDictT, SympySymbolAllocator
from qualtran.symbolics import HasLength, bit_length, is_symbolic, slen
from unitary_synthesis import MeasureInX, RyRotation, SignFixUp
from unitary_synthesis.utils import (
    QROAMCleanExactCSwap,
    angle_to_binary,
    clear_qroam_junk_registers,
    generalizer,
    set_qroam_max_junk_size,
)


@frozen(cache_hash=True)
class DenseStatePreparationViaQROAM(Bloq):
    r"""
    Prepare a dense quantum state using a Grover-Rudolph style algorithm.

    The basis construction follows the first reference with modifications mainly in the
    way uncomputation is treated.

    The qubit/Toffoli tradeoff in the QROAMs can be controlled via
    ``max_qroam_junk_qubits``.

    As Qualtrans capabilities for processing classical measurement results are just
    starting to grow, the Bloq does not implement the classical logic of calculating the
    sign-flips for the individual basis states caused by X-measuring the target
    registers of QRO(A)Ms. The measurement results are simply discarded. See
    ``tensor_simulation_random`` for how those measurements can be treated in
    simulations.

    Registers
    ----------
    - state : ``self.state_dtype`` (RIGHT side):
        The output register that will contain the prepared quantum state.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations.  It is passed through unchanged.

    References
    ----------
        Trading T-gates for dirty qubits in state preparation and unitary synthesis
        Low, Kliuchnikov, Schaeffer. 2018.
        (https://arxiv.org/abs/1812.00954).

        Rapid initial state preparation for the quantum simulation of strongly
        correlated molecules
        Berry, Tong, Khattar, White, Kim, Boixo, Lin, Lee, Chan, Babbush, Rubin. 2024
        (https://arxiv.org/abs/2409.11748)

        Sparse quantum state preparation with improved Toffoli cost
        Rupprecht, Wölk. 2026.
        (https://arxiv.org/abs/2601.09388).
    """

    coefficients: HasLen = field(eq=lambda x: data_to_tuple(x))
    """Classical vector (complex/real) containing the target amplitudes."""

    phase_gradient_dtype: QFxp
    """
    Datatype used for the phase-gradient register determining the accuracy of the 
    rotations.
    """

    prepare_only_amplitudes: bool = False
    """
    If ``True`` stop after the amplitude-preparation. The phase information must then be 
    encoded outside of the bloq. Defaults to ``False``.
    """

    fix_signs: bool = True
    """
    If ``True`` uncompute the signs introduced by the mesurements used for clearing the 
    registers that are targets of QROAM. If ``False`` this must be done outside of the 
    bloq.  Defaults to ``True``.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    tensor_simulation_random: bool | None = None
    """
    If not ``None`` (default) make the Bloq (and sub-Bloqs) suitable for 
    (non-superoperator) tensor simulation. This replaces the X-measurements by 
    unphysical fake X-measurements that are independent of the state that is measured 
    and avoid classical controlled operations. If ``False`` each X-measurement result is 
    assumed to be deterministically |+>, i.e. no phase flips are applied. If ``True`` 
    with probability 0.5 measure |+> or |->, independet of the actual state. Do not use
    when doing ressource estimates!
    """

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(self.coefficients)

    def __attrs_post_init__(self):
        assert isinstance(slen(self.coefficients), int), (
            "Can only have non-symbolic integer as coefficient length."
        )
        if not self.shapes_only:
            assert np.isclose(np.linalg.norm(self.coefficients), 1), (  # type: ignore
                f"The state must be normalized. Have norm {np.linalg.norm(self.coefficients)}"  # type: ignore
            )

    @property
    def state_dtype(self) -> QUInt:
        """Datatype of the state to prepare."""
        return QUInt(bit_length(slen(self.coefficients) - 1))

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("state", self.state_dtype, side=Side.RIGHT),
                Register("phase_gradient", self.phase_gradient_dtype),
            ]
        )

    @property
    def signs_out(self) -> HasLen:
        """Potential sign of each basis state in the ``target`` register."""
        if self.shapes_only or not self.fix_signs:
            return self._sign_flips_qroam
        return np.zeros(len(self._sign_flips_qroam), dtype=bool)  # type: ignore

    @property
    def _state_dim(self) -> int:
        """Dimension of the space of the state qubits."""
        return 1 << self.state_dtype.num_bits

    @property
    def _sign_flips_qroam(self) -> HasLen:
        """Get random sign flips, imitating the flips caused by X-measurements."""
        if self.shapes_only:
            return HasLength(self._state_dim)
        elif self.tensor_simulation_random is not None:
            return np.zeros(self._state_dim, dtype=bool)
        # TODO: Compute the values from the X-measurements using classical registers.
        # If self.uncompute is True make the data available to following bloqs via a
        # classical register.
        return random_signs(self._state_dim, seed=1999999)

    @cached_property
    def _phase_angles(self) -> HasLen:
        """Rotation angles for preparing the phase."""
        if self.shapes_only:
            return HasLength(slen(self.coefficients))

        with np.errstate(divide="ignore", invalid="ignore"):
            phases = np.where(
                self.coefficients != 0,
                self.coefficients / np.abs(self.coefficients),  # type: ignore
                0,
            )  # safe division

        return angle_to_binary(
            np.angle(phases), self.phase_gradient_dtype.num_bits
        ).astype(int)

    @cached_property
    def _amplitude_angles(self) -> np.ndarray:
        """Rotation angles for preparing the amplitudes."""
        # Get |a|^2 for all coefficients a.
        coeff_probabilities = np.abs(self.coefficients) ** 2  # type: ignore

        coeff_probabilities = np.hstack(
            [np.zeros(coeff_probabilities.shape), coeff_probabilities]
        )

        # Fill left half with p_y's in eq (9) in the reference.
        for i in range(self._state_dim - 1, 0, -1):
            coeff_probabilities[i] = (
                coeff_probabilities[i << 1] + coeff_probabilities[(i << 1) | 1]
            )

        angles = coeff_probabilities
        for q in range(self.state_dtype.num_bits):
            for el in range(1 << q, 1 << (q + 1)):
                # Get coefficient from equ. (9) and calculate angle.
                angle = np.arccos(
                    np.sqrt(angles[el << 1] / angles[el] if angles[el] != 0 else 0)
                )
                angles[el] = angle_to_binary(angle, self.phase_gradient_dtype.num_bits)

        return angles[: self._state_dim].astype(int)

    def _qroam_amplitudes(self, i: int) -> QROAMClean:
        """QROAMs for loading the amplitude angles."""
        if self.shapes_only:
            qroam = QROAMCleanExactCSwap.build_from_bitsize(
                1 << i, target_bitsizes=(self.phase_gradient_dtype.num_bits,)
            )
        else:
            qroam = QROAMCleanExactCSwap.build_from_data(
                self._amplitude_angles[1 << i : 1 << (i + 1)],
                target_bitsizes=(self.phase_gradient_dtype.num_bits,),
            )
        return set_qroam_max_junk_size(qroam, self.max_qroam_junk_qubits)

    @property
    def _xork_amplitude(self) -> XorK:
        """The XorK used for setting the first angles."""
        val = 0 if self.shapes_only else self._amplitude_angles[1]
        return XorK(self.phase_gradient_dtype, val)

    def _prepare_amplitudes_bloq(
        self, bb: BloqBuilder, state: SoquetT, phase_gradient: SoquetT
    ) -> tuple[SoquetT, SoquetT]:
        """Bloq encoding the amplitudes of the state"""

        # See Figure 8 in our Paper.
        for i in range(self.state_dtype.num_bits):
            if i == 0:
                angles = bb.add(
                    self._xork_amplitude,
                    x=bb.allocate(dtype=self.phase_gradient_dtype),
                )
            else:
                partition = Partition(
                    n=self.state_dtype.num_bits,
                    regs=(
                        Register("active", QUInt(i)),
                        Register("passive", QUInt(self.state_dtype.num_bits - i)),
                    ),
                )
                active, passive = bb.add(partition, x=state)

                soqs = bb.add_d(self._qroam_amplitudes(i), selection=active)
                active, angles = soqs.pop("selection"), soqs.pop("target0_")
                soqs = clear_qroam_junk_registers(
                    bb, self.phase_gradient_dtype, self.tensor_simulation_random, **soqs
                )  # TODO: Collect measurement results in classical register and compute
                # sign flips.
                state = bb.add(partition.adjoint(), active=active, passive=passive)

            # Ry rotation
            state = bb.split(state)  # type: ignore
            state[i], angles, phase_gradient = bb.add(
                RyRotation(
                    self.phase_gradient_dtype,
                ),
                q=state[i],
                angles=angles,
                phase_gradient=phase_gradient,
            )
            state = bb.join(state)
            bb.add(
                MeasureInX(self.phase_gradient_dtype, self.tensor_simulation_random),
                to_measure=angles,
            )  # TODO: Collect measurement results in classical register and compute
            # sign flips.

        return state, phase_gradient

    @property
    def _bloq_counter_amplitudes(self) -> Counter[Bloq]:
        """Count the bloqs for preparing the amplitudes."""
        return Counter(
            [self._qroam_amplitudes(i) for i in range(1, self.state_dtype.num_bits)]
            + self.state_dtype.num_bits * [RyRotation(self.phase_gradient_dtype)]
            + [self._xork_amplitude]
        )

    @property
    def _qroam_phases(self) -> QROAMClean:
        """QROAM for loading the phase angles."""
        if self.shapes_only:
            qroam = QROAMCleanExactCSwap.build_from_bitsize(
                slen(self._phase_angles),
                target_bitsizes=(self.phase_gradient_dtype.num_bits,),
            )
        else:
            qroam = QROAMCleanExactCSwap.build_from_data(
                self._phase_angles,  # type: ignore
                target_bitsizes=(self.phase_gradient_dtype.num_bits,),
            )
        return set_qroam_max_junk_size(qroam, self.max_qroam_junk_qubits)

    def _xork_phase_1_bit(self, i) -> Bloq:
        """The XorK used for setting the phase angle if only one qubit is prepared."""
        val = 0 if self.shapes_only else self._phase_angles[i]  # type: ignore
        return XorK(self.phase_gradient_dtype, val).controlled(
            ctrl_spec=CtrlSpec(cvs=i)
        )

    def _prepare_phases_bloq(
        self, bb: BloqBuilder, state: SoquetT, phase_gradient: SoquetT
    ) -> tuple[SoquetT, SoquetT]:
        """Encoding the the phase information of the state."""
        if self.state_dtype.num_bits == 1:
            angles = bb.allocate(dtype=self.phase_gradient_dtype)
            for i in (1, 0):
                state, angles = bb.add(self._xork_phase_1_bit(i), ctrl=state, x=angles)
        else:
            soqs = bb.add_d(self._qroam_phases, selection=state)
            state, angles = soqs.pop("selection"), soqs.pop("target0_")
            soqs = clear_qroam_junk_registers(
                bb, self.phase_gradient_dtype, self.tensor_simulation_random, **soqs
            )  # TODO: Collect measurement results in classical register and compute
            # sign flips.

        anc = bb.add(OneState())
        anc, angles, phase_gradient = bb.add(
            RzViaPhaseGradient(self.phase_gradient_dtype, self.phase_gradient_dtype),
            q=anc,
            angle=angles,
            phase_grad=phase_gradient,
        )
        bb.add(OneEffect(), q=anc)
        bb.add(
            MeasureInX(self.phase_gradient_dtype, self.tensor_simulation_random),
            to_measure=angles,
        )  # TODO: Collect measurement results in classical register and compute sign
        # flips.
        return state, phase_gradient

    @property
    def _bloq_counter_phases(self) -> Counter[Bloq]:
        """Count the bloqs for preparing the phases."""
        rz = RzViaPhaseGradient(self.phase_gradient_dtype, self.phase_gradient_dtype)
        loading = (
            [self._xork_phase_1_bit(i) for i in (0, 1)]
            if self.state_dtype.num_bits == 1
            else [self._qroam_phases]
        )
        return Counter([rz] + loading)

    @property
    def _sign_fix_up_bloq(self) -> SignFixUp:
        """
        Bloq that uncomputes the sign-flips of the X-Measurements used for deleting
        QRO(A)M target registers.
        """
        return SignFixUp(
            self._sign_flips_qroam,
            self.max_qroam_junk_qubits,
            tensor_simulation=self.tensor_simulation_random is not None,
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, phase_gradient: SoquetT
    ) -> dict[str, SoquetT]:  # type:ignore
        """@private"""
        state = bb.allocate(dtype=self.state_dtype)
        state, phase_gradient = self._prepare_amplitudes_bloq(bb, state, phase_gradient)

        if not self.prepare_only_amplitudes:
            state, phase_gradient = self._prepare_phases_bloq(bb, state, phase_gradient)

        if self.fix_signs:
            state = bb.add(
                self._sign_fix_up_bloq,
                address=state,
            )

        return {"state": state, "phase_gradient": phase_gradient}

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        d = self._bloq_counter_amplitudes
        if not self.prepare_only_amplitudes:
            d += self._bloq_counter_phases
        if self.fix_signs:
            d += Counter([self._sign_fix_up_bloq])
        return d

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        c = Counter(
            [
                sum(j.total_qubits() for j in self._qroam_amplitudes(i).junk_registers)
                for i in range(1, self.state_dtype.num_bits)
            ]
        )
        if not self.prepare_only_amplitudes:
            c += Counter(
                [sum(j.total_qubits() for j in self._qroam_phases.junk_registers)]
            )
        return c


_state = np.array(
    [
        -0.06983439 + 0.10294799j,
        0.23564679 + 0.26862708j,
        0.44597159 + 0.01439211j,
        -0.03913393 + 0.02271167j,
        -0.05347711 - 0.04959530j,
        0.16747489 + 0.19496189j,
        0.07018624 - 0.05290770j,
        -0.18050612 + 0.29707594j,
        0.01736172 - 0.22782472j,
        0.05347427 + 0.03384025j,
        0.16316080 + 0.18020173j,
        0.09339864 + 0.20001203j,
        -0.24241623 + 0.15270911j,
        -0.00976748 + 0.17939815j,
        -0.00097635 - 0.36802006j,
        -0.01953336 + 0.20379402j,
    ]
)


@bloq_example(generalizer=generalizer)
def _dense_prep_no_phase() -> DenseStatePreparationViaQROAM:
    return DenseStatePreparationViaQROAM(
        _state, QFxp(6, 6), prepare_only_amplitudes=True, fix_signs=False
    )


@bloq_example(generalizer=generalizer)
def _dense_prep() -> DenseStatePreparationViaQROAM:
    return DenseStatePreparationViaQROAM(
        _state,
        QFxp(6, 6),
    )
