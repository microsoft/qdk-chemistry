# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

from collections import Counter
from copy import deepcopy
from functools import cached_property

import numpy as np
from attrs import field, frozen
from isometry.utils import HasLen, HasShape, data_to_tuple
from qualtran import (
    Bloq,
    BloqBuilder,
    QFxp,
    QUInt,
    Register,
    Side,
    Signature,
    SoquetT,
    bloq_example,
)
from qualtran.bloqs.bookkeeping import Partition
from qualtran.resource_counting import BloqCountDictT, SympySymbolAllocator
from qualtran.symbolics import Shaped, is_symbolic
from qualtran.symbolics.types import HasLength
from unitary_synthesis.utils import generalizer

from .dense_state_preparation import DenseStatePreparationViaQROAM
from .site_unitaries import SiteUnitaryDense, SiteUnitarySparse, SparseThreeTensor


@frozen(cache_hash=True)
class MPSPreparation(Bloq):
    """
    Prepare a matrix product state consisting of ``tensors`` with the sites being
    four-dimensional. Two modes are supported:

    - If ``exploit_block_sparsity`` is ``False`` we rougly follow the reference and
    decompose the unitary into a sequence of smaller unitaries. Note that the way the
    unitaries are synthesized differs from the reference, improving the cost in the case
    of real a real MPS.
    - Otherwise an approach exploiting the block-sparsity of the MPS tensors is used to
    reduce the ressource cost.

    The rotations are applied using a phase-gradient register.
    The qubit/Toffoli tradeoff in the QROAMs can be controlled via
    ``max_qroam_junk_qubits``.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. See ``tensor_simulation`` for how those
    measurements can be treated in simulations.

    Registers
    ----------
    - state : ``self.state_dtype`` (RIGHT):
        The target register in which the MPS is prepared.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations. It is passed through unchanged.

    References
    ----------
        Rapid initial state preparation for the quantum simulation of strongly
        correlated molecules
        Berry, Tong, Khattar, White, Kim, Boixo, Lin, Lee, Chan, Babbush, Rubin. 2024
        (https://arxiv.org/abs/2409.11748)
    """

    tensors: tuple[HasShape | SparseThreeTensor, ...] = field(
        eq=lambda y: tuple(
            m if isinstance(m, SparseThreeTensor) else data_to_tuple(m) for m in y
        )
    )
    """Tensors of the MPS with the shapes ``(left, 4, right)``."""

    phase_gradient_dtype: QFxp
    """
    Datatype used for the phase-gradient register determining the accuracy of the
    rotations.
    """

    exploit_block_sparsity: bool
    """
    If ``True`` exploit the block sparsity of the MPS tensors for implementing the
    unitary corresponding to each site. Defaults to ``False``.
    """

    is_complex: bool
    """
    Indicate whether the MPS has complex tensors or not. This can also be used to force 
    real MPS to be treated as complex.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum value for k used in any QROAM. If ``None`` compute the optimal value. If 
    ``0`` use QROM.
    """

    force_shaped: bool = False
    """
    Force the subbloqs to only work with shapes of the tensors as soon as this is 
    possible.
    """

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor
    simulation. This replaces the X-measurements by unphysical fake X-measurements that
    are independent of the state that is measured and avoid classical controlled
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e.
    no phase flips are applied. Do not use when doing ressource estimates! Defaults to
    ``False``.
    """

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(*self.tensors) or self.force_shaped

    def __attrs_post_init__(self):
        assert all(t.shape[1] == 4 for t in self.tensors), (
            f"Site dimension must be 4. Have shapes {[t.shape for t in self.tensors]}."
        )
        assert all(
            self.tensors[i].shape[0] == self.tensors[i - 1].shape[2]
            for i in range(1, len(self.tensors))
        ), (
            f"Bond dimensions do not match between consecutive tensors. Have shapes {[t.shape for t in self.tensors]}"
        )
        assert self.tensors[-1].shape[2] == 1, (
            f"Last tensor has invalid shape {self.tensors[-1].shape}."
        )
        if not self.shapes_only:
            assert all(
                t.is_right_canonical
                if isinstance(t, SparseThreeTensor)
                else np.allclose(
                    np.eye(t.shape[0]), np.tensordot(t, t.conj(), axes=([1, 2], [1, 2]))
                )
                for t in self.tensors[1:-1]
            ), "MPS must be in right-canonical form."
            if not self.is_complex:
                assert all(
                    t.is_real if isinstance(t, SparseThreeTensor) else np.isrealobj(t)  # type: ignore
                    for t in self.tensors
                ), "Tensors are not real."

    @property
    def target_dtype(self) -> QUInt:
        """Datatype of the target register holding the state."""
        return QUInt(2 * len(self.tensors))

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("state", self.target_dtype, side=Side.RIGHT),
                Register("phase_gradient", self.phase_gradient_dtype),
            ]
        )

    @property
    def _initial_state(self) -> HasLen:
        """The initial state."""
        if self.shapes_only:
            return HasLength(4 * self.tensors[0].shape[2])
        first_tensor = (
            self.tensors[0].to_dense()
            if isinstance(self.tensors[0], SparseThreeTensor)
            else self.tensors[0]
        )
        initial_state = first_tensor.transpose(1, 2, 0)  # type: ignore
        if not self.exploit_block_sparsity:
            initial_state = self._unitaries[0].v @ initial_state  # type: ignore

        return np.sum(initial_state, axis=2).flatten()

    @property
    def _initial_state_bloq(
        self,
    ) -> DenseStatePreparationViaQROAM:
        """Bloq for preparing the initial state."""
        return DenseStatePreparationViaQROAM(
            self._initial_state,
            self.phase_gradient_dtype,
            max_qroam_junk_qubits=self.max_qroam_junk_qubits,
            tensor_simulation_random=False if self.tensor_simulation else None,
        )

    @property
    def _partition_initial_state(self) -> Partition:
        """
        Partition the register in which the initial state was prepared into an ancilla
        and site register.
        """
        initial_state_bitsize = self._initial_state_bloq.state_dtype.num_bits
        return Partition(
            initial_state_bitsize,
            (
                Register("site", QUInt(2)),
                Register("ancilla", QUInt(initial_state_bitsize - 2)),
            ),
        )

    def _partition_adjust_ancilla(
        self, ancilla_bitsize: int, new_ancilla_bitsize: int
    ) -> Partition:
        """Partition the ancilla register to adjust its size."""
        ancilla_diff = new_ancilla_bitsize - ancilla_bitsize
        partition = Partition(
            max(ancilla_bitsize, new_ancilla_bitsize),
            (
                Register("diff", QUInt(abs(ancilla_diff))),
                Register("ancilla", QUInt(min(ancilla_bitsize, new_ancilla_bitsize))),
            ),
        )
        return partition if ancilla_diff < 0 else partition.adjoint()

    def _adjust_ancilla_size(
        self, bb: BloqBuilder, ancilla: SoquetT, bitsize: int, new_bitsize: int
    ) -> SoquetT:
        """Adjust the ancilla size."""
        ancilla_diff = new_bitsize - bitsize
        if ancilla_diff > 0:
            ancilla = bb.add(
                self._partition_adjust_ancilla(bitsize, new_bitsize),
                diff=bb.allocate(ancilla_diff),
                ancilla=ancilla,
            )
        elif ancilla_diff < 0:
            to_free, ancilla = bb.add(
                self._partition_adjust_ancilla(bitsize, new_bitsize), x=ancilla
            )
            bb.free(to_free)
        return ancilla

    @cached_property
    def _unitaries(
        self,
    ) -> tuple[SiteUnitaryDense, ...] | tuple[SiteUnitarySparse, ...]:
        """Site unitaries for all sites except the first."""
        if self.exploit_block_sparsity:
            return tuple(
                SiteUnitarySparse(
                    tensor
                    if isinstance(tensor, SparseThreeTensor)
                    else SparseThreeTensor.from_dense(tensor),
                    self.phase_gradient_dtype,
                    self.is_complex,
                    self.max_qroam_junk_qubits,
                    self.shapes_only,
                    self.tensor_simulation,
                )
                for tensor in self.tensors[1:]
            )
        unitaries = []
        for i, tensor in enumerate(reversed(self.tensors[1:])):
            if self.shapes_only:
                tensor = Shaped(tensor.shape)
            elif isinstance(tensor, SparseThreeTensor):
                tensor = tensor.to_dense()
            unitaries.append(
                SiteUnitaryDense(
                    tensor,
                    self.phase_gradient_dtype,
                    unitaries[-1].v if i > 0 else None,
                    self.is_complex,
                    self.max_qroam_junk_qubits,
                    self.tensor_simulation,
                )
            )
        return tuple(reversed(unitaries))

    def build_composite_bloq(
        self, bb: BloqBuilder, phase_gradient: SoquetT
    ) -> dict[str, SoquetT]:  # type: ignore
        """@private"""

        full, phase_gradient = bb.add(
            self._initial_state_bloq, phase_gradient=phase_gradient
        )

        site, ancilla = bb.add(self._partition_initial_state, x=full)
        target = [bb.split(site)]

        ancilla_bitsize = self._initial_state_bloq.state_dtype.num_bits - 2
        for unitary in self._unitaries:
            ancilla = self._adjust_ancilla_size(
                bb, ancilla, ancilla_bitsize, unitary.ancilla_dtype.num_bits
            )
            new_site, ancilla, phase_gradient = bb.add(
                unitary,
                site=bb.allocate(dtype=unitary.site_dtype),
                ancilla=ancilla,
                phase_gradient=phase_gradient,
            )
            ancilla_bitsize = unitary.ancilla_dtype.num_bits
            target.append(bb.split(new_site))

        bb.free(ancilla)
        state = bb.join(np.hstack(target))  # type: ignore
        return {"state": state, "phase_gradient": phase_gradient}

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        return Counter((self._unitaries) + (self._initial_state_bloq,))

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        return sum(
            (
                b.junk_register_qubits
                for b in self._unitaries + (self._initial_state_bloq,)
            ),
            Counter(),
        )


@bloq_example(generalizer=generalizer)
def _mps_prep_dense() -> MPSPreparation:
    return MPSPreparation(
        deepcopy(_mps), QFxp(5, 5), exploit_block_sparsity=False, is_complex=False
    )


@bloq_example(generalizer=generalizer)
def _mps_prep_sparse() -> MPSPreparation:
    return MPSPreparation(
        deepcopy(_mps), QFxp(7, 7), exploit_block_sparsity=True, is_complex=False
    )


_mps = (np.array(
    [[[ 0.01650572,  0.        ,  0.        ,  0.        ],
        [ 0.        , -0.52929781,  0.        ,  0.        ],
        [ 0.        ,  0.        , -0.84462254,  0.        ],
        [ 0.        ,  0.        ,  0.        , -0.07863941]]]), np.array(
        [[[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 1.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ]],
       [[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [-0.05969264,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.9973967 ,  0.04045497,  0.        ,  0.        ,
          0.        ]],
       [[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [-0.08381532,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.98376348,  0.15869598,
          0.        ]],
       [[-0.0421477 ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.46961402,  0.0265522 ,  0.        ,  0.        ,
          0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.41109095,  0.03268939,
          0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
          0.77904869]]]), np.array(
            [[[ 0.        ,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ],
        [ 1.        ,  0.        ,  0.        ,  0.        ]],
       [[ 0.        ,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ],
        [-0.19640516,  0.        ,  0.        ,  0.        ],
        [ 0.        , -0.98052283,  0.        ,  0.        ]],
       [[ 0.        ,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ],
        [-0.98052283,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.19640516,  0.        ,  0.        ]],
       [[ 0.        ,  0.        ,  0.        ,  0.        ],
        [-0.02411236,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        , -0.99970925,  0.        ]],
       [[ 0.        ,  0.        ,  0.        ,  0.        ],
        [-0.99970925,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        ,  0.        ,  0.        ],
        [ 0.        ,  0.        ,  0.02411236,  0.        ]],
       [[-0.17695837,  0.        ,  0.        ,  0.        ],
        [ 0.        , -0.58052668,  0.        ,  0.        ],
        [ 0.        ,  0.        , -0.53176612,  0.        ],
        [ 0.        ,  0.        ,  0.        , -0.59067698]]]), np.array(
            [[[0.],
        [0.],
        [0.],
        [1.]],
       [[0.],
        [0.],
        [1.],
        [0.]],
       [[0.],
        [1.],
        [0.],
        [0.]],
       [[1.],
        [0.],
        [0.],
        [0.]]]))  # fmt: skip
