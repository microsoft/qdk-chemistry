# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

from collections import Counter
from functools import cache, cached_property

import numpy as np
from attrs import field, frozen
from isometry import random_signs
from isometry.utils import HasLen, HasShape, data_to_tuple, pad
from qualtran import (
    Bloq,
    BloqBuilder,
    QBit,
    QFxp,
    QUInt,
    Register,
    Signature,
    SoquetT,
    bloq_example,
)
from qualtran.bloqs.basic_gates.cnot import CNOT
from qualtran.bloqs.data_loading.qroam_clean import QROAMClean
from qualtran.resource_counting import BloqCountDictT, SympySymbolAllocator
from qualtran.symbolics import Shaped, bit_length, is_symbolic, slen
from qualtran.symbolics.types import HasLength
from scipy.sparse import coo_array
from unitary_synthesis import (
    MeasureInX,
    RyRotation,
    Unitary,
)
from unitary_synthesis.utils import (
    QROAMCleanExactCSwap,
    angle_to_binary,
    clear_qroam_junk_registers,
    combine_sign_flips,
    generalizer,
    set_qroam_max_junk_size,
)


@frozen(cache_hash=True)
class YRotation(Bloq):
    r"""
    Synthesize the block matrix

        ( d_1  . )
        ( d_2  . )

    with ``d_1`` and ``d_2`` being diagonal matrices of the same shape. The blocks are
    selected by the value of the ``target``-qubit and the block content corresponds to
    the ``address``-register.

    The rotations are applied using a phase-gradient register. Note that sign-flips due
    to measuring the QROAM-ancilla qubits are not fixed. The unitary may be controlled
    on a control qubit if ``controlled`` is set.
    The qubit/Toffoli tradeoff in the QROAMs can be controlled via
    ``max_qroam_junk_qubits``.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. See ``tensor_simulation`` for how those
    measurements can be treated in simulations.

    Registers
    ----------
    - target : ``QBit()``:
        The target qubit on which the rotation is being applied. Corresponds to the two
        blocks.

    - address : ``self.address_dtype``:
        The address qubits depending on which we load the different angles. Large enough
        to be able to hold all elements of ``diagonal``.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations. It is passed through unchanged.

    - control : ``QBit()`` (optional):
        Qubit that acts as a control qubit for the rotation. Only created if
        ``controlled`` is set.
    """

    diagonal_d_2: HasLen = field(eq=lambda x: data_to_tuple(x))
    """Values on the lower diagonal ``d_2``"""

    address_dtype: QUInt
    """Datatype of the register whose states are being rotated."""

    phase_gradient_dtype: QFxp
    """
    Datatype for the phase-gradient register. Its size determines the accuracy of the
    rotations.
    """

    controlled: bool = False
    """
    If ``True`` the rotations are controlled on an extra ``QBit``. Defaults to
    ``False``.
    """

    signs_in: HasLen | None = field(eq=lambda x: data_to_tuple(x), default=None)
    """
    Incoming signs for each basis state in the joint ``target``+``address`` register.
    Defaults to ``None``.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor
    simulation. This replaces the X-measurements by unphysical fake X-measurements that
    are independent of the state that is measured and avoid classical controlled
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e.
    no phase flips are applied. Defaults to ``False``.
    """

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(self.diagonal_d_2, self.signs_in)

    @property
    def _address_dim(self) -> int:
        """Dimension of the space of the addrres qubits."""
        return 1 << self.address_dtype.num_bits

    def __attrs_post_init__(self):
        if self.signs_in is not None:
            assert slen(self.signs_in) == 2 * self._address_dim, (
                f"Sign_in length {slen(self.signs_in)} must be {self._address_dim}."
            )
        assert slen(self.diagonal_d_2) <= self._address_dim, (
            f"Rotation angles of length {slen(self.diagonal_d_2)} do not fit in register of dimension {self._address_dim}."
        )
        if not self.shapes_only:
            assert np.all(
                ((self.diagonal_d_2 > -1) & (self.diagonal_d_2 < 1))  # type: ignore
                | np.isclose(np.abs(self.diagonal_d_2), 1)  # type: ignore
            ), f"Diagonal values {self.diagonal_d_2} must be in [-1, 1]."

    @property
    def signature(self) -> Signature:
        """@private"""
        regs = [
            Register("target", QBit()),
            Register("address", self.address_dtype),
            Register("phase_gradient", self.phase_gradient_dtype),
        ]
        if self.controlled:
            regs.append(Register("control", QBit()))
        return Signature(regs)

    @property
    def signs_out(self) -> HasLen:
        """
        Outgoing signs for each basis state in the joint ``target``+``address``
        register.
        """
        if self.signs_in is not None:
            return combine_sign_flips(self._sign_flips_qroam, self.signs_in)
        return self._sign_flips_qroam

    @property
    def _rot_angles_after_sign_commutations(self) -> np.ndarray:
        """
        Adapt the rotatin angles such that the signs in get pushed through the circuit.
        """
        angles = np.arcsin(np.clip(self.diagonal_d_2, -1, 1))  # type: ignore
        if self.signs_in is not None:
            block_len = slen(self.signs_in) // 2
            differs = (
                self.signs_in[: len(angles)]  # type: ignore
                != self.signs_in[block_len : block_len + len(angles)]  # type: ignore
            )
            angles = (-1) ** differs * angles
        return angles

    @cached_property
    def _angles(self) -> HasLen:
        """Rotation angles."""
        if self.shapes_only:
            return HasLength(self._address_dim)
        else:
            return pad(
                angle_to_binary(
                    self._rot_angles_after_sign_commutations,
                    self.phase_gradient_dtype.num_bits,
                ),
                self._address_dim,
            )

    @property
    def _qroam(self) -> QROAMClean:
        """QROAM for loading the rotation angles."""
        if self.shapes_only:
            qroam = QROAMCleanExactCSwap.build_from_bitsize(
                slen(self._angles),
                target_bitsizes=(self.phase_gradient_dtype.num_bits,),
                num_controls=1 if self.controlled else 0,
            )
        else:
            qroam = QROAMCleanExactCSwap.build_from_data(
                self._angles,  # type: ignore
                target_bitsizes=(self.phase_gradient_dtype.num_bits,),
                num_controls=1 if self.controlled else 0,
            )
        return set_qroam_max_junk_size(qroam, self.max_qroam_junk_qubits)

    @property
    def _sign_flips_qroam(self) -> HasLen:
        """Get random sign flips, imitating the flips caused by X-measurements."""
        if self.shapes_only:
            return HasLength(2 * self._address_dim)
        elif self.tensor_simulation:
            return np.zeros(2 * self._address_dim, dtype=bool)
        # TODO: Compute the values from the X-measurements using classical registers.
        rand = random_signs(self._address_dim, seed=1999999)
        return np.hstack([rand, rand])

    def build_composite_bloq(
        self,
        bb: BloqBuilder,
        target: SoquetT,
        address: SoquetT,
        phase_gradient: SoquetT,
        **soqs: SoquetT,
    ) -> dict[str, SoquetT]:  # type: ignore
        """@private"""

        fake_random_meas = False if self.tensor_simulation else None

        soqs = bb.add_d(
            self._qroam,
            selection=address,
            **soqs,
        )
        soqs["address"] = soqs.pop("selection")

        soqs = clear_qroam_junk_registers(
            bb, self.phase_gradient_dtype, fake_random_meas, **soqs
        )  # TODO: Collect measurement results in classical register and compute sign
        # flips.
        soqs["target"], angles, soqs["phase_gradient"] = bb.add(
            RyRotation(self.phase_gradient_dtype),
            q=target,
            angles=soqs.pop("target0_"),
            phase_gradient=phase_gradient,
        )
        bb.add(
            MeasureInX(self.phase_gradient_dtype, fake_random_meas), to_measure=angles
        )
        return soqs

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        return {self._qroam: 1, RyRotation(self.phase_gradient_dtype): 1}

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        return Counter([sum(j.total_qubits() for j in self._qroam.junk_registers)])


def _decompose_2d(
    a: np.ndarray, b: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Decompose a 2x2 block matrix as in eq (30) of the Berry et al. paper. The matrices
    ``a`` and ``b`` are matrices of the same shape ``(x, y)`` with ``(a, b)^T`` having
    mutually orthogonal columns. The returned decomposition a matrix  whose first
    columns agree with the input matrices.

    Return the individual parts ``(u_1, u_2, d_1, d_2, v)`` of the decomposition with
    shapes ``(x, x)``, ``(x, x)``, ``(y,)``, ``(y,)`` and ``(y, y)``.
    """
    assert a.shape == b.shape, (
        f"The blocks must be of the same shape. Have {a.shape} and {b.shape}."
    )
    assert np.allclose(
        np.vstack([a, b]).conj().T @ np.vstack([a, b]), np.eye(a.shape[1])
    ), "Columns need to be orthonormal."

    u_1, d_1, v = np.linalg.svd(a)
    # (dim, width) -> (dim, dim), (width), (width, width)

    u_2, d_2 = _polar(b @ (v.conj().T))
    # (dim, width) -> (dim, dim), (width, width)

    # TODO: Find out why I cant set atol higher here.
    assert np.allclose(d_2, np.diag(d_2.diagonal()), atol=1e-7), (
        f"The matrix {d_2} should be diagonal."
    )
    return (u_1, u_2, d_1, d_2.diagonal(), v)


def _polar(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Apply a polar decomposition to the ``matrix`` with shape ``(x, y)``. The returned
    matrices have shape ``(x, x)`` and (y, y)``.
    """
    width = matrix.shape[1]
    w, s, v_ = np.linalg.svd(
        matrix
    )  # (dim, width) -> (dim, dim), (width), (width, width)

    w[:width, :width] = w[:width, :width] @ v_
    return w, (v_.T.conj() * s) @ v_


@frozen(cache_hash=True)
class SiteUnitaryDense(Bloq):
    r"""
    Decompose the target matrix via

    .. math::
        \begin{pmatrix}
            a_0 & * & * & * \\\\
            a_1 & * & * & * \\\\
            a_2 & * & * & * \\\\
            a_3 & * & * & * \\\\
        \end{pmatrix} = \begin{pmatrix}
            u_0 & 0 & 0 & 0 \\\\
            0 & u_1 & 0 & 0 \\\\
            0 & 0 & u_2 & 0 \\\\
            0 & 0 & 0 & u_3 \\\\
        \end{pmatrix} \begin{pmatrix}
            I & 0 & 0 & 0 \\\\
            0 & I & 0 & 0 \\\\
            0 & 0 & d_0 & \cdot \\\\
            0 & 0 & d_0' & \cdot \\\\
        \end{pmatrix} \begin{pmatrix}
            I & 0 & 0 & 0 \\\\
            0 & I & 0 & 0 \\\\
            0 & 0 & w_0 & 0 \\\\
            0 & 0 & 0 & w_0 \\\\
        \end{pmatrix} \begin{pmatrix}
            I & 0 & 0 & 0 \\\\
            0 & d_1 & \cdot & 0 \\\\
            0 & d_1' & \cdot & 0 \\\\
            0 & 0 & 0 & I \\\\
        \end{pmatrix} \begin{pmatrix}
            I & 0 & 0 & 0 \\\\
            0 & w_1 & 0 & 0 \\\\
            0 & 0 & w_1 & 0 \\\\
            0 & 0 & 0 & I \\\\
        \end{pmatrix} \begin{pmatrix}
            d_2 & \cdot & 0 & 0 \\\\
            d_2' & \cdot & 0 & 0 \\\\
            0 & 0 & d_2 & \cdot \\\\
            0 & 0 & d_2' & \cdot \\\\
        \end{pmatrix} \begin{pmatrix}
            v & 0 & 0 & 0 \\\\
            0 & v & 0 & 0 \\\\
            0 & 0 & v & 0 \\\\
            0 & 0 & 0 & v \\\\
        \end{pmatrix}

    Then implement the unitary without the last matrix involving ``v``. It is assumed
    that this part is pushed to a lower site.

    The rotations are applied using a phase-gradient register.
    The qubit/Toffoli tradeoff in the QROAMs can be controlled via 
    ``max_qroam_junk_qubits``.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. The measurement results are simply discarded.
    See ``tensor_simulation`` for how those measurements can be treated in simulations.

    Registers
    ----------
    - site : ``self.site_dtype``:
        The site register consisting of two qubits.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations. It is passed through unchanged.

    - ancilla : ``self.ancilla_dtype``:
        ancilla register bringing information from previous sites in and for following
        sites out of the unitary.
    """

    tensor: HasShape = field(eq=lambda x: data_to_tuple(x))
    """
    Tensor for the site of shape ``(left, 4, right)``.
    """

    phase_gradient_dtype: QFxp
    """
    Datatype for the phase-gradient register. Its size determines the accuracy of the 
    rotations.
    """

    v_from_next: HasShape | None = field(eq=lambda x: data_to_tuple(x))
    """A matrix on the ancilla qubits from the site before. Include it here."""

    is_complex: bool
    """
    Indicate whether the tensor is tensors or not. This can also be used to force  real 
    tensors to be treated as complex.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor 
    simulation. This replaces the X-measurements by unphysical fake X-measurements that 
    are independent of the state that is measured and avoid classical controlled 
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e. 
    no phase flips are applied. Do not use when doing ressource estimates! Defaults to 
    ``False``.
    """

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(self.tensor, self.v_from_next)

    @property
    def ancilla_dtype(self) -> QUInt:
        """Datatype of the ancilla register"""
        return QUInt(bit_length(max(self.tensor.shape[2], self.tensor.shape[0]) - 1))

    @property
    def _ancilla_dim(self) -> int:
        """Dimension of the space of the ancilla qubits."""
        return 1 << self.ancilla_dtype.num_bits

    @cached_property
    def _target_matrix(self) -> np.ndarray:
        """Transform tensor to matrix according to eq. (6) in Berry et al. paper."""
        tensor = self.tensor.transpose(1, 2, 0)  # type: ignore

        if (v := self.v_from_next) is not None:
            tensor = v @ tensor

        padded_tensor = np.pad(
            tensor, ((0, 0), (0, self._ancilla_dim - tensor.shape[1]), (0, 0))
        )
        shape = padded_tensor.shape
        return padded_tensor.reshape(shape[0] * shape[1], shape[2])

    def __attrs_post_init__(self):
        assert len(self.tensor.shape) == 3 and self.tensor.shape[1] == 4, (
            f"Need valid tensor. Have shape {self.tensor.shape}"
        )
        if (v := self.v_from_next) is not None:
            assert v.shape[0] == v.shape[1] and v.shape[0] == self.tensor.shape[2], (
                f"Shapes of v_from_next must fit. Tensor shape {self.tensor.shape}, v shape {v.shape}."
            )
        if not self.shapes_only:
            assert np.allclose(
                self._target_matrix.conj().T @ self._target_matrix,
                np.eye(self._target_matrix.shape[1]),
            ), "Columns need to be orthonormal."
            if not self.is_complex:
                assert np.isrealobj(self.tensor) and np.isrealobj(self.v_from_next), (  # type:ignore
                    f"The tensors ({np.isrealobj(self.tensor)}) and v_from_next ({np.isrealobj(self.v_from_next)}) must be real."  # type:ignore
                )

    @property
    def site_dtype(self) -> QUInt:
        """Datatype of the site. Consists of two qubits."""
        return QUInt(2)

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("site", self.site_dtype),
                Register("ancilla", self.ancilla_dtype),
                Register("phase_gradient", self.phase_gradient_dtype),
            ]
        )

    @cached_property
    def _decomposition(
        self,
    ) -> tuple[
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
        tuple[np.ndarray, np.ndarray, np.ndarray],
        tuple[np.ndarray, np.ndarray, np.ndarray],
        tuple[np.ndarray, np.ndarray],
        np.ndarray,
    ]:
        """
        Follow the logic in the Appendix of our paper to transform the tensor into the
        decomposition.
        """
        dim = self._ancilla_dim
        matrix = self._target_matrix  # (4*dim, width)

        b, r = np.linalg.qr(matrix[dim:, :], mode="complete")
        # (3*dim, width) -> (3*dim, 3*dim), (3*dim, width)

        c, s = np.linalg.qr(b[dim:, :dim], mode="complete")
        # (2*dim, dim) -> (2*dim, 2*dim), (2*dim, dim)

        u_2, u_3, d_2, d_2_, v__ = _decompose_2d(c[:dim, :dim], c[dim:, :dim])
        # (dim, dim), (dim, dim) -> (dim, dim), (dim, dim), (dim), (dim), (dim, dim)

        u_1, u, d_1, d_1_, v_ = _decompose_2d(b[:dim, :dim], s[:dim, :])
        # (dim, dim), (dim, dim) -> (dim, dim), (dim, dim), (dim), (dim), (dim, dim)

        u_0, u_, d_0, d_0_, v = _decompose_2d(matrix[:dim, :], r[:dim, :])
        # (dim, width), (dim, width) -> (dim, dim), (dim, width), (width), (width), (width, width)

        d_0 = pad(d_0.real, dim)
        d_0_ = pad(d_0_.real, dim)

        return (  # type: ignore
            (u_0, u_1, u_2, u_3),
            (d_0, d_1.real, d_2.real),
            (d_0_, d_1_.real, d_2_.real),
            (v_ @ u_, v__ @ u),
            v,
        )

    @property
    def _shape_block(self) -> Shaped:
        """Shape of a basic block."""
        return Shaped((self._ancilla_dim,) * 2)

    @property
    def _u(self) -> tuple[HasShape, HasShape, HasShape, HasShape]:
        """The ``u``s in the decomposition."""
        if self.shapes_only:
            b = self._shape_block
            return (b, b, b, b)
        else:
            return self._decomposition[0]

    @property
    def _d(self) -> tuple[HasLen, HasLen, HasLen]:
        """The ``d``s in the decomposition."""
        if self.shapes_only:
            h = HasLength(self._ancilla_dim)
            return (h, h, h)
        else:
            return self._decomposition[1]

    @property
    def _d_(self) -> tuple[HasLen, HasLen, HasLen]:
        """The ``d_``s in the decomposition."""
        if self.shapes_only:
            h = HasLength(self._ancilla_dim)
            return (h, h, h)
        else:
            return self._decomposition[2]

    @property
    def _w(self) -> tuple[HasShape, HasShape]:
        """The ``w``s in the decomposition."""
        if self.shapes_only:
            b = self._shape_block
            return (b, b)
        else:
            return self._decomposition[3]

    @property
    def v(self) -> HasShape:
        """``v`` in the decomposition. It is not included in the circuit."""
        if self.shapes_only:
            return Shaped((self.tensor.shape[0],) * 2)
        else:
            return self._decomposition[4]

    def _assert_decomposition_valid(self):
        """Check whether the decomposition reproduces the correct matrix."""
        width = self.v.shape[0]
        temp_0 = (self._w[0] * self._d_[0])[:, :width] @ self.v  # type: ignore
        temp_1 = self._w[1] @ (temp_0 * self._d_[1][:, None])  # type: ignore
        matrix = np.vstack(
            [
                (self._u[0] * self._d[0])[:, :width] @ self.v,  # type: ignore
                self._u[1] @ (temp_0 * self._d[1][:, None]),  # type: ignore
                self._u[2] @ (temp_1 * self._d[2][:, None]),  # type: ignore
                self._u[3] @ (temp_1 * self._d_[2][:, None]),  # type: ignore
            ]
        )
        assert np.allclose(matrix, self._target_matrix), (
            "The decomposition must recreate the target matrix."
        )

    @cache
    def _unitary_w_i(self, i: int) -> Unitary:
        """Bloq implementing the unitary with ``w_i``."""
        if self.shapes_only:
            signs_in = HasLength(self._ancilla_dim)
        else:
            signs_in = self._y_rotation_i(i).signs_out[self._ancilla_dim :]  # type: ignore

        return Unitary.from_matrices(
            (self._w[i],),
            self.ancilla_dtype,
            self.phase_gradient_dtype,
            self.is_complex,
            True,
            signs_in,
            False,
            self.max_qroam_junk_qubits,
            self.tensor_simulation,
        )

    @cached_property
    def _unitary_u(self) -> Unitary:
        """Bloq implementing the unitary with the ``u``s."""
        if self.shapes_only:
            signs_in = HasLength(4 * self._ancilla_dim)
        else:
            signs_in = np.hstack(  # type: ignore
                [
                    self._y_rotation_i(0).signs_out[: self._ancilla_dim],  # type: ignore
                    self._y_rotation_i(1).signs_out[: self._ancilla_dim],  # type: ignore
                    self._y_rotation_i(2).signs_out,
                ]
            )

        return Unitary.from_matrices(
            self._u,
            self.ancilla_dtype,
            self.phase_gradient_dtype,
            self.is_complex,
            False,
            signs_in,
            True,
            self.max_qroam_junk_qubits,
            self.tensor_simulation,
        )

    def _y_rotation_i(self, i: int) -> YRotation:
        """Bloq implementing the Y-Rotations with ``d_i``"""
        if self.shapes_only:
            signs_in = HasLength(2 * self._ancilla_dim) if i > 0 else None
        else:
            signs_in = (
                (np.hstack(2 * [self._unitary_w_i(i - 1).signs_out])) if i > 0 else None  # type: ignore
            )
        return YRotation(
            self._d_[i],
            self.ancilla_dtype,
            self.phase_gradient_dtype,
            i in (1, 2),
            signs_in,
            self.max_qroam_junk_qubits,
            self.tensor_simulation,
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, site: SoquetT, ancilla: SoquetT, phase_gradient: SoquetT
    ) -> dict[str, SoquetT]:  # type: ignore
        """@private"""

        site = bb.split(site)  # type: ignore
        site[1], ancilla, phase_gradient = bb.add(
            self._y_rotation_i(0),
            target=site[1],
            address=ancilla,
            phase_gradient=phase_gradient,
        )
        site[0], site[1] = bb.add(CNOT(), ctrl=site[0], target=site[1])
        ancilla, phase_gradient, site[1] = bb.add(
            self._unitary_w_i(0),
            target=ancilla,
            phase_gradient=phase_gradient,
            control=site[1],
        )
        site[0], ancilla, phase_gradient, site[1] = bb.add(
            self._y_rotation_i(1),
            target=site[0],
            address=ancilla,
            phase_gradient=phase_gradient,
            control=site[1],
        )
        site[0], site[1] = bb.add(CNOT(), ctrl=site[0], target=site[1])
        ancilla, phase_gradient, site[0] = bb.add(
            self._unitary_w_i(1),
            target=ancilla,
            phase_gradient=phase_gradient,
            control=site[0],
        )
        site[1], ancilla, phase_gradient, site[0] = bb.add(
            self._y_rotation_i(2),
            target=site[1],
            address=ancilla,
            phase_gradient=phase_gradient,
            control=site[0],
        )
        site = bb.join(site)
        soqs = {}
        soqs["ancilla"], soqs["phase_gradient"], soqs["site"] = bb.add(
            self._unitary_u,
            target=ancilla,
            phase_gradient=phase_gradient,
            subspace=site,
        )
        return soqs

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        return Counter(
            [self._y_rotation_i(i) for i in (0, 1, 2)]
            + [self._unitary_w_i(i) for i in (0, 1)]
            + [self._unitary_u]
            + 2 * [CNOT()]
        )

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        return sum(
            (
                b.junk_register_qubits
                for b in [self._y_rotation_i(i) for i in (0, 1, 2)]
                + [self._unitary_w_i(i) for i in (0, 1)]
                + [self._unitary_u]
            ),
            Counter(),
        )


@bloq_example(generalizer=generalizer)
def _site_unitary_dense() -> SiteUnitaryDense:
    return SiteUnitaryDense(_tensor, QFxp(7, 7), None, True)


_tensor = coo_array(
    (
        np.array(
    [1.        , -0.00001137,  0.00031231,  0.01458963, -0.84456028, -0.53526159,
       -0.00289236, -0.99999575,  0.00021525, -0.00025164, -0.0001805 , -0.00000142,
        0.00001614, -0.00768365,  0.53520809, -0.8446853 ,  1.        ,  0.49013412,
       -0.34742948,  0.00095798, -0.79930663, -0.01297227, -0.0010096 , -0.34742582,
        0.00100338,  0.79930728,  0.01297197,  0.00101266, -0.49013557, -0.00000007,
       -0.00000435, -0.00148569,  0.08698141,  0.10600696, -0.99055265]),
    (np.array(
        [0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6,
       6, 6, 7, 7, 7, 7, 7, 7]), 
       np.array(
        [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1,
       1, 2, 0, 0, 0, 0, 0, 3]), 
       np.array(
        [0, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 1, 2, 3, 4,
       5, 6, 1, 2, 3, 4, 5, 7]))),
    (8, 4, 8)
    ).toarray()  # fmt: skip


@bloq_example(generalizer=generalizer)
def _y_rotation() -> YRotation:
    return YRotation(
        np.array(
            [
                0.19509032,
                -0.38268343,
                0.0,
                0.55557023,
                0.19509032,
                -0.38268343,
                -0.09801714,
                0.29028468,
                0.47139674,
                -0.09801714,
                -0.19509032,
                0.29028468,
                -0.09801714,
            ]
        ),
        QUInt(4),
        QFxp(6, 6),
    )
