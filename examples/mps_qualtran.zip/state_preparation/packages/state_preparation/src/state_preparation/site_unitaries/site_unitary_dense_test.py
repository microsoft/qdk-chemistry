# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import pytest
from attrs import evolve
from isometry import random_signs
from isometry.utils_test import bloq_autotester_with_counts  # noqa: F401
from qualtran import BloqBuilder, QUInt, Register
from qualtran.bloqs.rotations.phase_gradient import PhaseGradientState
from qualtran.dtype import QBit, QFxp
from scipy.linalg import block_diag
from scipy.stats import unitary_group

from .site_unitary_dense import SiteUnitaryDense, _site_unitary_dense, _y_rotation


@pytest.mark.parametrize("bloq_ex", [_y_rotation, _site_unitary_dense])
def test_example(bloq_autotester_with_counts, bloq_ex):  # noqa: F811
    bloq_autotester_with_counts(bloq_ex)


@pytest.mark.parametrize(
    "signs_in",
    [None, random_signs(32, 2341253)],
)
@pytest.mark.parametrize(
    "controlled",
    [False, True],
)
def test_phase(signs_in, controlled):
    y_rot = evolve(
        _y_rotation(),
        tensor_simulation=True,
        controlled=controlled,
        signs_in=signs_in,
    )
    phase_gradient_state = PhaseGradientState(y_rot.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    if controlled:
        soqs["control"] = bb.add_register(Register("control", QBit()))
    soqs["target"] = bb.add_register(Register("target", QBit()))
    soqs["address"] = bb.add_register(Register("address", QUInt(4)))
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(y_rot, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))

    if controlled:
        bloq = bb.finalize(
            control=soqs.pop("control"),
            target=soqs.pop("target"),
            address=soqs.pop("address"),
        )
    else:
        bloq = bb.finalize(
            target=soqs.pop("target"),
            address=soqs.pop("address"),
        )

    d_ = block_diag(np.diag(y_rot.diagonal_d_2), np.diag([0, 0, 0]))  # type: ignore
    d = block_diag(np.diag(np.sqrt(1 - y_rot.diagonal_d_2**2)), np.eye(3))  # type: ignore
    target_matrix = np.block(
        [
            [d, -d_],
            [d_, d],
        ]
    )
    if controlled:
        target_matrix = block_diag(np.eye(target_matrix.shape[0]), target_matrix)
        signs_out = np.hstack(  # type: ignore
            [np.zeros(len(y_rot.signs_out), dtype=bool), y_rot.signs_out]  # type: ignore
        )
    else:
        signs_out = y_rot.signs_out

    tensor = np.diag((-1) ** signs_out) @ bloq.tensor_contract()  # type: ignore

    if signs_in is not None:
        if controlled:
            signs_in = np.hstack([np.zeros(len(signs_in), dtype=bool), signs_in])

        assert np.allclose(
            target_matrix @ np.diag((-1) ** signs_in),
            tensor,
        )
    else:
        assert np.allclose(target_matrix, tensor)


tensor = (
    unitary_group.rvs(16, random_state=7890987)[:, :4]
    .reshape(4, 4, 4)
    .transpose(2, 0, 1)
)
site_unitary_dense = SiteUnitaryDense(tensor, QFxp(6, 6), None, True)


@pytest.mark.parametrize("complex", [False, True])
@pytest.mark.parametrize("bloq", [_site_unitary_dense(), site_unitary_dense])
def test_site_unitary_dense(complex, bloq):
    if bloq == site_unitary_dense:
        complex = True
    unitary = evolve(
        bloq, tensor_simulation=True, max_qroam_junk_qubits=0, is_complex=complex
    )

    phase_gradient_state = PhaseGradientState(unitary.phase_gradient_dtype.num_bits)
    bb = BloqBuilder()
    soqs = {}
    soqs["site"] = bb.add_register(Register("site", QUInt(2)))
    soqs["ancilla"] = bb.add_register(
        Register("ancilla", QUInt(2 if bloq == site_unitary_dense else 3))
    )
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(unitary, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))
    bloq = bb.finalize(site=soqs.pop("site"), ancilla=soqs.pop("ancilla"))

    # Would like to use larger phase gradient states to be able to lower the atol, but
    # this would require too much memory.
    num_cols = unitary._target_matrix.shape[1]
    np.set_printoptions(suppress=True, threshold=100000, linewidth=500)
    a = unitary._target_matrix @ (unitary.v.conjugate().T)
    b = bloq.tensor_contract()[:, :num_cols]
    assert np.allclose(
        a,
        b,
        atol=0.076,
    )
