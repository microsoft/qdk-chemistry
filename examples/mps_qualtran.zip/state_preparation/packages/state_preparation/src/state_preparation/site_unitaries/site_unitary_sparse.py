# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

from collections import Counter
from functools import cached_property

import numpy as np
from attrs import field, frozen
from isometry import random_signs
from isometry.utils import HasLen, data_to_tuple
from qualtran import (
    Bloq,
    BloqBuilder,
    QFxp,
    QUInt,
    Register,
    Signature,
    SoquetT,
    bloq_example,
)
from qualtran.bloqs.basic_gates import Swap
from qualtran.bloqs.bookkeeping import Partition
from qualtran.bloqs.data_loading.qroam_clean import QROAMClean
from qualtran.resource_counting import BloqCountDictT, SympySymbolAllocator
from qualtran.symbolics import Shaped, bit_length, is_symbolic
from qualtran.symbolics.types import HasLength, slen
from scipy.sparse import (
    block_diag,
    coo_array,
    csc_array,
    csr_array,
    eye_array,
    hstack,
)
from unitary_synthesis import MeasureInX, SignFixUp, Unitary
from unitary_synthesis.utils import (
    QROAMCleanExactCSwap,
    clear_qroam_junk_registers,
    combine_sign_flips,
    generalizer,
    set_qroam_max_junk_size,
)


@frozen(cache_hash=True)
class Permutation:
    """
    Permutation on the set ``[0, ..., len]``.
    """

    data: HasLen = field(eq=lambda x: data_to_tuple(x))
    """The ``i``-th element in data defines the mapping ``i -> data[i]``."""

    def is_symbolic(self) -> bool:
        """@private"""
        return is_symbolic(self.data)

    def __attrs_post_init__(self):
        if not self.is_symbolic:
            assert np.array_equal(
                np.unique(self.data), np.arange(len(self.data), dtype=int)
            ), f"{self.data} is not a permutation on [0, {len(self.data)}]."

    def pad(self, length: int) -> "Permutation":
        """
        Add identities such that it is a permutation on a set of length ``length``.
        """
        if self.is_symbolic():
            return Permutation(HasLength(length))
        return Permutation(
            np.hstack([self.data, np.arange(len(self.data), length, dtype=int)])  # type: ignore
        )

    def to_symbolic(self) -> "Permutation":
        """Return a symbolic version of the instance."""
        return Permutation(HasLength(slen(self.data)))

    def invert(self) -> "Permutation":
        """Compute the inverse of the permutation."""
        if self.is_symbolic():
            return self
        inverse = np.zeros(len(self.data), dtype=int)  # type: ignore
        inverse[self.data] = np.arange(len(self.data))  # type: ignore
        return Permutation(inverse)

    def __matmul__(self, other: "Permutation"):
        assert slen(other.data) == slen(self.data), (
            f"Permutation lengths differ. left: {slen(self.data)}, right: {slen(other.data)}."
        )
        return Permutation(other.data[self.data]) if not self.is_symbolic() else self  # type: ignore


@frozen(cache_hash=True)
class PermutationViaQROAM(Bloq):
    """
    Apply a ``permutation`` on the basis states.

    The qubit/Toffoli tradeoff in the QROAM can be controlled via ``max_qroam_junk_qubits``.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. See ``tensor_simulation`` for how those
    measurements can be treated in simulations.

    Registers
    ----------
    - target : ``self.target_dtype``:
        The target register whose states are being permuted.
    """

    permutation: Permutation
    """Permutation to apply."""

    target_dtype: QUInt
    """Datatype of the register whose states are being permuted."""

    signs_in: HasLen | None = field(eq=lambda x: data_to_tuple(x), default=None)
    """
    Incoming signs for each basis state in the ``target`` register. Defaults to 
    ``None``.
    """

    fix_signs: bool = True
    """
    If ``False`` do not any sign flips at the end of the circuit. This makes sense if 
    the signs can be fixed at a later stage. Defaults to ``True``.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor 
    simulation. This replaces the X-measurements by unphysical fake X-measurements that 
    are independent of the state that is measured and avoid classical controlled 
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e. 
    no phase flips are applied. Defaults to ``False``.
    """

    # TODO: Do the whole sign-flip business with classical registers instead of our hack

    @property
    def shapes_only(self) -> bool:
        """@private"""
        return is_symbolic(
            self.permutation,
            self.signs_in,
        )

    @property
    def _target_dim(self) -> int:
        """Dimension of the space of the target qubits."""
        return 1 << self.target_dtype.num_bits

    def __attrs_post_init__(self):
        assert slen(self.permutation.data) <= self._target_dim, (
            f"Permutation of length {slen(self.permutation.data)} too long for register of size {self.target_dtype.num_bits}."
        )
        if self.signs_in is not None:
            assert slen(self.signs_in) == self._target_dim, (
                f"Sign_in length {slen(self.signs_in)} must be {self._target_dim}."
            )

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature((Register("target", self.target_dtype),))

    @property
    def signs_out(self) -> HasLen:
        """
        Outgoing signs for each basis state in the ``target`` register.
        """
        if self.shapes_only or not self.fix_signs:
            return self._sign_flips
        return np.zeros(len(self._sign_flips), dtype=bool)  # type: ignore

    @property
    def _expanded_permutation(self) -> Permutation:
        """Take into account basis states in the register that are not permuted."""
        return self.permutation.pad(self._target_dim)

    @property
    def _qroam(self) -> QROAMClean:
        """QROAM for loading the permutation targets."""
        if self.shapes_only:
            qroam = QROAMCleanExactCSwap.build_from_bitsize(
                slen(self._expanded_permutation.data),
                target_bitsizes=(self.target_dtype.num_bits,),
            )
        else:
            qroam = QROAMCleanExactCSwap.build_from_data(
                self._expanded_permutation.data,  # type: ignore
                target_bitsizes=(self.target_dtype.num_bits,),
            )
        return set_qroam_max_junk_size(qroam, self.max_qroam_junk_qubits)

    @property
    def _sign_flips_qroam(self) -> HasLen:
        """Get random sign flips, imitating the flips caused by X-measurements."""
        if self.shapes_only:
            return HasLength(self._target_dim)
        elif self.tensor_simulation:
            return np.zeros(self._target_dim, dtype=bool)
        return random_signs(self._target_dim, seed=1999999)

    @property
    def _sign_flips(self) -> HasLen:
        """
        Signs for all basis states in the ``target`` register at the end of the circuit.
        It is corrected if ``fix_signs`` is set.
        """
        if self.shapes_only or self.signs_in is None:
            return self._sign_flips_qroam
        permuted_signs = self.signs_in[self._expanded_permutation.invert().data]  # type: ignore
        return combine_sign_flips(permuted_signs, self._sign_flips_qroam)

    @property
    def _sign_fix_up_bloq(self) -> SignFixUp:
        """Bloq that applies the sign fixes."""
        return SignFixUp(
            self._sign_flips,
            self.max_qroam_junk_qubits,
            tensor_simulation=self.tensor_simulation,
        )

    def adjoint(self) -> "PermutationViaQROAM":
        """@private"""
        return PermutationViaQROAM(
            self.permutation.invert(),
            self.target_dtype,
            self.signs_in,
            self.fix_signs,
            self.max_qroam_junk_qubits,
            self.tensor_simulation,
        )

    def build_composite_bloq(
        self, bb: BloqBuilder, target: SoquetT
    ) -> dict[str, SoquetT]:  # type: ignore
        """@private"""
        fake_random_meas = False if self.tensor_simulation else None

        soqs = bb.add_d(self._qroam, selection=target)
        target, permuted = bb.add(
            Swap(self.target_dtype.num_bits),
            x=soqs.pop("selection"),
            y=soqs.pop("target0_"),
        )
        soqs = clear_qroam_junk_registers(
            bb, self.target_dtype, fake_random_meas, **soqs
        )
        bb.add(MeasureInX(self.target_dtype, fake_random_meas), to_measure=permuted)
        if self.fix_signs:
            target = bb.add(self._sign_fix_up_bloq, address=target)
        return {"target": target}

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        d = {self._qroam: 1, Swap(self.target_dtype.num_bits): 1}
        if self.fix_signs:
            d[self._sign_fix_up_bloq] = 1  # type: ignore
        return d  # type: ignore

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        return Counter([sum(j.total_qubits() for j in self._qroam.junk_registers)])


def _sparse_to_tuple(m: csr_array) -> tuple:
    """Make a ``csr_array`` hashable."""
    return tuple(m.data) + tuple(m.shape) + tuple(m.indices) + tuple(m.indptr)


@frozen(cache_hash=True)
class SparseThreeTensor:
    """
    A 3-tensor with the middle dimension being 4 represented as a tuple of 4 sparse
    matrices.
    """

    data: tuple[csr_array, csr_array, csr_array, csr_array] = field(
        eq=lambda y: tuple(_sparse_to_tuple(x) for x in y)
    )
    """The 4 matrices."""

    @classmethod
    def from_dense(cls, dense_tensor: np.ndarray):
        """
        Create a ``SparseThreeTensor`` from a dense 3-tensor with the middle dimension
        being 4.
        """
        shape = dense_tensor.shape
        assert len(shape) == 3 and shape[1] == 4, f"Shape {shape} not valid."
        return cls(
            tuple(csr_array(dense_tensor[:, i, :]) for i in range(4))  # type: ignore
        )

    @classmethod
    def from_coo(cls, coo_tensor: coo_array):
        """
        Create a ``SparseThreeTensor`` from a coo 3-tensor with the middle dimension
        being 4.
        """
        shape = coo_tensor.shape
        assert len(shape) == 3 and shape[1] == 4, f"Shape {shape} not valid."
        return cls(
            tuple(csr_array(coo_tensor[:, i, :]) for i in range(4))  # type: ignore
        )

    @property
    def shape(self) -> tuple[int, int, int]:
        """Return the shape of the tensor."""
        matrix = self.data[0]
        return (matrix.shape[0], 4, matrix.shape[1])

    @property
    def is_real(self) -> bool:
        """Check if the tensor is real."""
        return not any(np.issubdtype(d.dtype, np.complexfloating) for d in self.data)

    @property
    def nnz(self) -> int:
        """Return the number of non-zero values of the tensor."""
        return sum(d.nnz for d in self.data)

    @property
    def dense_size(self) -> int:
        """Return the number of elements in a dense representation of the tensor."""
        return sum(d.shape[0] * d.shape[1] for d in self.data)

    @cached_property
    def is_right_canonical(self) -> bool:
        """Check if the tensor is right-canonical."""
        res = sum(d @ (d.transpose().conj()) for d in self.data)
        identity = eye_array(self.shape[0], format="csr")
        return _is_close_to_zero_sparse(res - identity)

    def to_dense(self) -> np.ndarray:
        """Return a dense version of the tensor."""
        return np.stack([d.toarray() for d in self.data], axis=1)

    def _to_target_matrix(self, dim: int) -> csc_array:
        """Transform into the target matrix with ``4*dim`` rows."""
        for t in self.data:
            t.resize((t.shape[0], dim))
        return hstack(self.data).transpose()


def _is_close_to_zero_sparse(array: csr_array | csc_array, atol=1e-7) -> bool:
    """Check if the ``array`` is close to zero."""
    if array.nnz == 0:
        return True
    return np.allclose(array.data, 0, atol=atol)


def _get_rectangles_and_row_permutation(
    matrix: csc_array,
) -> tuple[list[np.ndarray], Permutation]:
    """
    Transforms a ``matrix`` in block sparse MPS form into a matrix of chained blocks,
    i.e. the bottom-right point of rectangle ``i`` borders the top-left point of
    rectangle ``i+1`` starting at the top-left. Return the row permutation that achieves
    this and the resulting rectangles.
    """
    # TODO: Make this faster. Outsource to Rust?
    num_rows, num_cols = matrix.shape

    permutation = []
    blocks = []
    seen_rows = np.zeros(num_rows, dtype=bool)

    current_rectangle_rows: dict[int, None] = dict()
    current_rectangle_cols = []
    for col_idx in range(num_cols):
        non_zero_rows = matrix.indices[
            matrix.indptr[col_idx] : matrix.indptr[col_idx + 1]
        ]
        new_rows = [r for r in non_zero_rows if not seen_rows[r]]

        if len(new_rows) == len(non_zero_rows):  # have new block
            if len(current_rectangle_rows) > 0:
                blocks.append(
                    matrix[list(current_rectangle_rows.keys()), :][
                        :, current_rectangle_cols
                    ].todense()
                )
            current_rectangle_rows = {x: None for x in new_rows}
            current_rectangle_cols = [col_idx]
            permutation.extend(new_rows)
        else:
            current_rectangle_cols.append(col_idx)
            current_rectangle_rows.update({x: None for x in new_rows})

        for r in new_rows:
            seen_rows[r] = True

    if len(current_rectangle_rows) > 0:
        blocks.append(
            matrix[list(current_rectangle_rows.keys()), :][
                :, current_rectangle_cols
            ].todense()
        )

    zero_rows = np.arange(num_rows)[~seen_rows]
    permutation = Permutation(np.hstack([permutation, zero_rows]))
    return blocks, permutation


def expand_to_unitary(rectangle: np.ndarray) -> np.ndarray:
    """
    Expand a ``rectangle`` with orthonormal columns, that is at least as high as wide,
    into a unitary.
    """
    shape = rectangle.shape
    return (
        np.hstack([rectangle, _null_space(rectangle.conj().T)])
        if shape[0] != shape[1]
        else rectangle
    )


def _null_space(rectangle: np.ndarray) -> np.ndarray:
    """Find the null-space of the ``rectangle`` via a SVD."""
    _, _, v_ = np.linalg.svd(rectangle)
    return v_[rectangle.shape[0] :, :].T.conj()


def _find_column_permutation(rectangles: list[np.ndarray]) -> Permutation:
    """
    Given a matrix that is composed of ``rectangles`` whose height is at least their
    width, and which are chained, i.e. the bottom-right point of rectangle ``i`` borders
    the top-left point of rectangle ``i+1``, compute a column permutation that permutes
    in columns from "left of the matrix" such that there is space for the rectangle to
    be transformed into a square block.
    """
    dim = sum(rect.shape[0] for rect in rectangles)
    mapping = np.arange(dim)
    col_left, col_right, diag = 0, dim, 0
    for rect in rectangles:
        height, width = rect.shape[0], rect.shape[1]
        diff = height - width
        mapping[col_left + width : col_right] += diff
        mapping[col_right - diff : col_right] = np.arange(
            diag + width, diag + width + diff
        )
        col_left += width
        col_right -= diff
        diag += height

    mapping = Permutation(mapping).invert()
    assert slen(mapping.data) == dim, (
        f"Permutation has lenght {slen(mapping.data)}. Need {dim}."
    )
    return mapping


def _order_blocks(blocks: list[np.ndarray]) -> tuple[Permutation, list[np.ndarray]]:
    """
    Find a permutation ``P`` such that the block diagonal matrix ``B`` consisting of the
    ``blocks`` gets ordered according to block size, i.e. the biggest block is on the
    top-left. Return the permutation and the reordered blocks.
    """
    dim = sum(block.shape[0] for block in blocks)
    mapping = np.arange(dim)

    col = 0
    elements_before = np.cumsum(np.array([0] + [b.shape[0] for b in blocks]))
    for i, block in sorted(enumerate(blocks), key=lambda p: -p[1].shape[0]):
        before = elements_before[i]
        size = block.shape[0]
        mapping[before : before + size] = np.arange(col, col + size)
        col += size

    mapping = Permutation(mapping).invert()
    assert slen(mapping.data) == dim, (
        f"Permutation has lenght {slen(mapping.data)}. Need {dim}."
    )
    return mapping, sorted(blocks, key=lambda block: -block.shape[0])


@frozen(cache_hash=True)
class SiteUnitarySparse(Bloq):
    """
    Implement the unitary corresponding to a site. Permute the rows and columns and
    expand orthogonal columns into a unitary that it is block-diagonal. Then synthesize
    this block-diagonal unitary.

    The rotations are applied using a phase-gradient register.
    The qubit/Toffoli tradeoff in the QROAMs can be controlled via ``max_qroam_junk_qubits``.

    Note: For compatibility reasons the ``tensor`` is a general dense numpy array. For
    speed and memory reasons this is not ideal and code adapted to the sparse data
    formats of the DMRG-codes used might be benefitial.

    As Qualtrans capabilities for processing classical measurement results and applying
    feedback are just starting to grow, the Bloq does not implement the classical logic
    of calculating the sign-flips for the individual basis states caused by X-measuring
    the target registers of QRO(A)Ms. The measurement results are simply discarded.
    See ``tensor_simulation`` for how those measurements can be treated in simulations.

    Registers
    ----------
    - site : ``self.site_dtype``:
        The site register consisting of two qubits.

    - phase_gradient : ``self.phase_gradient_dtype``:
        An auxiliary register used to apply rotations. It is passed through unchanged.

    - ancilla : ``self.ancilla_dtype``:
        ancilla register bringing information from previous sites in and for following
        sites out of the unitary.
    """

    tensor: SparseThreeTensor
    """
    Tensor for the site.s
    """

    phase_gradient_dtype: QFxp
    """
    Datatype for the phase-gradient register. Its size determines the accuracy of the 
    rotations.
    """

    is_complex: bool
    """
    Indicate whether the tensor is tensors or not. This can also be used to force  real 
    tensors to be treated as complex.
    """

    max_qroam_junk_qubits: int | None = None
    """
    Maximum number of junk qubits used in QROAMs. If ``None`` compute the optimal value. 
    If ``0`` use QROM.
    """

    shapes_only: bool = False
    """Consider for all subbloqs only the shapes of the tensor."""

    tensor_simulation: bool = False
    """
    If ``True`` make the Bloq (and sub-Bloqs) suitable for (non-superoperator) tensor 
    simulation. This replaces the X-measurements by unphysical fake X-measurements that 
    are independent of the state that is measured and avoid classical controlled 
    operations. Each X-measurement result is assumed to be deterministically |+>, i.e. 
    no phase flips are applied. Do not use when doing ressource estimates! Defaults to 
    ``False``.
    """

    @property
    def ancilla_dtype(self) -> QUInt:
        """Datatype of the ancilla register"""
        return QUInt(bit_length(max(self.tensor.shape[2], self.tensor.shape[0]) - 1))

    @property
    def _target_matrix(self) -> csc_array:
        """Transform tensor to matrix according to eq. (6) in Berry et al. paper."""
        dim = 1 << self.ancilla_dtype.bitsize  # type :ignore
        return self.tensor._to_target_matrix(dim)

    def __attrs_post_init__(self):
        assert self.tensor.is_right_canonical, "Tensor is not in right-canonical form."
        if not self.is_complex:
            assert self.tensor.is_real, "Tensor is not real."

    @property
    def site_dtype(self) -> QUInt:
        """Datatype of the site. Consists of two qubits."""
        return QUInt(2)

    @property
    def signature(self) -> Signature:
        """@private"""
        return Signature(
            [
                Register("site", self.site_dtype),
                Register("ancilla", self.ancilla_dtype),
                Register("phase_gradient", self.phase_gradient_dtype),
            ]
        )

    @property
    def _target_dtype(self) -> QUInt:
        """Datatype of the full working register."""
        return QUInt(self.site_dtype.num_bits + self.ancilla_dtype.num_bits)

    @cached_property
    def _decomposition(
        self,
    ) -> tuple[Permutation, tuple[np.ndarray, ...], Permutation]:
        """
        Find a decomposition ``U = P*G*P'`` with ``P`` and ``P'`` being permutation
        matrices and ``G`` being a block-diagonal matrix, such that the first columns of
        ``U`` correspond to the orthogonal columns to be implemented.
        """
        active_dim = self._target_matrix.shape[0]

        rectangles, row_perm = _get_rectangles_and_row_permutation(self._target_matrix)
        row_perm = row_perm.pad(active_dim)

        col_perm = _find_column_permutation(rectangles).pad(active_dim)
        blocks = [expand_to_unitary(rect) for rect in rectangles]

        blocks = blocks + [np.eye(1)] * (
            active_dim - sum(b.shape[0] for b in blocks)
        )  # Pad to fill the complete active matrix

        ordering_perm, blocks = _order_blocks(blocks)
        ordering_perm = ordering_perm.pad(active_dim)

        col_perm = (ordering_perm @ col_perm).invert()
        row_perm = ordering_perm @ row_perm

        return (row_perm, tuple(blocks), col_perm)

    @property
    def _row_permutation(self) -> Permutation:
        """Row permutation applied."""
        perm = self._decomposition[0]
        return perm.to_symbolic() if self.shapes_only else perm

    @property
    def _column_permutation(self) -> Permutation:
        """Column permutation applied."""
        perm = self._decomposition[2]
        return perm.to_symbolic() if self.shapes_only else perm

    @property
    def _block_matrices(self) -> tuple[np.ndarray | Shaped, ...]:
        """Blocks of block-diagonal matrix to be synthesized."""
        matrices = self._decomposition[1]
        if self.shapes_only:
            return tuple(Shaped(m.shape) for m in matrices)
        return matrices

    def _assert_decomposition_valid(self):
        """Check whether the decomposition reproduces the correct matrix."""
        res = (
            block_diag(self._block_matrices, format="csc")[
                self._row_permutation.invert().data
            ][:, self._column_permutation.data][:, : self._target_matrix.shape[1]],
        )
        assert _is_close_to_zero_sparse(res - self._target_matrix), (
            "The decomposition must recreate the target matrix."
        )

    @cached_property
    def _row_permutation_bloq(self) -> PermutationViaQROAM:
        """Bloq executing the row permutation."""
        return PermutationViaQROAM(
            self._row_permutation,
            self._target_dtype,
            self._block_unitary_bloq.signs_out,
            max_qroam_junk_qubits=self.max_qroam_junk_qubits,
            tensor_simulation=self.tensor_simulation,
        )

    @cached_property
    def _column_permutation_bloq(self) -> PermutationViaQROAM:
        """Bloq executing the column permutation."""
        return PermutationViaQROAM(
            self._column_permutation,
            self._target_dtype,
            fix_signs=False,
            max_qroam_junk_qubits=self.max_qroam_junk_qubits,
            tensor_simulation=self.tensor_simulation,
        )

    @cached_property
    def _block_unitary_bloq(self) -> Unitary:
        """Bloq implementing the block-diagonal matrix."""
        return Unitary.from_block_diagonal_matrices(
            (self._block_matrices,),
            self._target_dtype,
            self.phase_gradient_dtype,
            self.is_complex,
            signs_in=self._column_permutation_bloq.signs_out,
            fix_signs=False,
            max_qroam_junk_qubits=self.max_qroam_junk_qubits,
            tensor_simulation=self.tensor_simulation,
        )

    @property
    def _partition(self) -> Partition:
        """
        Partition the ``site`` and ``ancilla`` registers into a big working register.
        """
        return Partition(
            self._target_dtype.num_bits,
            (
                Register("site", self.site_dtype),
                Register("ancilla", self.ancilla_dtype),
            ),
        )

    def build_composite_bloq(
        self,
        bb: BloqBuilder,
        site: SoquetT,
        ancilla: SoquetT,
        phase_gradient: SoquetT,
    ) -> dict[str, SoquetT]:  # type: ignore
        """@private"""
        target = bb.add(self._partition.adjoint(), site=site, ancilla=ancilla)
        target = bb.add(self._column_permutation_bloq, target=target)
        target, phase_gradient = bb.add(
            self._block_unitary_bloq, target=target, phase_gradient=phase_gradient
        )
        target = bb.add(self._row_permutation_bloq, target=target)
        site, ancilla = bb.add(self._partition, x=target)
        return {"site": site, "ancilla": ancilla, "phase_gradient": phase_gradient}

    def build_call_graph(self, ssa: SympySymbolAllocator) -> BloqCountDictT:
        """@private"""
        return {
            self._column_permutation_bloq: 1,
            self._row_permutation_bloq: 1,
            self._block_unitary_bloq: 1,
        }

    @property
    def junk_register_qubits(self) -> dict[int, int]:
        """
        Count the number of junk register qubits used in QROAM's and the number of their
        occurences.
        """
        return sum(
            (
                b.junk_register_qubits
                for b in (
                    self._column_permutation_bloq,
                    self._row_permutation_bloq,
                    self._block_unitary_bloq,
                )
            ),
            Counter(),
        )


@bloq_example(generalizer=generalizer)
def _permutation() -> PermutationViaQROAM:
    return PermutationViaQROAM(
        Permutation(
            np.array([7, 11, 3, 13, 1, 9, 5, 0, 2, 8, 4, 12, 6, 10], dtype=int)
        ),
        QUInt(4),
        fix_signs=False,
    )


@bloq_example(generalizer=generalizer)
def _site_unitary_sparse() -> SiteUnitarySparse:
    return SiteUnitarySparse(_tensor, QFxp(6, 6), is_complex=False)


_tensor = SparseThreeTensor.from_coo(coo_array(
    (
        np.array(
    [ 1.        , -0.06529681, -0.21823697,  0.80873407,
       -0.54227129,  0.99196206, -0.05352461,  0.10145871,
        0.05340906, -0.0314629 , -0.97114398, -0.23105394,
        0.05003537, -0.10371929, -0.07991947,  0.53129032,
        0.83701003, -0.71416854,  0.38268343, -0.58610297,
       -0.29581829, -0.92387953, -0.2427718 , -0.63439328,
        0.77301045, -0.70710678, -0.70710678, -0.70710678,
        0.70710678, -0.04667196,  0.08183508,  0.17913141,
       -0.4376217 ,  0.50294103,  0.37637954,  0.08194149,
        0.10117301, -0.3569069 ,  0.47769864,  0.01959044,
       -0.6091723 ,  0.06806463, -0.27941392, -0.1228121 ,
        0.20408854, -0.09277709, -0.18419342,  0.09848402,
       -0.4107272 , -0.51416707, -0.06458102, -0.00057106,
        0.04646671, -0.39307151, -0.05791556, -0.32300574,
       -0.48580074, -0.13162936, -0.00774822, -0.37507311,
        0.56000868, -0.16724278,  0.2841895 ,  0.04419075,
        0.08735139, -0.81258978, -0.35215065, -0.06047946,
       -0.06983318, -0.15004217, -0.01491312, -0.3064603 ,
        0.01239363, -0.23504973, -0.0787661 , -0.03991293,
        0.00944982,  0.07644049,  0.09293174, -0.05945385,
       -0.95174013,  0.04407359,  0.10529448, -0.00350562,
        0.02966449,  0.02995518, -0.16987694,  0.01490345,
       -0.0160302 , -0.05276522, -0.06852768, -0.00860989,
       -0.0944491 ,  0.03659029,  0.97522901]), 
       (np.array(
    [ 0,  1,  1,  1,  1,  2,  2,  2,  2,  3,  3,  3,  3,  4,  4,  4,  4,  5,  5,  5,
         6,  6,  6,  7,  7,  8,  8,  9,  9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
        11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12,
        12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14, 14, 14, 14,
        14, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15]),
 np.array([3, 0, 3, 3, 3, 0, 3, 3, 3, 0, 3, 3, 3, 0, 3, 3, 3, 2, 3, 3, 2, 3, 3, 2, 3, 1, 3,
        1, 3, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 0, 0, 0,
        1, 1, 1, 2, 2, 2, 3, 3, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 0, 0, 0, 1, 1, 1, 2, 2,
        2, 3, 3, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3]),
 np.array([ 0,  0,  1,  2,  3,  0,  1,  2,  3,  0,  1,  2,  3,  0,  1,  2,  3,  4,  5,  6,
         4,  5,  6,  4,  6,  4, 10,  4, 10,  1,  2,  3,  7,  8,  9, 11, 12, 13, 14, 15,
         1,  2,  3,  7,  8,  9, 11, 12, 13, 14, 15,  1,  2,  3,  7,  8,  9, 11, 12, 13,
        14, 15,  1,  2,  3,  7,  8,  9, 11, 12, 13, 14, 15,  1,  2,  3,  7,  8,  9, 11,
        12, 13, 14, 15,  1,  2,  3,  7,  8,  9, 11, 12, 13, 14, 15]))), 
       shape=(16, 4, 16)
    ))  # fmt: skip
