# SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)
#
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import pytest
from attrs import evolve
from isometry import random_signs
from isometry.utils_test import bloq_autotester_with_counts  # noqa: F401
from qualtran import BloqBuilder, QUInt, Register
from qualtran.bloqs.rotations.phase_gradient import PhaseGradientState
from qualtran.dtype import QFxp
from qualtran.simulation.classical_sim import do_phased_classical_simulation
from scipy.sparse import coo_array

from state_preparation.site_unitaries.site_unitary_sparse import SparseThreeTensor

from .site_unitary_sparse import (
    Permutation,
    PermutationViaQROAM,
    SiteUnitarySparse,
    _permutation,
    _site_unitary_sparse,
)

small_permutation = PermutationViaQROAM(
    Permutation(np.array([1, 0], dtype=int)), QUInt(1)
)


@pytest.mark.parametrize(
    "bloq_ex",
    [_permutation, _site_unitary_sparse],
)
def test_example(bloq_autotester_with_counts, bloq_ex):  # noqa: F811
    bloq_autotester_with_counts(bloq_ex)


@pytest.mark.parametrize(
    "bloq",
    [_permutation(), small_permutation],
)
def test_up_to_sign(bloq):
    for i, per_i in enumerate(bloq.permutation.data):
        val, phase = do_phased_classical_simulation(
            bloq, {"target": i}, np.random.default_rng(seed=123)
        )
        assert val == {"target": per_i}
    for i in range(len(bloq.permutation.data), 1 << bloq.target_dtype.num_bits):
        val, phase = do_phased_classical_simulation(
            bloq, {"target": i}, np.random.default_rng(seed=123)
        )
        assert val == {"target": i}


@pytest.mark.parametrize(
    "bloq",
    [_permutation(), small_permutation],
)
def test_adjoint_up_to_sign(bloq):
    for i, per_i in enumerate(bloq.permutation.data):
        val, _ = do_phased_classical_simulation(
            bloq.adjoint(), {"target": per_i}, np.random.default_rng(seed=123)
        )
        assert val == {"target": i}
    for i in range(len(bloq.permutation.data), 1 << bloq.target_dtype.num_bits):
        val, phase = do_phased_classical_simulation(
            bloq.adjoint(), {"target": i}, np.random.default_rng(seed=123)
        )
        assert val == {"target": i}


@pytest.mark.parametrize(
    "fix_signs",
    [True, False],
)
def test_sign_flip_commutation(fix_signs):
    signs_in = random_signs(16, 2341253)
    target = evolve(_permutation(), tensor_simulation=True)
    permutation = evolve(
        _permutation(), signs_in=signs_in, fix_signs=fix_signs, tensor_simulation=True
    )
    assert np.allclose(
        target.tensor_contract() @ np.diag((-1) ** signs_in),
        np.diag((-1) ** permutation.signs_out) @ permutation.tensor_contract(),  # type: ignore
    )


tensor = SparseThreeTensor.from_coo(coo_array((np.array(
    [ 1.        ,  1.        ,  1.        , -1.        ,  1.        , -1.        ,
        1.        ,  1.        , -1.        ,  1.        , -0.77301045,  0.63439328,
       -0.7233408 , -0.52276972, -0.45109855, -0.88192126,  0.47139674,  0.5632571 ,
        0.47420886, -0.676659  , -0.5632571 ,  0.47420886, -0.676659  ,  1.        ]),
       (np.array(
        [ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 10, 11, 11, 11, 12, 12, 13, 13, 13,
        14, 14, 14, 15]),
       np.array(
        [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 2, 3]),
       np.array(
        [ 0,  1,  3,  4,  5,  6,  7,  9, 11, 12,  8,  9,  2, 10, 11,  3,  5,  8,  9, 13,
        10, 11, 14, 15]))), (16, 4, 16)
    ))  # fmt: skip

site_unitary_sparse = SiteUnitarySparse(tensor, QFxp(6, 6), False)


@pytest.mark.parametrize("complex", [False, True])
@pytest.mark.parametrize(
    "bloq",
    [site_unitary_sparse, _site_unitary_sparse()],
)
def test_site_unitary_sparse(complex, bloq):
    unitary = evolve(
        bloq, tensor_simulation=True, max_qroam_junk_qubits=0, is_complex=complex
    )
    phase_gradient_state = PhaseGradientState(unitary.phase_gradient_dtype.num_bits)

    bb = BloqBuilder()
    soqs = {}
    soqs["site"] = bb.add_register(Register("site", QUInt(2)))
    soqs["ancilla"] = bb.add_register(Register("ancilla", QUInt(4)))
    soqs["phase_gradient"] = bb.add(phase_gradient_state)

    soqs = bb.add_d(unitary, **soqs)
    bb.add(phase_gradient_state.adjoint(), phase_grad=soqs.pop("phase_gradient"))
    bloq = bb.finalize(site=soqs.pop("site"), ancilla=soqs.pop("ancilla"))

    # Would like to use larger phase gradient states to be able to lower the atol, but
    # this would require too much memory.
    assert np.allclose(
        bloq.tensor_contract()[:64, :16], unitary._target_matrix.todense(), atol=0.072
    )
