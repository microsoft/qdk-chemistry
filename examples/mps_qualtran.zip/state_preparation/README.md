<!--
SPDX-FileCopyrightText: 2026 German Aerospace Center (DLR)

SPDX-License-Identifier: Apache-2.0
-->

# state_preparation_lib

This repository contains algorithms for preparing quantum states written in the [Qualtran](https://github.com/quantumlib/Qualtran) framework.

The main package [state_preparation](/packages/state-preparation/) contains Bloqs for preparing dense quantum states, sparse quantum states and matrix-product-states.
The helper packages [unitary_synthesis](/packages/unitary_synthesis/) and [isometry](/packages/isometry/) contain sub-Bloqs used in the main package with all relevant objects from the subpackages being reexported in `state_preparation`. 
The helper packages encapsulate Rust code that is used for speeding-up more ressource intensive tasks.

The background for the sparse state preparation code is explained in the paper [arXiv:2601.09388](https://arxiv.org/abs/2601.09388).

## Installation

Assuming [uv](https://docs.astral.sh/uv/) is installed, the package can be built and installed by calling `uv sync` in the project folder.

## Tests

There are tests for both the Rust and Python code.

For running the Python tests simply call `uv run pytest`, and for the Rust tests 
```
cargo test --manifest-path packages/isometry/Cargo.toml
cargo test --manifest-path packages/unitary_synthesis/Cargo.toml
```
(assuming the [rust toolchain](https://rust-lang.org/tools/install/) is installed).

## Examples

An introductory notebook for the sparse state preparation code may be found in the [examples](/examples/) folder.

## Documentation

Documentation for the Python code can be built via [pdoc](https://pdoc.dev/) by (be aware of the information in [Caution!](#caution))
```
uv add pdoc
uv run pdoc state_preparation
```

## Acknowledgements

This work has been funded by the Ministry of Economic Affairs, Labour and Tourism Baden Württemberg through the Competence Center Quantum Computing Baden-Württemberg (KQCBW).

## License

This code is licensed under the Apache License, Version 2.0 [LICENSE](LICENSES/Apache-2.0.txt).

Copyright 2025-2026 German Aerospace Center (DLR)